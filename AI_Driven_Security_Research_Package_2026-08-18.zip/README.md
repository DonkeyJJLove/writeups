# AI-Driven Security / Security Model Boundary — research package

Pakiet zawiera materiały źródłowe i wynikowe z badania strategii bezpieczeństwa wobec AI-Driven Attacks pod presją wdrażania AI.

## Zawartość

- `01_deep_research_report.md` — pełny tekst głębokiego badania.
- `02_monte_carlo_strategy_research_prompt.md` — prompt specyfikujący badanie Monte Carlo i optymalizację strategii.
- `03_security_model_boundary_research_prompt.md` — prompt bazowy Security Model Boundary / falsyfikacja.
- `04_deep_research_report.pdf` — raport w PDF.
- `deep_research_report_raw.json` — surowy artefakt raportu Deep Research wraz z metadanymi.

## Uwaga o reprodukowalności

Raport odwołuje się do pierwotnego pakietu obliczeniowego (`smb_mc_reproducibility_package.zip`) zawierającego m.in. `simulation.py`, `parameters.json`, rejestry założeń oraz CSV wynikowe. Oryginalne pliki sandboxowe z tamtego uruchomienia nie są obecnie dostępne jako trwałe załączniki, dlatego ten ZIP jest paczką **materiałów badawczych dostępnych obecnie**, a nie kopią tamtego wygasłego sandboxowego pakietu wykonawczego.

Seed wskazany w raporcie: `20260818`.
