# ROLA

Działasz jako interdyscyplinarny zespół badawczy łączący kompetencje:

- AI Security Researcher,
- Offensive Security Architect,
- Defensive Security Architect,
- Agentic Systems Security Engineer,
- Vulnerability Researcher,
- Security Model Auditor,
- Cognitive Security Researcher,
- Distributed Systems Researcher,
- Reliability / Resilience Engineer,
- Applied Probabilistic Reasoning Researcher,
- Formal Methods Researcher,
- Threat Intelligence Analyst,
- Security Economics Researcher,
- Technology Risk Researcher,
- Human Factors / HCI Researcher.

Twoim zadaniem jest przeprowadzenie **badania naukowego, falsyfikacji i racjonalizacji przedstawionej hipotezy**, a następnie — wyłącznie w zakresie uzasadnionym materiałem dowodowym — skonstruowanie **strategii obronnej przeciw AI-Driven Attacks**, której głównym przedmiotem nie będzie klasyczna powierzchnia ataku, lecz **granica obowiązującego modelu bezpieczeństwa**.

Nie zakładaj z góry, że hipoteza jest prawdziwa.

Jednocześnie nie redukuj jej automatycznie do istniejących kategorii typu prompt injection, insecure output handling, excessive agency, confused deputy, RAG poisoning czy conventional authorization flaw. Zbadaj możliwość, że problem znajduje się **poziom wyżej: w kompozycji zachowań uznawanych indywidualnie za dopuszczalne**.

# HIPOTEZA BADAWCZA

Współczesne infrastruktury AI i systemy agentowe mogą posiadać systemową klasę słabości wynikającą nie tyle z pojedynczych błędów implementacyjnych, ile z **niepełności modeli bezpieczeństwa używanych do ich projektowania, testowania i certyfikowania**.

Możliwy mechanizm wygląda następująco:

1. Poszczególne komponenty, operacje lub prymitywy spełniają lokalne wymagania bezpieczeństwa.
2. Każdy komponent analizowany osobno może zachowywać się zgodnie ze swoim modelem bezpieczeństwa.
3. System AI łączy jednak komponenty poprzez probabilistyczne decyzje, kontekst, narzędzia, pamięć, workflowy, delegację uprawnień, dane zewnętrzne i systemy deterministyczne.
4. Powstają ścieżki wykonania, które nie muszą zawierać klasycznej pojedynczej podatności.
5. Kompozycja kilku lokalnie poprawnych zachowań może jednak wygenerować globalnie niebezpieczny stan.
6. Atak może więc istnieć nie jako:

`vulnerability → exploit`

lecz jako:

`allowed primitive A → AI-mediated transition → allowed primitive B → state transition → allowed primitive C → unsafe global outcome`

7. W takim przypadku klasyczny model bezpieczeństwa może prawidłowo klasyfikować wszystkie elementy lokalne, a jednocześnie nie reprezentować niebezpiecznej właściwości ich kompozycji.

Hipoteza zakłada więc możliwość istnienia:

**Security Model Boundary Exploitation**

czyli ataków wykorzystujących nie tyle naruszenie reguł modelu bezpieczeństwa, ile **zachowania znajdujące się poza zakresem jego reprezentacji**.

# CENTRALNE PYTANIE

Zbadaj:

> Czy rozwój systemów AI, agentów i Copilotów stworzył klasę zagrożeń, w której lokalnie poprawne i zgodne z polityką operacje mogą poprzez probabilistyczną kompozycję wygenerować globalnie niebezpieczne zachowanie, którego klasyczne modele bezpieczeństwa nie reprezentują wystarczająco?

Jeżeli tak, ustal:

> Jak rozszerzyć model bezpieczeństwa i praktykę defensive/offensive security tak, aby wykrywać i neutralizować takie ścieżki przed ich wykorzystaniem przez AI-driven attackers?

# I. FALSYFIKACJA HIPOTEZY

Najpierw spróbuj hipotezę obalić.

Poszukaj dowodów, że istniejące modele bezpieczeństwa, standardy, threat modeling, zero trust, formal verification, attack graphs, model checking, taint tracking, information-flow control, capability security, runtime monitoring albo inne istniejące mechanizmy już wystarczająco rozwiązują opisany problem.

Rozdziel co najmniej:

- błąd implementacyjny,
- błąd konfiguracji,
- błąd autoryzacji,
- błąd workflow,
- błąd modelu zagrożeń,
- błąd kompozycji,
- emergent behavior,
- AI-specific vulnerability,
- klasyczny exploit tylko wykonywany przez AI,
- rzeczywistą lukę w reprezentacji modelu bezpieczeństwa.

Nie nazywaj nową klasą czegoś, co można wystarczająco opisać istniejącą terminologią.

# II. SECURITY MODEL BOUNDARY

Jeżeli hipoteza przeżyje falsyfikację, zdefiniuj formalnie pojęcie:

**Security Model Boundary — SMB**

Rozróżnij:

- przestrzeń stanów reprezentowanych przez model,
- przestrzeń stanów rzeczywiście osiągalnych,
- przestrzeń stanów testowanych,
- przestrzeń stanów dopuszczonych przez politykę,
- przestrzeń stanów obserwowalnych,
- przestrzeń stanów kontrolowalnych,
- przestrzeń kompozycji pomiędzy komponentami.

Zbadaj sytuację:

`Allowed(A) = true`

`Allowed(B) = true`

`Allowed(C) = true`

ale:

`Safe(A ∘ B ∘ C) = false`

Sprawdź, czy właśnie tutaj może znajdować się właściwa jednostka analizy.

# III. PRIMITIVE COMPOSITION

Zbadaj problem izolowanego testowania prymitywów.

Przeanalizuj przypadek, w którym:

- primitive A nie jest podatnością,
- primitive B nie jest podatnością,
- primitive C nie jest podatnością,

ale ich kompozycja prowadzi do naruszenia własności bezpieczeństwa.

Formalizuj różnicę między:

**primitive vulnerability**

a:

**compositional exploitability**.

Zbadaj analogie do:

- exploit chains,
- weird machines,
- confused deputy,
- protocol composition attacks,
- capability leakage,
- TOCTOU,
- state machine abuse,
- business logic vulnerabilities,
- authorization graph attacks,
- transitive trust,
- cross-domain attacks,
- emergent distributed-system failures.

Ustal, gdzie analogie są trafne, a gdzie AI tworzy jakościowo nowy problem.

# IV. GRANICA PROBABILISTYCZNE ↔ DETERMINISTYCZNE

Szczególną uwagę poświęć przejściom:

`deterministic → probabilistic → deterministic`

Przykładowo:

`API → LLM/agent → tool decision → API`

`user input → Copilot → generated action → privileged system`

`document → RAG → model reasoning → workflow engine`

`telemetry → AI interpretation → remediation action`

Zbadaj, czy klasyczne modele bezpieczeństwa zakładają stabilność semantyczną, której system probabilistyczny nie gwarantuje.

Wprowadź pojęcie **Probabilistic-Deterministic Boundary** i oceń, czy jest ono szczególnie istotnym miejscem dla powstawania niebezpiecznych kompozycji.

# V. WORKFLOW JAKO POWIERZCHNIA ATAKU

Nie analizuj wyłącznie kodu, API i pojedynczych komponentów.

Potraktuj cały workflow jako potencjalną powierzchnię ataku:

`input → interpretation → context → decision → delegation → tool → state change → observation → next decision`

Zbadaj możliwość występowania:

- unsafe loops,
- feedback amplification,
- recursive delegation,
- authority propagation,
- context contamination,
- state drift,
- semantic drift,
- execution drift,
- privilege accumulation,
- cross-agent trust propagation,
- delayed unsafe effects.

Zadaj pytanie:

> Czy bezpieczeństwo systemów agentowych powinno być właściwością ścieżki wykonania, a nie tylko właściwością komponentów?

# VI. OBSERWOWALNOŚĆ

Zbadaj hipotezę, że nie można skutecznie kontrolować systemu, którego istotnych stanów nie można obserwować.

Rozważ zależność:

`Observability → Detectability → Controllability → Enforceability`

Ustal, jakie elementy systemów AI pozostają obecnie słabo obserwowalne:

- kontekst,
- provenance,
- authority propagation,
- tool-selection reasoning,
- memory influence,
- cross-agent state,
- semantic transformation,
- decision provenance,
- causal chain wykonania.

Zbadaj zasadę:

> utrata obserwowalności krytycznej części ścieżki wykonania powinna powodować redukcję authority albo zatrzymanie wykonania.

# VII. KERNEL MODEL OBSERWOWALNOŚCI

Jeżeli materiał dowodowy to uzasadnia, zaprojektuj minimalny **Security Observability Kernel**.

Kernel powinien śledzić co najmniej:

`SOURCE`

`IDENTITY`

`CONTEXT`

`INSTRUCTION`

`MEMORY`

`AUTHORITY`

`DECISION`

`TOOL`

`STATE CHANGE`

`OUTPUT`

`NEXT ACTION`

Każde wykonanie powinno umożliwiać rekonstrukcję:

`Source → Interpretation → Authority → Decision → Action → Effect`

Określ minimalny zestaw informacji konieczny do ustalenia, dlaczego system uzyskał możliwość wykonania danej operacji.

# VIII. COMBINATORIAL EXECUTION CONTROL

Zaprojektuj mechanizm kontroli, który nie pyta wyłącznie:

> Czy operacja X jest dozwolona?

ale również:

> Czy operacja X jest bezpieczna w kontekście całej dotychczasowej ścieżki wykonania?

Model powinien rozważać:

`Risk(next_action | execution_history, authority_history, context_history, state)`

Zaproponuj mechanizmy ograniczające eksplozję kombinatoryczną.

Rozważ:

- pruning,
- risk budgets,
- provenance compression,
- bounded history,
- dynamic trust reduction,
- taint propagation,
- capability attenuation,
- causal graphs,
- attack-path scoring,
- runtime invariants,
- execution receipts,
- uncertainty thresholds.

# IX. TECHNOLOGICAL SECURITY DEBT

Zbadaj hipotezę, że problem może być częściowo konsekwencją długu technologicznego.

Nie zakładaj intencjonalnego ukrywania problemu przez producentów bez dowodów.

Zamiast tego zbadaj ekonomicznie:

- koszt pełniejszej obserwowalności,
- koszt state-space exploration,
- koszt combinatorial testing,
- latency,
- inference cost,
- telemetry volume,
- false positives,
- compatibility,
- developer friction,
- time-to-market.

Sprawdź, czy organizacje mogły racjonalnie optymalizować systemy w sposób pozostawiający część ryzyka poza praktycznym modelem kontroli.

Nazwij to — jeżeli dowody pozwalają — **Security Model Debt**.

# X. COMPLIANCE VS SECURITY

Zbadaj różnicę pomiędzy:

`compliant(system, standard)`

a:

`safe(system, environment)`

Sprawdź możliwość istnienia:

`Compliant = true`

przy jednoczesnym:

`Residual systemic risk = high`

Nie traktuj tego jako automatycznego dowodu nieskuteczności compliance.

Ustal dokładnie, które klasy ryzyka mogą znajdować się poza zakresem istniejących standardów.

Zbadaj zasadę:

> Standard powinien być kodowaną konsekwencją wiedzy o bezpieczeństwie, a nie epistemiczną granicą tego, czego wolno szukać.

# XI. ADVERSARIAL PRESSURE

Zbadaj, czy realni operatorzy ofensywni mają ekonomiczną przewagę wynikającą z asymetrii:

**defender:**
musi utrzymać model, interoperacyjność, SLA, compliance i przewidywalność;

**attacker:**
musi znaleźć tylko jedną osiągalną ścieżkę prowadzącą poza założenia modelu.

Przeanalizuj:

`Defender optimizes inside model`

versus:

`Attacker searches boundary of model`

Sprawdź, czy AI zwiększa tę asymetrię poprzez automatyzację eksploracji dużych przestrzeni kombinatorycznych.

# XII. STRATEGIA — SECURITY MODEL BOUNDARY PROGRAM

Na podstawie wyników badań zaprojektuj strategię obronną.

Jeżeli hipoteza zostanie wystarczająco potwierdzona, strategia powinna koncentrować się na:

**atakowaniu badawczym granicy modelu bezpieczeństwa, aby wymuszać jego rozszerzanie zanim zrobi to przeciwnik.**

Nie chodzi o ofensywne atakowanie cudzych systemów.

Chodzi o systematyczne adversarial testing własnych, laboratoryjnych, autoryzowanych i objętych bug bounty środowisk.

Podziel strategię na:

### RED — Boundary Discovery

Poszukuj:

- bezpiecznych lokalnie prymitywów,
- niebezpiecznych kompozycji,
- przejść między trust domains,
- AI-mediated state transitions,
- cross-agent propagation,
- authority inheritance,
- deterministic/probabilistic boundary failures.

### BLUE — Boundary Enforcement

Buduj:

- runtime invariants,
- authority attenuation,
- execution provenance,
- observability,
- isolation,
- circuit breakers,
- semantic validation,
- deterministic verification gates.

### PURPLE — Model Expansion

Każdy potwierdzony boundary exploit powinien prowadzić do:

`finding → primitive decomposition → missing invariant → model extension → regression test → runtime control`

Celem nie jest wyłącznie załatanie konkretnego exploita.

Celem jest **rozszerzenie modelu tak, aby cała klasa podobnych ścieżek przestała być osiągalna**.

# XIII. PRIORYTETY

Zaproponuj priorytety badawcze według relacji:

`Risk = Reachability × Impact × Composability × Automation × Observability Gap`

Szczególnie wysoko klasyfikuj przypadki, w których:

- pojedyncze operacje są legalne,
- exploit wymaga kompozycji,
- AI może automatyzować kompozycję,
- efekt przekracza trust boundary,
- monitoring nie rekonstruuje całej ścieżki,
- problem występuje w szeroko stosowanym komponencie infrastrukturalnym.

# XIV. BUFFER MODEL

Zaprojektuj koncepcję **Security Boundary Buffer** pomiędzy:

`known-safe model`

a:

`unbounded execution space`.

Bufor powinien obejmować:

- rozszerzoną obserwowalność,
- ograniczenie authority,
- probabilistic risk scoring,
- deterministic gates,
- execution provenance,
- anomaly detection,
- combinatorial testing,
- automated containment.

Zbadaj zasadę:

> Im bardziej system oddala się od dobrze obserwowalnej i zweryfikowanej części przestrzeni stanów, tym mniejszą autonomię powinien posiadać.

# XV. WYMAGANA FALSYFIKACJA STRATEGII

Po skonstruowaniu strategii spróbuj ją zniszczyć.

Sprawdź:

- czy jest obliczeniowo wykonalna,
- czy powoduje state-space explosion,
- czy nie blokuje użyteczności AI,
- czy nie sprowadza się do istniejącego zero trust,
- czy observability rzeczywiście pomaga,
- czy attacker może manipulować telemetry,
- czy execution provenance może zostać zatrute,
- czy risk scoring nie tworzy kolejnego probabilistycznego punktu awarii,
- czy system nie wymaga nierealistycznej pełnej wiedzy o stanie.

Następnie popraw strategię.

# XVI. RESEARCH OUTPUT

Końcowy wynik ma zawierać:

1. **Verdict hipotezy** — potwierdzona / częściowo potwierdzona / sfalsyfikowana.
2. **Poziom pewności** dla najważniejszych wniosków.
3. **Najsilniejsze dowody wspierające.**
4. **Najsilniejsze kontrargumenty i przypadki falsyfikujące.**
5. **Formalny model Security Model Boundary.**
6. **Model Primitive Composition Exploitability.**
7. **Model Probabilistic-Deterministic Boundary.**
8. **Analizę Security Model Debt.**
9. **Analizę compliance vs rzeczywiste bezpieczeństwo.**
10. **Strategię Security Model Boundary Program.**
11. **Security Observability Kernel.**
12. **Combinatorial Execution Control.**
13. **Security Boundary Buffer.**
14. **Program RED / BLUE / PURPLE.**
15. **Metryki pozwalające sprawdzić, czy strategia rzeczywiście redukuje ryzyko.**
16. **Roadmapę wdrożenia: 30 / 90 / 180 / 365 dni.**

# XVII. REŻIM DOWODOWY

**REŻIM: NAUKOWY**

Każde istotne twierdzenie klasyfikuj jako:

- FACT,
- STRONG EVIDENCE,
- MODERATE EVIDENCE,
- WEAK EVIDENCE,
- HYPOTHESIS,
- SPECULATION.

Nie przekształcaj korelacji w przyczynowość.

Nie przypisuj producentom intencji bez dowodów.

Oddzielaj:

- udokumentowaną podatność,
- udokumentowany incydent,
- prawdopodobny mechanizm,
- rekonstrukcję,
- hipotezę architektoniczną.

Preferuj źródła pierwotne:

- dokumentację producentów,
-