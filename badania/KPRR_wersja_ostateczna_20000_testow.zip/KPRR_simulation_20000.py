#!/usr/bin/env python3
"""Reprodukcja 20 000 eksperymentów Monte Carlo KPRR."""
from pathlib import Path
import itertools
import numpy as np
import pandas as pd
from scipy.stats import beta, fisher_exact

SEED=20260805
SCENARIOS=['strong_protocol', 'weak_protocol', 'no_protocol', 'object_cue', 'position_mimicry', 'human_dependence', 'temporal_synchrony', 'no_transfer']
EDGES=['AB', 'BC_chain', 'BC_post']
CONDS=['normal1', 'normal2', 'no_signal', 'occluded', 'position', 'shifted', 'human']
N_PER_SCENARIO=2500
N_TOTAL=len(SCENARIOS)*N_PER_SCENARIO
N_CANDIDATES=[20, 30, 40, 50, 60]

def cp_interval(k,n,alpha=.05):
    lo=0.0 if k==0 else float(beta.ppf(alpha/2,k,n-k+1))
    hi=1.0 if k==n else float(beta.ppf(1-alpha/2,k+1,n-k))
    return lo,hi

def run(outdir="."):
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(SEED)
    scenario_arr=np.repeat(SCENARIOS,N_PER_SCENARIO)
    split_arr=np.tile(np.array(["cal"]*(N_PER_SCENARIO//2)+["val"]*(N_PER_SCENARIO-N_PER_SCENARIO//2)),len(SCENARIOS))
    pbase={(e,c):np.zeros(N_TOTAL) for e in EDGES for c in CONDS}
    urange=lambda lo,hi,size:rng.uniform(lo,hi,size=size)

    for scenario in SCENARIOS:
        idx=np.where(scenario_arr==scenario)[0]; m=len(idx)
        for edge in EDGES:
            if scenario=="strong_protocol": normal,ctrl=urange(.80,.95,m),(.05,.20)
            elif scenario=="weak_protocol":
                normal=urange(.55,.72,m) if edge=="BC_post" else urange(.60,.78,m); ctrl=(.15,.35)
            elif scenario=="no_protocol": normal,ctrl=urange(.10,.35,m),(.10,.35)
            elif scenario in ("object_cue","position_mimicry"): normal,ctrl=urange(.75,.92,m),(.10,.30)
            elif scenario=="human_dependence": normal,ctrl=urange(.15,.45,m),(.10,.30)
            elif scenario=="temporal_synchrony": normal,ctrl=urange(.70,.90,m),(.45,.70)
            elif scenario=="no_transfer":
                if edge=="BC_post": normal,ctrl=urange(.15,.40,m),(.10,.30)
                else: normal,ctrl=urange(.80,.95,m),(.05,.20)
            pbase[(edge,"normal1")][idx]=normal
            pbase[(edge,"normal2")][idx]=np.clip(normal+rng.normal(0,.03,m),.01,.99)
            for c in ["no_signal","occluded","position","shifted"]: pbase[(edge,c)][idx]=urange(*ctrl,m)
            pbase[(edge,"human")][idx]=np.clip(normal+rng.uniform(-.08,.08,m),.01,.99)
            if scenario=="object_cue": pbase[(edge,"occluded")][idx]=urange(.70,.90,m)
            elif scenario=="position_mimicry": pbase[(edge,"position")][idx]=urange(.70,.90,m)
            elif scenario=="human_dependence": pbase[(edge,"human")][idx]=urange(.75,.92,m)
            elif scenario=="temporal_synchrony":
                pbase[(edge,"shifted")][idx]=urange(.65,.88,m)
                pbase[(edge,"occluded")][idx]=urange(.55,.82,m)
                pbase[(edge,"position")][idx]=urange(.45,.70,m)
                pbase[(edge,"human")][idx]=np.clip(normal+rng.uniform(-.10,.10,m),.01,.99)

    sens=rng.uniform(.90,.99,N_TOTAL); spec=rng.uniform(.94,.995,N_TOTAL); kappa=rng.uniform(30,80,N_TOTAL)
    counts={n:{} for n in N_CANDIDATES}; latent={}
    for edge in EDGES:
        for cond in CONDS:
            pb=np.clip(pbase[(edge,cond)],.005,.995)
            pblock=rng.beta(pb*kappa,(1-pb)*kappa)
            pobs=pblock*sens+(1-pblock)*(1-spec); latent[(edge,cond)]=pblock
            seq=rng.random((N_TOTAL,max(N_CANDIDATES)))<pobs[:,None]; cs=np.cumsum(seq,axis=1)
            for n in N_CANDIDATES: counts[n][(edge,cond)]=cs[:,n-1].astype(np.int16)

    lookup={}
    for n in N_CANDIDATES:
        arr=np.ones((2*n+1,n+1))
        for sn in range(2*n+1):
            for sc in range(n+1):
                arr[sn,sc]=fisher_exact([[sn,2*n-sn],[sc,n-sc]],alternative="greater").pvalue
        lookup[n]=arr

    features={}
    for n in N_CANDIDATES:
        for e in EDGES:
            c=counts[n]; n1=c[(e,"normal1")].astype(float); n2=c[(e,"normal2")].astype(float)
            no=c[(e,"no_signal")].astype(float); occ=c[(e,"occluded")].astype(float)
            pos=c[(e,"position")].astype(float); shi=c[(e,"shifted")].astype(float)
            hum=c[(e,"human")].astype(float); navg=(n1+n2)/(2*n)
            features[(n,e)]={"n1":n1/n,"n2":n2/n,"no":no/n,"occ":occ/n,"pos":pos/n,
                              "shi":shi/n,"hum":hum/n,"norm_avg":navg,
                              "pval":lookup[n][(n1+n2).astype(int),no.astype(int)]}

    def edge_pass(n,e,pmin,cmax,dmin,alpha,hmax):
        f=features[(n,e)]
        return ((f["n1"]>=pmin)&(f["n2"]>=pmin)&(f["no"]<=cmax)&(f["occ"]<=cmax)&
                (f["pos"]<=cmax)&(f["shi"]<=cmax)&((f["norm_avg"]-f["no"])>=dmin)&
                ((f["norm_avg"]-f["occ"])>=dmin)&((f["norm_avg"]-f["pos"])>=dmin)&
                ((f["norm_avg"]-f["shi"])>=dmin)&(f["pval"]<alpha)&
                (np.abs(f["hum"]-f["norm_avg"])<=hmax))

    cal=split_arr=="cal"; strong=scenario_arr=="strong_protocol"; weak=scenario_arr=="weak_protocol"
    negative=~np.isin(scenario_arr,["strong_protocol","weak_protocol"])
    grid=list(itertools.product(N_CANDIDATES,[.60,.65,.70,.75],[.30,.35,.40],[.25,.30,.35,.40],[.05,.02,.01],[.20,.25,.30]))
    rows=[]; cache={}
    for params in grid:
        pred=np.ones(N_TOTAL,dtype=bool)
        for e in EDGES: pred &= edge_pass(params[0],e,*params[1:])
        cache[params]=pred
        rows.append({"n":params[0],"pmin":params[1],"cmax":params[2],"dmin":params[3],"alpha":params[4],
                      "hmax":params[5],"cal_tpr_strong":pred[cal&strong].mean(),
                      "cal_fpr_negative":pred[cal&negative].mean(),"cal_accept_weak":pred[cal&weak].mean()})
    grid_df=pd.DataFrame(rows)
    eligible=grid_df[(grid_df.alpha==.01)&(grid_df.dmin>=.30)&(grid_df.cal_tpr_strong>=.90)&(grid_df.cal_fpr_negative==0)].copy()
    eligible=eligible.sort_values(["n","dmin","cmax","pmin","hmax"],ascending=[True,False,True,False,True])
    r=eligible.iloc[0]; selected=(int(r.n),float(r.pmin),float(r.cmax),float(r.dmin),float(r.alpha),float(r.hmax))
    final=cache[selected]
    original=np.ones(N_TOTAL,dtype=bool)
    for e in EDGES: original &= edge_pass(40,e,.75,.25,.50,.01,.20)

    run_df=pd.DataFrame({"run_id":np.arange(1,N_TOTAL+1),"scenario":scenario_arr,"split":split_arr,
                         "detector_sensitivity":sens,"detector_specificity":spec,"beta_concentration":kappa,
                         "accepted_final":final.astype(int),"accepted_original":original.astype(int)})
    for e in EDGES:
        run_df[f"edge_{e}_pass"]=edge_pass(selected[0],e,*selected[1:]).astype(int)
        for c in CONDS:
            run_df[f"{e}_{c}_successes"]=counts[selected[0]][(e,c)]
            run_df[f"{e}_{c}_latent_p"]=latent[(e,c)]
    summary=[]
    for s in SCENARIOS:
        for sp in ["cal","val"]:
            mask=(scenario_arr==s)&(split_arr==sp); k=int(final[mask].sum()); n=int(mask.sum()); lo,hi=cp_interval(k,n)
            ko=int(original[mask].sum())
            summary.append({"scenario":s,"split":sp,"n":n,"accepted_final":k,"rate_final":k/n,
                            "ci95_low_final":lo,"ci95_high_final":hi,"accepted_original":ko,"rate_original":ko/n})
    run_df.to_csv(out/"KPRR_monte_carlo_20000_runs.csv",index=False)
    pd.DataFrame(summary).to_csv(out/"KPRR_monte_carlo_summary.csv",index=False)
    grid_df.to_csv(out/"KPRR_threshold_grid.csv",index=False)
    print("selected=",selected)
    print(pd.DataFrame(summary).query("split == 'val'").to_string(index=False))

if __name__=="__main__":
    run(".")
