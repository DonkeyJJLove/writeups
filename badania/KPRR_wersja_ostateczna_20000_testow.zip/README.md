# Pakiet KPRR — wersja ostateczna

Pakiet zawiera pełną dokumentację protokołu i rzeczywiste wyniki 20 000 eksperymentów Monte Carlo.

Najważniejsze wyniki:
- silny protokół, holdout: 1144/1250 = 91,52%;
- słaby protokół, holdout: 40/1250 = 3,20%;
- sześć rodzin negatywnych, holdout: 0/7500;
- 95% CI dla fałszywej akceptacji przy 0/7500: 0–0,0492%;
- wcześniejsza reguła: 179/1250 = 14,32% silnych protokołów.

To jest walidacja obliczeniowa. Nie wykonano 20 000 prób na zwierzętach.
