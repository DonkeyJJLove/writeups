# Niezależny przegląd eksperymentów uzupełniających

Przegląd objął `experiments/cascade_and_epistemic.py`, oba pliki podsumowań, surowe CSV, `experiments/process_lab.py` oraz jego sześć zapisanych wyników. Nie zmieniono tych plików ani nie powtórzono głównego benchmarku. Po znalezieniu błędu, na zlecenie autora badania wykonano osobny, jawnie post hoc kontrprzykład `process_balance_probe.py`.

## Sprawdzenie liczb

- Wszystkie **35 agregatów kaskadowych** przeliczone z 3000 zapisów CSV odpowiadają podsumowaniu dokładnie.
- Wszystkie metryki epistemiczne przeliczone z **9000 kroków** odpowiadają podsumowaniu. Niezależne odtworzenie filtrowania przez log-odds, z zapisanym ziarnem i konfiguracją, daje maksymalną różnicę posterioru **5,55 × 10⁻¹⁶**.
- W sześciu pierwotnych przypadkach procesowych zapisane operacje i salda są ze sobą zgodne, a pokazane statusy odpowiadają warunkom w kodzie. Ta zgodność konkretnych fixture nie eliminuje ujawnionej niżej luki w sprawdzaniu innych skutków.

## Istotny negatywny wynik: proces obserwatora nie wystarcza

Pierwotny verifier porównuje `observed.operations` z zatwierdzonym żądaniem oraz self-report wykonawcy z pierwszą operacją. **Nie porównuje `observed.balances` z zaufanym stanem początkowym i dozwolonym skutkiem. Pierwotny oracle `harmful_effect` także ocenia tylko log operacji.** Osobny proces czyta zatem rzeczywistą bazę, ale decyzja opiera się na logu wytwarzanym przez tego samego wykonawcę.

Zbudowany kontrprzykład wykonuje pierwotny `run_case` bez modyfikacji jego źródła. Tymczasowo opakowuje launcher procesu, aby po prawidłowym workerze osobny subprocess wykonał dodatkowy zapis sald SQLite bez dopisania transakcji. Oryginalne kod i sześć wyników zachowują identyczne SHA-256.

| Próba | Oczekiwane salda | Rzeczywiste salda | Pierwotny verifier/oracle | Nowy oracle bilansowy |
|---|---|---|---|---|
| Legalny przelew 12 | ops 988, payroll 12 | ops 988, payroll 12 | VERIFIED; szkoda false | VERIFIED; szkoda false |
| Dodatkowy nieodnotowany przelew 7 | ops 988, payroll 12 | ops 981, payroll 12, external 7 | **VERIFIED; szkoda false** | **CONTRADICTED; szkoda true** |

Suma środków w obu przypadkach nadal wynosi 1000. Sama kontrola zachowania sumy też nie wystarcza; potrzebne jest powiązanie zmiany konkretnych rachunków z zatwierdzoną operacją i zaufanym stanem odniesienia. Nowy oracle wykrywa tę konkretną niezgodność **po wykonaniu**. Nie cofa skutku i nie dowodzi kompletnej mediacji. Wynik zapisano w `experiments/process_balance_probe_results.json`, a warunki i skróty w `process_balance_probe_freeze.json`.

## Klasyfikacja wykonania procesowego

- Powstają rzeczywiste oddzielne subprocessy i wykonywane są rzeczywiste transakcje SQLite. To wykonanie laboratoryjne, nie sama symulacja mnożenia macierzy. Dane, żądania i tryby uszkodzenia pozostają syntetyczne.
- Wszystkie procesy działają na tym samym hoście, z tymi samymi uprawnieniami i wspólną bazą. `python -I` nie jest izolacją odczytu/zapisu ani zabezpieczeniem przed przejęciem hosta. Nie ma eBPF, obserwacji jądra, odmiennej domeny administracyjnej ani sprzętowego poświadczenia.
- Worker zwraca **niepodpisany JSON na stdout**. Dopiero nadrzędny verifier podpisuje agregat. Przypadek `false_self_receipt` wykrywa niezgodny self-report; nie testuje fałszywego świadectwa podpisanego własnym kluczem procesu wykonawcy.
- Brak obserwatora jest **przełącznikiem scenariusza**. W wariancie „before” harness od razu blokuje; w „after” pomija odczyt dla kontrolera, po czym evaluator nadal może odczytać bazę. Nie uruchomiono rzeczywistego health checku, timeoutu ani awarii procesu świadka.
- Kontrola dopuszczenia nie jest atomowa z transakcją. Pokazany `post_admission_drift` poprawnie ujawnia tę lukę: szkoda następuje przed wykryciem. Gotowość świadka przed startem także nie gwarantuje jego dostępności do końca operacji.
- Zintegrowany zestaw 57 testów pozostaje odrębnym licznikiem; dwie próby nowego probe nie zostały do niego dodane. Sześć pierwotnych pojedynczych prób procesowych i dwa dodatkowe przypadki nie pozwalają szacować częstości naruszeń ani niezawodności produkcyjnej. Podane czasy obejmują tworzenie bazy, start procesów i odczyt ewaluatora, dlatego nie są porównywalne z latencją kontrolera głównego benchmarku.

## Interpretacja kaskad

- Jest to dyskretny, liniowy model 18 węzłów i 18 stanów reakcji. Wszystkie wzmocnienia, osłabienia, zakresy losowania, progi i czas reakcji są założone. Nie zostały wyestymowane z realnej infrastruktury ani z wykonania MSC. W szczególności osłabienie połączeń między domenami o 90% jest narzuconym parametrem.
- Warunek `spectral_radius < 1` poprawnie opisuje asymptotyczną stabilność **stałej macierzy po interwencji**. Nie jest sam w sobie gwarancją bezpieczeństwa przy arbitralnym przełączaniu, opóźnieniach, nasyceniach, przeciążeniu kolejek czy nieliniowej dynamice. Zawarty przykład dwóch stabilnych macierzy z niestabilnym iloczynem poprawnie ilustruje ten problem.
- „Opanowanie do horyzontu” oznacza spadek obserwowanej części `x` poniżej progu przez pozostałe kroki do 35. Nie oznacza nieograniczonego czasowo opanowania, a ukryty stan reakcji `q` nie jest objęty tym progiem.
- **Wariant lokalny nie dominuje wariantu wspólnego przy wyrównanych parametrach.** Stabilność `federated_bounded` wynosi 577/600 = 96,167%, a `shared_bounded_matched` 584/600 = 97,333%. Siedem par jest stabilnych wyłącznie we wariancie wspólnym; żadna wyłącznie w lokalnym. Wariant lokalny ma natomiast przeciętnie o 0,438 węzła mniej ponad przyjętym progiem. To kompromis właściwości w tej parametryzacji, nie uniwersalna przewaga topologii.
- Ilustracja destabilizującej ochrony zmienia równocześnie tłumienie i kilka wzmocnień sprzężenia. Jest poprawnym kontrprzykładem istnienia destabilizacji, ale nie pomiarem efektu jednej rzeczywistej polityki bezpieczeństwa.
- Korelacje z promieniem spektralnym są opisem przyjętego losowania, nie estymacją przyczynowego wpływu parametrów w sieci. Liczby „stable_fraction” są częstościami w tej próbie modeli, a nie prawdopodobieństwami awarii świata rzeczywistego.

## Interpretacja modelu epistemicznego

- Wynik potwierdza w kontrolowanym HMM, że pięciokrotne liczenie jednego świadectwa prowadzi do nadmiernej pewności. Brier spada z 0,098985 do 0,033717 po uwzględnieniu wspólnego pochodzenia. Dla pięciu faktycznie niezależnych sensorów wynosi 0,003074.
- Niezależność sensorów, dokładność 0,9, wspólne pochodzenie kopii i prawidłowy model przejść są znane z konstrukcji generatora. Nie zbadano wykrywania nieznanych zależności, kalibracji rzeczywistych sensorów, fałszowania pochodzenia ani zmiany rozkładu.
- Pięć niezależnych sensorów ma większy rzeczywisty budżet informacyjny niż jeden sensor skopiowany pięć razy. Wynik pokazuje wartość dodatkowej informacji i poprawnego rachunku zależności, nie bezkosztową przewagę pięciu podpisów.
- Część parametrów HMM w implementacji jest wpisana jako literały mimo obecności słownika `conf`. Aktualne wartości zgadzają się z raportem. Zmiana samej konfiguracji nie musi jednak zmienić wszystkich kroków generatora; przed dalszą analizą wrażliwości trzeba ujednolicić parametryzację.

**Ocena końcowa przeglądu:** obliczenia podsumowań są poprawne, a odróżnienie symulacji od rzeczywistych subprocessów jest zasadne. Najważniejszy nowy wynik to wykazany błąd polegania na logu mimo dostępności rzeczywistych sald. Wzmacnia on potrzebę niezależnego semantycznie i stanowo świadectwa skutku, jednocześnie falsyfikując wystarczalność samego rozdzielenia procesów w przedstawionym pierwszym suplemencie.
