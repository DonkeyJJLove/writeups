"""Signed execution/source provenance cross-binding, outside the frozen M0–M8 benchmark."""
from pathlib import Path
import hashlib
from msc import digest, issue_event, verify_event


def source_inventory(source_root=None):
    root = Path(source_root) if source_root is not None else Path(__file__).resolve().parents[1]
    return {'schema': 'msc-source-inventory-v1', 'kind': 'source-files',
            'files': {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in sorted(root.rglob('*.py')) if p.is_file()},
            'hardware_attestation': {'status': 'UNKNOWN', 'reason': 'No hardware measurement was acquired'}}


def _payload(public, receipts, inventory):
    events = public.get('events', [])
    return {'schema': 'msc-meta-binding-v1', 'software_inventory': inventory,
            'software_inventory_digest': digest(inventory),
            'event_root': digest([e.get('digest') for e in events]),
            'receipt_root': digest([e.get('digest') for e in receipts]),
            'decision_root': digest([e.get('digest') for e in events if e.get('kind') == 'decision']),
            'request_digest': digest(public.get('request', {})),
            'context_digest': digest(public.get('context', {})),
            'authorization_digest': digest(public.get('authorization', {})),
            'hardware_status': 'UNKNOWN',
            'claim_scope': 'Source-file inventory bound to supplied execution records; not measured execution or hardware attestation'}


def create_meta_binding(public, receipts, inventory=None):
    inventory = source_inventory() if inventory is None else inventory
    return issue_event({'id': str(public.get('request', {}).get('id', 'unknown')) + ':meta-binding',
                        'kind': 'meta_attestation', 'role': 'verifier', 'step': 102,
                        'parents': [r.get('digest') for r in receipts], 'roots': ['verifier:synthetic'],
                        'taint': 'observed', 'label': 'meta-bom-link',
                        'body': _payload(public, receipts, inventory)})


def verify_meta_binding(binding, public, receipts, inventory=None):
    """Checks signed binding against independently supplied current bytes and records."""
    inventory = source_inventory() if inventory is None else inventory
    errors = []
    if binding.get('role') != 'verifier' or binding.get('kind') != 'meta_attestation' or not verify_event(binding):
        errors.append('META_SIGNATURE_OR_ROLE')
    if any(not verify_event(e) for e in list(public.get('events', [])) + list(receipts)):
        errors.append('BOUND_RECORD_SIGNATURE')
    expected = _payload(public, receipts, inventory)
    if binding.get('body') != expected:
        errors.append('META_BINDING_MISMATCH')
    if binding.get('parents') != [r.get('digest') for r in receipts]:
        errors.append('META_PARENT_MISMATCH')
    return {'status': 'CONTRADICTED' if errors else 'VERIFIED', 'errors': errors,
            'hardware_status': 'UNKNOWN', 'scope': 'source-and-record-integrity-only',
            'production_key_security': 'NOT_ASSESSED_PUBLIC_TEST_KEYS'}
