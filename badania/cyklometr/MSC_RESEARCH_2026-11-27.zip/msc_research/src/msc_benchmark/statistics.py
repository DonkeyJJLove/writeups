"""Small, reproducible statistics helpers; no detector implementation imports."""
from __future__ import annotations
import math
from statistics import NormalDist
import numpy as np
from scipy.stats import binomtest


def wilson(successes: int, trials: int, confidence: float = 0.95):
    if not trials:
        return [None, None]
    z = NormalDist().inv_cdf(0.5 + confidence / 2)
    p = successes / trials
    den = 1 + z*z / trials
    center = (p + z*z / (2*trials)) / den
    delta = z * math.sqrt(p*(1-p)/trials + z*z/(4*trials*trials)) / den
    return [max(0.0, center-delta), min(1.0, center+delta)]


def percentile(values, q):
    return float(np.percentile(values, q)) if values else None


def cluster_bootstrap(values: list[dict], key: str, seed: int, reps: int = 2000):
    """Two-way crossed bootstrap over family and seed.

    Each observation belongs to a family x seed cell. Resample the family and
    seed levels independently and retain every existing cell's mean. This is
    uncertainty over this hand-designed scenario mixture, not the Internet.
    """
    if not values:
        return [None, None]
    families = sorted({v['family'] for v in values})
    seeds = sorted({v['seed'] for v in values})
    table = np.full((len(families), len(seeds)), np.nan)
    for i, family in enumerate(families):
        for j, runseed in enumerate(seeds):
            cell = [float(v[key]) for v in values if v['family'] == family and v['seed'] == runseed]
            if cell:
                table[i,j] = np.mean(cell)
    rng = np.random.default_rng(seed)
    draws = []
    for _ in range(reps):
        fi = rng.integers(0, len(families), len(families))
        sj = rng.integers(0, len(seeds), len(seeds))
        block = table[np.ix_(fi,sj)]
        if np.isfinite(block).any():
            draws.append(float(np.nanmean(block)))
    return [float(x) for x in np.percentile(draws,[2.5,97.5])]


def paired_mcnemar(left: list[bool], right: list[bool]):
    if len(left) != len(right):
        raise ValueError('paired observations required')
    b = sum(bool(a) and not bool(c) for a,c in zip(left,right))
    c = sum(not bool(a) and bool(d) for a,d in zip(left,right))
    return {'left_only':b,'right_only':c,'discordant':b+c,
            'exact_p':float(binomtest(min(b,c),b+c,0.5).pvalue) if b+c else 1.0,
            'warning':'Naive case-level exact test; repeated templates are not independent external attacks.'}


def design_power(delta=0.10, discordance=0.20, alpha=0.05, power=0.80):
    za=NormalDist().inv_cdf(1-alpha/2)
    zb=NormalDist().inv_cdf(power)
    n=math.ceil(((za*math.sqrt(discordance)+zb*math.sqrt(max(0,discordance-delta*delta)))/delta)**2)
    return {'target_difference':delta,'assumed_paired_discordance':discordance,
            'alpha':alpha,'power':power,'approximate_independent_pairs_required':n,
            'worst_case_binomial_n_for_3pp_half_width':math.ceil(za*za*0.25/(0.03**2)),
            'qualification':'Design calculation only. No guarantee under family clustering or model mismatch.'}
