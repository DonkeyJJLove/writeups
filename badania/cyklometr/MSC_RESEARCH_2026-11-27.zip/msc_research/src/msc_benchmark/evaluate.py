"""Run immutable inputs through the public MSC API and score actual ledger effects."""
from __future__ import annotations
import copy
import csv
import gzip
import hashlib
import json
import platform
import random
import sys
import time
from datetime import datetime,timezone
from pathlib import Path
from statistics import mean
from msc import evaluate
from .statistics import wilson,cluster_bootstrap,paired_mcnemar,design_power,percentile

ALL_LAYERS=['rbac','schema','semantic_proxy','control_flow','crypto','typed_invariants','reconstruction']
MODEL_CONFIGS=[(f'M{i}',None) for i in range(9)]+[(f'M7_without_{layer}',[x for x in ALL_LAYERS if x!=layer]) for layer in ALL_LAYERS]


def hash_file(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text(encoding='utf-8').splitlines() if line]


def oracle(effect,truth):
    """Uses committed operation and an independent normative/ownership world.

    `malicious` labels are deliberately not read here. The same exact operation
    can be safe or harmful under different hidden beneficial-account ownership.
    """
    operations=effect.get('operations',[])
    if not operations:
        return {'harm':False,'task_succeeded':False,'reasons':['no_commit']}
    reasons=[]
    if effect.get('total_debit',0)>truth['allowed_total']: reasons.append('total_budget')
    for operation in operations:
        target=operation['target']
        if target!=truth['expected_target']: reasons.append('target')
        if truth['account_owners'].get(target,'unknown')!=truth['authorized_owner']: reasons.append('beneficial_owner')
        if operation.get('purpose')!=truth['expected_purpose']: reasons.append('purpose')
        if operation.get('source')!='ops': reasons.append('source')
    correct_amount=effect.get('total_debit')==truth['expected_amount']
    return {'harm':bool(reasons),'task_succeeded':not reasons and correct_amount,
            'reasons':sorted(set(reasons))}


def ensure_no_truth(case):
    if set(case)!= {'public','runtime'}:
        raise ValueError('Only the API case may enter the controller')
    forbidden={'malicious','is_attack','family','expected_target','expected_amount','account_owners','ground_truth','violation_locations','unseen_family'}
    def check(x):
        if isinstance(x,dict):
            if forbidden.intersection(x): raise ValueError('Evaluator truth leaked into controller input')
            for v in x.values(): check(v)
        elif isinstance(x,list):
            for v in x: check(v)
    check(case)


def score(truth, result, wall_ms,cpu_ms,model):
    status=result['status']; detection=status=='CONTRADICTED'
    effect=result.get('actual_effect',{})
    observed=oracle(effect,truth)
    goldloc=set(truth['violation_locations'])
    locations=set(result.get('locations',[]))
    overlap=bool(goldloc&locations)
    reconstruction=result.get('reconstruction') or {}
    rec_effect=reconstruction.get('effect')
    rec_available=rec_effect is not None
    rec_correct=rec_available and rec_effect==effect
    row={
        'id':truth['id'],'split':truth['split'],'seed':truth['seed'],'family':truth['family'],
        'malicious':truth['malicious'],'unseen_family':truth['unseen_family'],'model':model,
        'allowed_pre':bool(result['allowed_pre']), 'executed':bool(result['executed']),
        'committed_count':result.get('committed_count',len(effect.get('operations',[]))),
        'status':status,'detected':detection,'unknown':status=='UNKNOWN',
        'harmful_effect':observed['harm'],'task_succeeded':observed['task_succeeded'],
        'unjustified_pre_authorization':bool(truth['malicious'] and result['allowed_pre']),
        'localizable':bool(goldloc),'localized':detection and overlap,
        'localization_exact':detection and bool(goldloc) and locations==goldloc,
        'localization_precision':len(goldloc&locations)/len(locations) if locations else None,
        'reconstruction_available':rec_available,'reconstruction_effect_correct':rec_correct,
        'falsely_verified_harm':status=='VERIFIED' and observed['harm'],
        'wall_ms':wall_ms,'cpu_ms':cpu_ms,'oracle_reasons':observed['reasons'],
        'result':result,
    }
    return row


def summarize(rows,cluster_seed=6100):
    out=[]
    for model,_ in MODEL_CONFIGS:
        rr=[r for r in rows if r['model']==model]
        if not rr: continue
        atk=[r for r in rr if r['malicious']]; ben=[r for r in rr if not r['malicious']]
        tp=sum(r['detected'] for r in atk); fp=sum(r['detected'] for r in ben)
        fn=len(atk)-tp; tn=len(ben)-fp
        successful=sum(r['harmful_effect'] for r in atk)
        precision=tp/(tp+fp) if tp+fp else 0.0
        recall=tp/len(atk) if atk else 0.0
        f1=2*precision*recall/(precision+recall) if precision+recall else 0.0
        loc=[r for r in atk if r['localizable']]
        detected_loc=[r for r in loc if r['detected']]
        executed=[r for r in rr if r['executed']]
        rec=[r for r in executed if r['reconstruction_available']]
        family={}
        for fam in sorted({r['family'] for r in rr}):
            fr=[r for r in rr if r['family']==fam]
            family[fam]={'n':len(fr),'harm':sum(r['harmful_effect'] for r in fr),
                         'detected':sum(r['detected'] for r in fr),
                         'unknown':sum(r['unknown'] for r in fr),
                         'completed':sum(r['task_succeeded'] for r in fr)}
        unseen=[r for r in atk if r['unseen_family']]
        d={
            'model':model,'n_attack':len(atk),'n_benign':len(ben),'attack_successes':successful,
            'ASR':successful/len(atk) if atk else None,
            'ASR_wilson95':wilson(successful,len(atk)),
            'ASR_family_seed_bootstrap95':cluster_bootstrap(atk,'harmful_effect',cluster_seed),
            'TP':tp,'FP':fp,'TN':tn,'FN':fn,'TPR':recall,
            'FPR':fp/len(ben) if ben else None,'FNR':fn/len(atk) if atk else None,
            'FPR_wilson95':wilson(fp,len(ben)),
            'precision':precision,'recall':recall,'F1':f1,
            'benign_task_success':mean(r['task_succeeded'] for r in ben) if ben else None,
            'unknown_fraction':mean(r['unknown'] for r in rr),
            'unknown_attack_fraction':mean(r['unknown'] for r in atk) if atk else None,
            'unknown_benign_fraction':mean(r['unknown'] for r in ben) if ben else None,
            'unjustified_pre_authorization':mean(r['allowed_pre'] for r in atk) if atk else None,
            'localization_end_to_end':sum(r['localized'] for r in loc)/len(loc) if loc else None,
            'localization_given_detection':sum(r['localized'] for r in detected_loc)/len(detected_loc) if detected_loc else None,
            'localization_exact_end_to_end':sum(r['localization_exact'] for r in loc)/len(loc) if loc else None,
            'reconstruction_effect_coverage_executed':len(rec)/len(executed) if executed else None,
            'reconstruction_effect_accuracy_available':mean(r['reconstruction_effect_correct'] for r in rec) if rec else None,
            'full_latent_trajectory_accuracy':None,
            'falsely_verified_harm':sum(r['falsely_verified_harm'] for r in atk),
            'unseen_attack_n':len(unseen),
            'unseen_ASR':mean(r['harmful_effect'] for r in unseen) if unseen else None,
            'unseen_TPR':mean(r['detected'] for r in unseen) if unseen else None,
            'wall_median_ms':percentile([r['wall_ms'] for r in rr],50),
            'wall_p95_ms':percentile([r['wall_ms'] for r in rr],95),
            'cpu_median_ms':percentile([r['cpu_ms'] for r in rr],50),
            'mean_commits_attack':mean(r['committed_count'] for r in atk) if atk else None,
            'energy_joules':None,'per_family':family,
        }
        out.append(d)
    return out


def manifest(root):
    paths=list((root/'src'/'msc').glob('*.py'))+list((root/'src'/'msc_benchmark').glob('*.py'))
    return {str(p.relative_to(root)):hash_file(p) for p in sorted(paths)}


def run(root):
    root=Path(root); exp=root/'experiments'; data=exp/'dataset'
    exp.mkdir(parents=True,exist_ok=True)
    initial=manifest(root)
    freeze={'utc':datetime.now(timezone.utc).isoformat(),'code_sha256':initial,
            'dataset_manifest_sha256':hash_file(data/'DATASET_MANIFEST.json'),
            'models':[m for m,_ in MODEL_CONFIGS],
            'blindness':'procedural separation in one shared workspace; not an independent external blinded audit'}
    (exp/'BENCHMARK_FREEZE.json').write_text(json.dumps(freeze,indent=2),encoding='utf-8')
    rng=random.Random(80127001)
    summaries={}; test_rows=[]; wall_start=time.perf_counter()
    for split in ['design','validation','test']:
        inputs=read_jsonl(data/f'{split}_inputs.jsonl')
        labels={t['id']:t for t in read_jsonl(data/f'{split}_evaluator_truth.jsonl')}
        rows=[]
        with gzip.open(exp/f'{split}_raw_results.jsonl.gz','wt',encoding='utf-8') as raw:
            for index,item in enumerate(inputs):
                ensure_no_truth(item['case'])
                order=list(MODEL_CONFIGS); rng.shuffle(order)
                for model,layers in order:
                    case=copy.deepcopy(item['case'])
                    cpu=time.process_time_ns(); wall=time.perf_counter_ns()
                    result=evaluate(case,model=model if layers is None else 'M7',layers=layers)
                    wall_ms=(time.perf_counter_ns()-wall)/1e6; cpu_ms=(time.process_time_ns()-cpu)/1e6
                    row=score(labels[item['id']],result,wall_ms,cpu_ms,model)
                    raw.write(json.dumps(row,ensure_ascii=False,sort_keys=True)+'\n')
                    rows.append(row)
                if (index+1)%200==0:
                    print(json.dumps({'split':split,'cases_done':index+1,'total':len(inputs)}),flush=True)
        summaries[split]=summarize(rows,cluster_seed=6100+len(split))
        if split=='test': test_rows=rows
        print(json.dumps({'split':split,'complete':len(inputs)}),flush=True)
    if manifest(root)!=initial:
        raise RuntimeError('Controller or generator code changed during frozen evaluation')
    bymodel={model:{r['id']:r for r in test_rows if r['model']==model} for model,_ in MODEL_CONFIGS}
    comparisons=[]
    for a,b in [('M0','M7'),('M1','M7'),('M5','M7'),('M6','M7'),('M7','M8')]:
        ids=sorted(k for k,v in bymodel[a].items() if v['malicious'])
        left=[bymodel[a][k]['harmful_effect'] for k in ids]; right=[bymodel[b][k]['harmful_effect'] for k in ids]
        diff=[{**bymodel[a][k],'asr_reduction':int(bymodel[a][k]['harmful_effect'])-int(bymodel[b][k]['harmful_effect'])} for k in ids]
        comparisons.append({'left':a,'right':b,'ASR_reduction':mean(diffrow['asr_reduction'] for diffrow in diff),
                            'paired_family_seed_bootstrap95':cluster_bootstrap(diff,'asr_reduction',9112),
                            **paired_mcnemar(left,right)})
    pair=json.loads((data/'equivalence_pair.json').read_text())
    pair_results=[]
    for model,layers in MODEL_CONFIGS[:9]:
        result=evaluate(copy.deepcopy(pair['case']),model=model)
        pair_results.append({'model':model,'input_sha256':pair['input_sha256'],'status':result['status'],
                             'safe_world':oracle(result['actual_effect'],pair['safe_world']),
                             'unsafe_world':oracle(result['actual_effect'],pair['unsafe_world']),
                             'same_controller_output_by_construction':True})
    (exp/'equivalence_results.json').write_text(json.dumps(pair_results,indent=2,ensure_ascii=False),encoding='utf-8')
    report={'format':'msc-benchmark-v1','claim_scope':'executed synthetic Python ledger/controllers; no LLM/API/live attack benchmark',
            'environment':{'python':sys.version,'platform':platform.platform()},
            'elapsed_wall_s':time.perf_counter()-wall_start,
            'freeze':freeze,'power_design':design_power(),'paired_comparisons':comparisons,
            'metrics_notes':{
                'ASR':'malicious attempts producing unauthorized committed ledger effect divided by malicious attempts',
                'detection':'status CONTRADICTED; UNKNOWN is not a detected attack',
                'FNR':'1-TPR includes UNKNOWN and falsely VERIFIED attacks; not selective FNR',
                'false_positive':'benign case marked CONTRADICTED, even if effect already safely completed',
                'unknown':'epistemic abstention, reported separately from actual effect and completion',
                'reconstruction':'effect equality against independent toy ledger, never calibrated hidden-state accuracy',
                'timing':'interleaved random model order; Python process CPU/wall, includes synthetic signing+execution; no network/LLM latency',
                'confidence':'Wilson conditional on sample independence; crossed family×seed bootstrap is primary scenario-mixture uncertainty',
                'negative_results':'hidden trusted-source and ownership cases retained; no tuning on test labels',
                'nulls':'unmeasured, not zero',
            },'splits':summaries,'observational_equivalence':pair_results}
    (root/'BENCHMARK_RESULTS.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    scalar_keys=[k for k,v in summaries['test'][0].items() if not isinstance(v,(dict,list))]
    with (root/'BENCHMARK_RESULTS.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=scalar_keys); writer.writeheader()
        writer.writerows({k:v for k,v in row.items() if k in scalar_keys} for row in summaries['test'])
    (exp/'RUN_COMPLETE.json').write_text(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),
        'code_unchanged':True,'test_inputs':len(bymodel['M0']),'test_evaluations':len(test_rows),
        'all_evaluations':sum((x[0]['n_attack']+x[0]['n_benign'])*len(x) for x in summaries.values())},indent=2),encoding='utf-8')
    print(json.dumps({'complete':True,'elapsed_s':report['elapsed_wall_s'],'test_evaluations':len(test_rows)}),flush=True)
    return report

if __name__=='__main__':
    run(sys.argv[1] if len(sys.argv)>1 else '.')
