"""Independent synthetic MSC benchmark: labels stay in evaluator code/data."""
