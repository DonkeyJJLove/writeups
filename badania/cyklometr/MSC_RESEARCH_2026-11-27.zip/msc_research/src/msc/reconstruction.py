"""Independent effect reconciliation and explicit illustrative Bayesian abduction."""
import copy
from .crypto import digest, verify_event
from .controller import alert
from .executor import effect_for_operations

HYPOTHESES = ('consistent', 'self_fault', 'host_fault', 'common_fault')
PRIORS = dict(zip(HYPOTHESES, (0.85, 0.08, 0.05, 0.02)))
LIKELIHOODS = {
    'agree': dict(zip(HYPOTHESES, (0.98, 0.05, 0.05, 0.90))),
    'disagree': dict(zip(HYPOTHESES, (0.02, 0.95, 0.95, 0.10))),
    'missing': dict(zip(HYPOTHESES, (0.20, 0.40, 0.60, 0.40))),
}


def posterior(observation, priors=None):
    """Numbers are synthetic assumptions, not fitted probabilities of real compromise."""
    priors = priors or PRIORS
    weights = {h: priors[h] * LIKELIHOODS[observation][h] for h in HYPOTHESES}
    norm = sum(weights.values())
    return {h: weights[h] / norm for h in HYPOTHESES}


def reconstruct(public, receipts, keyring):
    alerts = []
    selfs = [r for r in receipts if r.get('kind') == 'execution' and r.get('role') == 'executor']
    hosts = [r for r in receipts if r.get('kind') == 'evidence' and r.get('role') == 'host']
    result = {'effect': None, 'independent': False,
              'observed_trajectory': [r.get('kind') for r in receipts],
              'claimed_event_trajectory': [e.get('kind') for e in public.get('events', [])],
              'posterior': {}, 'coverage': 'synthetic-ledger-only'}
    if len(selfs) != 1 or len(hosts) != 1:
        result['posterior'] = posterior('missing')
        return {'status': 'UNKNOWN', 'alerts': [alert('MISSING_OBSERVATION', 'EFFECT→EVIDENCE', phase='postflight')], 'reconstruction': result}
    s, h = selfs[0], hosts[0]
    if not verify_event(s, keyring) or not verify_event(h, keyring):
        return {'status': 'CONTRADICTED', 'alerts': [alert('INVALID_RECEIPT', 'EFFECT→EVIDENCE', phase='postflight')], 'reconstruction': result}
    result['effect'] = copy.deepcopy(h.get('body', {}).get('effect'))
    self_roots, host_roots = set(s.get('roots', [])), set(h.get('roots', []))
    # Explicit root ancestry, not a count of distinct signing keys, defines independence.
    independent = bool(self_roots and host_roots and not self_roots.intersection(host_roots))
    result['independent'] = independent
    agree = s.get('body', {}).get('effect') == h.get('body', {}).get('effect')
    result['posterior'] = posterior('agree' if agree else 'disagree')
    if not independent:
        return {'status': 'UNKNOWN', 'alerts': [alert('COMMON_EVIDENCE_ROOT', 'EFFECT→EVIDENCE', phase='postflight')], 'reconstruction': result}
    if not agree:
        alerts.append(alert('SELF_HOST_CONTRADICTION', 'EXECUTION→EFFECT', phase='postflight'))
    expected = effect_for_operations([public['request']])
    if h.get('body', {}).get('effect') != expected:
        alerts.append(alert('EFFECT_REQUEST_DIVERGENCE', 'TOOL→EXECUTION', phase='postflight'))
    for r in (s, h):
        if r.get('body', {}).get('request_digest') != digest(public['request']):
            alerts.append(alert('RECEIPT_REQUEST_BINDING', 'EFFECT→EVIDENCE', phase='postflight'))
        if r.get('body', {}).get('snapshot_version') != public['authorization'].get('snapshot_version'):
            alerts.append(alert('RECEIPT_STATE_DIVERGENCE', 'EXECUTION→EFFECT', phase='postflight'))
    return {'status': 'CONTRADICTED' if alerts else 'VERIFIED', 'alerts': alerts, 'reconstruction': result}
