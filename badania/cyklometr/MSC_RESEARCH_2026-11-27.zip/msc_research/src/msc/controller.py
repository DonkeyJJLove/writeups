"""Boundary controller over public claims. Does not access experiment labels or truth."""
import copy
import re
from .crypto import digest, verify_event, default_keyring
from .fixtures import STAGES, STAGE_ROLES
from .graph import has_path

ALL_LAYERS = frozenset(('rbac', 'schema', 'semantic_proxy', 'control_flow', 'crypto', 'typed_invariants', 'reconstruction', 'containment'))
BASE = frozenset(('rbac', 'schema'))
MODEL_LAYERS = {
    'M0': frozenset(('rbac',)), 'M1': BASE,
    'M2': BASE | {'semantic_proxy'}, 'M3': BASE | {'control_flow'},
    'M4': BASE | {'crypto'}, 'M5': BASE | {'typed_invariants'},
    'M6': BASE | {'reconstruction'}, 'M7': ALL_LAYERS - {'containment'}, 'M8': ALL_LAYERS,
}
INTERFACES = ('SOURCE→DATA', 'DATA→CONTEXT', 'CONTEXT→INTERPRETATION', 'INTERPRETATION→AUTHORITY',
              'AUTHORITY→DECISION', 'DECISION→TOOL', 'TOOL→EXECUTION', 'EXECUTION→EFFECT', 'EFFECT→EVIDENCE')


def alert(code, location, detail='', phase='preflight'):
    return {'code': code, 'location': location, 'phase': phase, 'detail': detail}


def _is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def _subset(values, parent):
    return isinstance(values, list) and isinstance(parent, list) and set(values).issubset(parent)


class AuthorizationRegistry:
    """In-memory toy registry. Persistence and cross-process linearizability are out of scope."""
    def __init__(self):
        self.used = set()
        self.mandates = {}

    def register(self, mandate):
        key = digest(mandate)
        self.mandates[key] = copy.deepcopy(mandate)
        return key

    def consume(self, nonce):
        if nonce in self.used:
            return False
        self.used.add(nonce)
        return True


class Controller:
    def __init__(self, model='M7', layers=None, keyring=None):
        self.model = model
        self.layers = frozenset(MODEL_LAYERS[model] if layers is None else layers)
        if not self.layers.issubset(ALL_LAYERS):
            raise ValueError('Unknown layer')
        self.keyring = keyring or default_keyring()
        self.registry = AuthorizationRegistry()

    def preflight(self, public):
        alerts = []
        try:
            q, c, p, a = (public[k] for k in ('request', 'context', 'plan', 'authorization'))
            events = public.get('events', [])
            if not all(isinstance(x, dict) for x in (q, c, p, a)) or not isinstance(events, list):
                raise TypeError('Invalid containers')
            if 'rbac' in self.layers and (q.get('actor') != 'executor' or q.get('action') != 'transfer'):
                alerts.append(alert('RBAC', 'DECISION→TOOL', 'Actor or action absent from local ACL'))
            if 'schema' in self.layers:
                required_strings = ('id', 'actor', 'action', 'source', 'target', 'currency', 'purpose')
                if any(not isinstance(q.get(k), str) or not q[k] for k in required_strings):
                    alerts.append(alert('SCHEMA_STRING', 'CONTEXT→INTERPRETATION'))
                if not _is_int(q.get('amount')) or q['amount'] <= 0:
                    alerts.append(alert('SCHEMA_AMOUNT', 'CONTEXT→INTERPRETATION'))
                if not _is_int(q.get('snapshot_version')) or q.get('currency') != 'PLN':
                    alerts.append(alert('SCHEMA_VERSION_CURRENCY', 'CONTEXT→INTERPRETATION'))
            if 'semantic_proxy' in self.layers:
                # Deliberately simple, documented baseline; legitimate quotations can trigger it.
                text = str(c.get('source_text', '')) + ' ' + str(c.get('user_goal', ''))
                if re.search(r'ignore\s+(all\s+|previous\s+)?instructions|system\s+override|bypass\s+authori[sz]ation|reveal\s+secrets', text, re.I):
                    alerts.append(alert('LEXICAL_INJECTION_PROXY', 'SOURCE→DATA', 'Uncalibrated keyword heuristic'))
            if 'control_flow' in self.layers:
                alerts += self._flow(events)
            if 'crypto' in self.layers:
                alerts += self._crypto(events)
            if 'typed_invariants' in self.layers:
                alerts += self._invariants(q, c, p, a, events)
        except (KeyError, TypeError, ValueError, AttributeError, OverflowError) as error:
            return {'allow': False, 'status': 'UNKNOWN', 'alerts': alerts + [alert('INSUFFICIENT_PUBLIC_RECORD', 'DATA→CONTEXT', type(error).__name__)],
                    'locations': sorted({x['location'] for x in alerts} | {'DATA→CONTEXT'})}
        return {'allow': not alerts, 'status': 'CONTRADICTED' if alerts else 'VERIFIED', 'alerts': alerts,
                'locations': sorted({x['location'] for x in alerts})}

    def _flow(self, events):
        alerts, by_kind, by_hash = [], {}, {}
        for e in events:
            by_kind.setdefault(e.get('kind'), []).append(e)
            by_hash[e.get('digest')] = e
        if len({e.get('id') for e in events}) != len(events) or len(by_hash) != len(events):
            alerts.append(alert('FLOW_DUPLICATE', 'AUTHORITY→DECISION'))
        for i, stage in enumerate(STAGES):
            group = by_kind.get(stage, [])
            if len(group) != 1:
                alerts.append(alert('FLOW_MISSING_OR_DUPLICATE_' + stage.upper(), INTERFACES[min(i, 5)]))
            elif group[0].get('role') != STAGE_ROLES[stage]:
                alerts.append(alert('ROLE_SEPARATION', INTERFACES[min(i, 5)]))
        for e in events:
            for ph in e.get('parents', []):
                parent = by_hash.get(ph)
                if parent is None or not _is_int(parent.get('step')) or not _is_int(e.get('step')) or parent['step'] >= e['step']:
                    alerts.append(alert('FLOW_CAUSAL_ORDER', 'AUTHORITY→DECISION'))
        for left, right in zip(STAGES, STAGES[1:]):
            if len(by_kind.get(left, [])) == len(by_kind.get(right, [])) == 1:
                if not has_path(events, by_kind[left][0].get('digest'), by_kind[right][0].get('digest')):
                    alerts.append(alert('FLOW_REQUIRED_EDGE', INTERFACES[min(STAGES.index(left), 5)]))
        return alerts

    def _crypto(self, events):
        alerts = []
        hashes = {e.get('digest') for e in events}
        if not events:
            return [alert('PROVENANCE_EMPTY', 'SOURCE→DATA')]
        for e in events:
            if not verify_event(e, self.keyring):
                alerts.append(alert('INVALID_ATTESTATION', 'EFFECT→EVIDENCE', str(e.get('kind'))))
            if any(parent not in hashes for parent in e.get('parents', [])):
                alerts.append(alert('BROKEN_PARENT_LINK', 'DATA→CONTEXT'))
            if e.get('kind') != 'source' and not e.get('parents'):
                alerts.append(alert('UNANCHORED_PROVENANCE', 'DATA→CONTEXT'))
        return alerts

    def _invariants(self, q, c, p, a, events):
        alerts = []
        if q != p:
            alerts.append(alert('PLAN_REQUEST_DIVERGENCE', 'DECISION→TOOL'))
        if a.get('request_digest') != digest(q):
            alerts.append(alert('UNBOUND_REQUEST', 'AUTHORITY→DECISION'))
        if a.get('context_digest') != digest(c):
            alerts.append(alert('UNBOUND_CONTEXT', 'CONTEXT→INTERPRETATION'))
        if q.get('snapshot_version') != a.get('snapshot_version') or a.get('snapshot_version') != c.get('snapshot_version'):
            alerts.append(alert('SNAPSHOT_BINDING', 'DECISION→TOOL'))
        if a.get('issuer') != 'authorizer' or a.get('subject') != q.get('actor') or a.get('issuer') == a.get('subject'):
            alerts.append(alert('MANDATE_IDENTITY', 'INTERPRETATION→AUTHORITY'))
        if q.get('action') not in a.get('actions', []):
            alerts.append(alert('SCOPE_ACTION', 'AUTHORITY→DECISION'))
        if q.get('target') not in a.get('targets', []) or q.get('target') not in c.get('allowed_targets', []):
            alerts.append(alert('SCOPE_TARGET', 'AUTHORITY→DECISION'))
        if not _is_int(a.get('max_amount')) or not _is_int(c.get('max_amount')) or not _is_int(q.get('amount')):
            alerts.append(alert('SCOPE_AMOUNT_TYPE', 'AUTHORITY→DECISION'))
        elif not (0 < q['amount'] <= a['max_amount'] <= c['max_amount']):
            alerts.append(alert('SCOPE_BUDGET', 'AUTHORITY→DECISION'))
        if q.get('purpose') not in a.get('purposes', []) or q.get('purpose') != c.get('purpose'):
            alerts.append(alert('SCOPE_PURPOSE', 'CONTEXT→INTERPRETATION'))
        if q.get('source') != 'ops':
            alerts.append(alert('SCOPE_SOURCE', 'AUTHORITY→DECISION'))
        roots = c.get('source_roots', [])
        trusted = c.get('trusted_roots', [])
        if not roots or not _subset(roots, trusted) or not _subset(roots, a.get('approved_source_roots', [])):
            alerts.append(alert('DATA_TO_AUTHORITY_UPLIFT', 'INTERPRETATION→AUTHORITY'))
        previous_scope = a
        previous_principal = a.get('issuer')
        delegations = a.get('delegations', [])
        for d in delegations:
            if d.get('from') != previous_principal or not isinstance(d.get('to'), str):
                alerts.append(alert('DELEGATION_CHAIN', 'INTERPRETATION→AUTHORITY'))
            if any(not _subset(d.get(field), previous_scope.get(field)) for field in ('actions', 'targets', 'purposes')):
                alerts.append(alert('DELEGATION_EXPANSION', 'INTERPRETATION→AUTHORITY'))
            if not _is_int(d.get('max_amount')) or d['max_amount'] > previous_scope.get('max_amount', -1):
                alerts.append(alert('DELEGATION_BUDGET', 'INTERPRETATION→AUTHORITY'))
            previous_scope, previous_principal = d, d.get('to')
        if delegations:
            if previous_principal != a.get('subject'):
                alerts.append(alert('DELEGATION_SUBJECT', 'INTERPRETATION→AUTHORITY'))
            if q.get('action') not in previous_scope.get('actions', []) or q.get('target') not in previous_scope.get('targets', []) or q.get('purpose') not in previous_scope.get('purposes', []) or q.get('amount', 0) > previous_scope.get('max_amount', -1):
                alerts.append(alert('DELEGATION_SCOPE', 'AUTHORITY→DECISION'))
        by_hash = {e.get('digest'): e for e in events}
        for e in events:
            if not e.get('roots') or (e.get('kind') == 'source' and set(e.get('roots', [])) != set(roots)):
                alerts.append(alert('ORIGIN_ABSENT', 'SOURCE→DATA'))
            if not _subset(e.get('roots', []), roots):
                alerts.append(alert('ORIGIN_MISMATCH', 'DATA→CONTEXT'))
            for parent in e.get('parents', []):
                pe = by_hash.get(parent)
                if pe is not None:
                    if not _subset(pe.get('roots', []), e.get('roots', [])):
                        alerts.append(alert('PROVENANCE_ERASURE', 'DATA→CONTEXT'))
                    if pe.get('taint') == 'untrusted' and e.get('taint') == 'trusted':
                        alerts.append(alert('TAINT_LAUNDERING', 'INTERPRETATION→AUTHORITY'))
            if e.get('kind') == 'authority' and e.get('body', {}).get('authorization') != a:
                alerts.append(alert('AUTHORITY_RECORD_MISMATCH', 'AUTHORITY→DECISION'))
            if e.get('kind') == 'interpretation' and e.get('body', {}).get('operation') != p:
                alerts.append(alert('INTERPRETER_RECORD_MISMATCH', 'CONTEXT→INTERPRETATION'))
            if e.get('kind') == 'tool' and e.get('body', {}).get('operation') != q:
                alerts.append(alert('TOOL_RECORD_MISMATCH', 'DECISION→TOOL'))
            if e.get('kind') == 'context' and e.get('body', {}).get('context_digest') != digest(c):
                alerts.append(alert('CONTEXT_RECORD_MISMATCH', 'DATA→CONTEXT'))
            if e.get('kind') in ('authority', 'decision', 'tool') and e.get('taint') == 'untrusted':
                alerts.append(alert('UNTRUSTED_AUTHORITY_PATH', 'INTERPRETATION→AUTHORITY'))
        return alerts

    def commit_guard(self, public, operation, runtime_version):
        if 'typed_invariants' not in self.layers:
            return []
        a = public['authorization']
        alerts = []
        if digest(operation) != a.get('request_digest'):
            alerts.append(alert('TOCTOU_REQUEST', 'TOOL→EXECUTION', phase='commit'))
        if runtime_version != a.get('snapshot_version'):
            alerts.append(alert('TOCTOU_STATE', 'TOOL→EXECUTION', phase='commit'))
        nonce = a.get('nonce')
        if not isinstance(nonce, str) or not nonce:
            alerts.append(alert('NONCE_MISSING', 'TOOL→EXECUTION', phase='commit'))
        elif nonce in self.registry.used:
            alerts.append(alert('REPLAY_NONCE', 'TOOL→EXECUTION', phase='commit'))
        if not alerts:
            self.registry.consume(nonce)
        return alerts

    def postflight(self, public, receipts):
        from .reconstruction import reconstruct
        if 'reconstruction' not in self.layers:
            return {'status': 'VERIFIED', 'alerts': [], 'reconstruction': {'effect': None, 'independent': False,
                    'observed_trajectory': [], 'posterior': {}, 'coverage': 'not-assessed-by-selected-layers'}}
        return reconstruct(public, receipts, self.keyring)
