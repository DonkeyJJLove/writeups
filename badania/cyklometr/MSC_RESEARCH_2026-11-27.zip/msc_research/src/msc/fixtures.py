"""Public fixture generator; separate from the policy controller."""
import copy
from .crypto import digest, issue_event

STAGES = ('source', 'data', 'context', 'interpretation', 'authority', 'decision', 'tool')
STAGE_ROLES = dict(zip(STAGES, ('ingestor', 'ingestor', 'planner', 'planner', 'authorizer', 'planner', 'executor')))


def make_events(public):
    c, q, a, p = public['context'], public['request'], public['authorization'], public['plan']
    bodies = {
        'source': {'text': c.get('source_text', '')},
        'data': {'text': c.get('source_text', '')},
        'context': {'context_digest': digest(c)},
        'interpretation': {'operation': p, 'interpreter': 'typed-ledger-v1'},
        'authority': {'authorization': a},
        'decision': {'request_digest': digest(q), 'context_digest': digest(c), 'approved': True},
        'tool': {'tool': 'ledger.transfer', 'operation': q},
    }
    events = []
    for step, kind in enumerate(STAGES):
        event = issue_event({
            'id': q['id'] + ':' + kind, 'kind': kind, 'role': STAGE_ROLES[kind],
            'step': step, 'parents': [events[-1]['digest']] if events else [],
            'body': copy.deepcopy(bodies[kind]),
            'roots': copy.deepcopy(c.get('source_roots', [])),
            'taint': 'trusted' if set(c.get('source_roots', [])).issubset(c.get('trusted_roots', [])) else 'untrusted',
            'label': 'instruction' if kind in ('source', 'authority', 'decision', 'tool') else 'data',
        })
        events.append(event)
    return events


def reseal(case, refresh_bindings=True, rebuild_events=True):
    public = case['public']
    if refresh_bindings:
        public['authorization']['request_digest'] = digest(public['request'])
        public['authorization']['context_digest'] = digest(public['context'])
    if rebuild_events:
        public['events'] = make_events(public)
    return case


def build_case(seed=1):
    q = {'id': f'case-{seed}', 'actor': 'executor', 'action': 'transfer', 'source': 'ops',
         'target': 'payroll', 'amount': 1 + int(seed) % 99, 'currency': 'PLN',
         'purpose': 'payroll', 'snapshot_version': 1}
    c = {'user_goal': 'Pay payroll from ops', 'purpose': 'payroll', 'allowed_targets': ['payroll'],
         'max_amount': 100, 'snapshot_version': 1, 'source_text': 'Pay payroll from ops',
         'source_roots': ['user:root'], 'trusted_roots': ['user:root'], 'policy_id': 'payroll-policy-v1'}
    a = {'issuer': 'authorizer', 'subject': 'executor', 'actions': ['transfer'], 'targets': ['payroll'],
         'max_amount': 100, 'purposes': ['payroll'], 'request_digest': digest(q), 'context_digest': digest(c),
         'snapshot_version': 1, 'nonce': f'nonce-{seed}', 'delegations': [], 'approved_source_roots': ['user:root']}
    case = {'public': {'request': q, 'context': c, 'plan': copy.deepcopy(q), 'authorization': a, 'events': []},
            'runtime': {'execution_request': copy.deepcopy(q), 'snapshot_version': 1,
                        'self_report_override': None, 'host_report_override': None,
                        'host_available': True, 'host_root': 'host:kernel', 'self_root': 'agent:executor',
                        'replay_nonce': False, 'repeat_count': 1, 'nonce_already_used': False}}
    return reseal(case)
