"""Content-addressed, local BOM registry for reproducible projections."""
import copy
from .crypto import digest
from .graph import materialize_bom


class BOMRegistry:
    def __init__(self):
        self.entries = {}

    def observe(self, public, receipts=()):
        view = materialize_bom(public, receipts)
        key = digest(view)
        self.entries[key] = copy.deepcopy(view)
        return key

    def get(self, key):
        value = copy.deepcopy(self.entries[key])
        if digest(value) != key:
            raise ValueError('Corrupted registry entry')
        return value
