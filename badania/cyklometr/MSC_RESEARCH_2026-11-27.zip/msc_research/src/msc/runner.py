"""Local experimental runner. Runtime attributes are unavailable at preflight."""
import copy
import time
from .controller import Controller, alert
from .executor import ToyExecutor, create_receipts
from .graph import materialize_bom, characteristic


def evaluate(case, model='M7', layers=None):
    started = time.perf_counter_ns()
    controller = Controller(model, layers)
    # Deliberate data firewall: never pass case labels, hidden truth or runtime to preflight.
    public = copy.deepcopy(case.get('public', {}))
    pre_start = time.perf_counter_ns()
    pre = controller.preflight(public)
    pre_end = time.perf_counter_ns()
    alerts = list(pre['alerts'])
    runtime = copy.deepcopy(case.get('runtime', {}))
    executor = ToyExecutor()
    receipts = []
    status = pre['status']
    reconstruction = {'effect': None, 'independent': False, 'observed_trajectory': [],
                      'posterior': {}, 'coverage': 'not-executed'}
    commit_start = time.perf_counter_ns()
    if pre['allow']:
        q = runtime.get('execution_request', public.get('request', {}))
        repeat = runtime.get('repeat_count', 1)
        if runtime.get('replay_nonce', False):
            repeat = max(repeat, 2) if isinstance(repeat, int) else repeat
        if not isinstance(repeat, int) or isinstance(repeat, bool) or not 1 <= repeat <= 20:
            alerts.append(alert('RUNTIME_REPEAT_BOUND', 'TOOL→EXECUTION', phase='commit'))
            status = 'UNKNOWN'
        else:
            if runtime.get('nonce_already_used', False):
                controller.registry.used.add(public['authorization'].get('nonce'))
            for _ in range(repeat):
                guard = controller.commit_guard(public, q, runtime.get('snapshot_version', 1))
                if guard:
                    alerts.extend(guard)
                    status = 'CONTRADICTED'
                    break
                if not executor.commit(q):
                    alerts.append(alert('EXECUTOR_PHYSICAL_VALIDITY', 'TOOL→EXECUTION', phase='commit'))
                    status = 'CONTRADICTED'
                    break
    commit_end = time.perf_counter_ns()
    post_start = time.perf_counter_ns()
    if executor.operations:
        receipts = create_receipts(public, runtime, executor.effect)
        post = controller.postflight(public, receipts)
        alerts.extend(post['alerts'])
        reconstruction = post['reconstruction']
        if status != 'CONTRADICTED':
            status = post['status']
    post_end = time.perf_counter_ns()
    containment_enabled = 'containment' in controller.layers
    return {
        'model': model, 'layers': sorted(controller.layers), 'allowed_pre': pre['allow'],
        'preflight_status': pre['status'], 'executed': bool(executor.operations),
        'committed_count': len(executor.operations), 'status': status,
        'alerts': alerts, 'locations': sorted({a['location'] for a in alerts}),
        'actual_effect': executor.effect, 'reconstruction': reconstruction,
        'receipts': receipts,
        'containment': {'enabled': containment_enabled,
                        'quarantined': containment_enabled and status != 'VERIFIED',
                        'retry_budget': 0 if containment_enabled else None,
                        'scope': 'local-result-signal; no network simulated here'},
        'timings_ms': {'preflight': (pre_end - pre_start) / 1e6,
                       'commit': (commit_end - commit_start) / 1e6,
                       'postflight': (post_end - post_start) / 1e6,
                       'total': (post_end - started) / 1e6},
        'verification_scope': 'Consistency with the selected observable contract; not absolute safety',
    }
