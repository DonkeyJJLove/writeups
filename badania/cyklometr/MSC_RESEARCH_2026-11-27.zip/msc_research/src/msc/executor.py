"""In-process synthetic ledger. Every actual effect originates here, never from receipts."""
import copy
from .crypto import digest, issue_event
from .controller import alert


def effect_for_operations(operations):
    if not operations:
        return {}
    delta = {}
    total = 0
    for q in operations:
        amount, source, target = q['amount'], q['source'], q['target']
        delta[source] = delta.get(source, 0) - amount
        delta[target] = delta.get(target, 0) + amount
        total += amount
    return {'operations': copy.deepcopy(operations), 'total_debit': total, 'balance_delta': delta}


class ToyExecutor:
    def __init__(self):
        self.balances = {'ops': 1_000_000}
        self.operations = []

    def commit(self, operation):
        # Physical validity only: no policy scope or ground truth is consulted.
        try:
            amount, source, target = operation['amount'], operation['source'], operation['target']
            if not isinstance(amount, int) or isinstance(amount, bool) or amount <= 0:
                return False
            if not isinstance(source, str) or not isinstance(target, str) or self.balances.get(source, 0) < amount:
                return False
            self.balances[source] -= amount
            self.balances[target] = self.balances.get(target, 0) + amount
            self.operations.append(copy.deepcopy(operation))
            return True
        except (KeyError, TypeError):
            return False

    @property
    def effect(self):
        return effect_for_operations(self.operations)


def create_receipts(public, runtime, actual_effect):
    request_digest = digest(public['request'])
    parent = public.get('events', [])[-1].get('digest') if public.get('events') else None
    base = {'request_digest': request_digest, 'snapshot_version': runtime.get('snapshot_version', 1)}
    self_effect = runtime.get('self_report_override')
    host_effect = runtime.get('host_report_override')
    self_event = issue_event({'id': public['request']['id'] + ':execution', 'kind': 'execution', 'role': 'executor',
                             'step': 100, 'parents': [parent] if parent else [], 'label': 'receipt', 'taint': 'observed',
                             'roots': [runtime.get('self_root', 'agent:executor')],
                             'body': {**base, 'effect': copy.deepcopy(actual_effect if self_effect is None else self_effect)}})
    records = [self_event]
    if runtime.get('host_available', True):
        records.append(issue_event({'id': public['request']['id'] + ':evidence', 'kind': 'evidence', 'role': 'host',
                                    'step': 101, 'parents': [self_event['digest']], 'label': 'observation', 'taint': 'observed',
                                    'roots': [runtime.get('host_root', 'host:kernel')],
                                    'body': {**base, 'effect': copy.deepcopy(actual_effect if host_effect is None else host_effect)}}))
    return records
