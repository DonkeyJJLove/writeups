import argparse
import json
from . import build_case, evaluate
parser = argparse.ArgumentParser(description='MSC toy ledger experiment; no external actions')
parser.add_argument('--model', default='M7', choices=[f'M{i}' for i in range(9)])
parser.add_argument('--seed', type=int, default=1)
parser.add_argument('--case', help='JSON case path (public + runtime only)')
args = parser.parse_args()
if args.case:
    with open(args.case, encoding='utf-8') as f:
        case = json.load(f)
else:
    case = build_case(args.seed)
print(json.dumps(evaluate(case, args.model), ensure_ascii=False, indent=2))
