"""Dynamic process multigraph and observable characteristics; no universal semantic invariant."""
from collections import Counter
from pathlib import Path
import hashlib
from .crypto import digest


def graph_from_events(events):
    nodes = {e.get('digest', e.get('id')): {'id': e.get('id'), 'kind': e.get('kind'), 'role': e.get('role'),
             'roots': e.get('roots', []), 'label': e.get('label'), 'step': e.get('step')} for e in events}
    edges = [(parent, e.get('digest', e.get('id'))) for e in events for parent in e.get('parents', [])]
    return {'nodes': nodes, 'edges': edges}


def characteristic(events, typed=True):
    """Invariant to event order and identity renaming, not complete graph isomorphism test."""
    g = graph_from_events(events)
    indeg = Counter(v for _, v in g['edges'])
    outdeg = Counter(u for u, _ in g['edges'])
    rows = []
    for node, meta in g['nodes'].items():
        row = [indeg[node], outdeg[node]]
        if typed:
            row += [meta['kind'], meta['role'], meta['label']]
        rows.append(row)
    return digest(sorted(rows, key=repr))


def has_path(events, source, target):
    adj = {}
    for e in events:
        for parent in e.get('parents', []):
            adj.setdefault(parent, []).append(e.get('digest'))
    stack, seen = [source], set()
    while stack:
        v = stack.pop()
        if v == target:
            return True
        if v not in seen:
            seen.add(v)
            stack.extend(adj.get(v, []))
    return False


def materialize_bom(public, receipts=()):
    """Derived views are projections of witnessed claims; they do not prove truth."""
    events = public.get('events', [])
    all_records = list(events) + list(receipts)
    source_files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob('*.py'))}
    inventory = {'components': [{'name': 'msc', 'version': '0.1.0', 'source_files': source_files},
                                {'name': 'toy-ledger', 'version': '1'}],
                 'hardware': {'status': 'UNKNOWN', 'reason': 'No measured boot or hardware attestation'}}
    return {
        'software_bom': inventory,
        'label_bom': [{'event': e.get('digest'), 'label': e.get('label'), 'roots': e.get('roots'), 'taint': e.get('taint')} for e in events],
        'identity_authority_bom': public.get('authorization', {}),
        'decision_bom': [{'event': e.get('digest'), 'body': e.get('body'), 'parents': e.get('parents')} for e in events if e.get('kind') == 'decision'],
        'execution_bom': [{'event': e.get('digest'), 'role': e.get('role'), 'body': e.get('body')} for e in receipts],
        'meta_links': {'event_root': digest([e.get('digest') for e in all_records]),
                       'software_digest': digest(inventory),
                       'request_digest': digest(public.get('request', {})),
                       'context_digest': digest(public.get('context', {}))},
    }
