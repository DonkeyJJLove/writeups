"""Canonical test attestations. Deterministic keys are public fixtures, not production keys."""
import base64
import copy
import hashlib
import json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.exceptions import InvalidSignature

ROLES = ('ingestor', 'planner', 'authorizer', 'executor', 'verifier', 'host')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def _private(role):
    if role not in ROLES:
        raise ValueError('Unregistered fixture role')
    seed = hashlib.sha256(('MSC PUBLIC TEST KEY ONLY/' + role).encode()).digest()
    return Ed25519PrivateKey.from_private_bytes(seed)


def default_keyring():
    return {role: _private(role).public_key() for role in ROLES}


def unsigned(event):
    return {key: value for key, value in event.items() if key not in ('digest', 'signature')}


def issue_event(event):
    event = copy.deepcopy(unsigned(event))
    event['digest'] = digest(event)
    event['signature'] = base64.b64encode(_private(event['role']).sign(bytes.fromhex(event['digest']))).decode()
    return event


def verify_event(event, keyring=None):
    try:
        keyring = keyring or default_keyring()
        claimed = event['digest']
        if digest(unsigned(event)) != claimed:
            return False
        keyring[event['role']].verify(base64.b64decode(event['signature'], validate=True), bytes.fromhex(claimed))
        return True
    except (KeyError, ValueError, TypeError, InvalidSignature):
        return False
