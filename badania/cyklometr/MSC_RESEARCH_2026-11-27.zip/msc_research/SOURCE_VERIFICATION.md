# Weryfikacja źródeł — Meta-BOM Semantic Cyclometer

**Stan kwerendy: 27 listopada 2026 r.** Badano teksty pierwotne, dokumentację organizacji rozwijających specyfikacje, strony wydawców oraz repozytoria autorów. Zakres lektury i identyfikatory odpowiedzi narzędzia zapisano osobno dla każdej pozycji w `sources/bibliography.json`. Weryfikacja obejmuje 45 pozycji; nie jest przeglądem systematycznym całej literatury. Eksperymentów cytowanych autorów nie odtwarzano.

## 1. Rozstrzygnięcia, które zmieniają interpretację projektu

1. **Rejewski daje ścisły wzorzec matematyczny oraz wyraźny przykład ograniczenia charakterystyk.** Zachowanie typu cyklowego przy sprzężeniu nie oznacza jednoznaczności konfiguracji. Przeniesienie tej idei na agentów wymaga własnej definicji obserwacji i transformacji. [R01]
2. **NIST IR 8536 nie przedstawia standardu Meta-SBOM.** Dokument dotyczy śledzenia pochodzenia w produkcyjnych łańcuchach dostaw. Jego użycie jako inspiracji dla MSC jest adaptacją projektową. [R02]
3. **NIST SP 2400-102e2026 jest Initial Public Draft.** Taksonomia odsyła do istniejących mechanizmów ochrony agentów; nie stanowi dowodu ich kompletności ani zatwierdzenia MSC. [R03]
4. **Najbliższym odniesieniem dla zestawienia grafu pochodzenia i grafu uprawnień jest AuthGraph.** Własny wkład MSC trzeba oceniać wobec tej pracy oraz kontroli przepływu, runtime verification, process mining i istniejących formatów provenance. [R11, R36–R40]
5. **Uczciwy wynik obecnego badania nie może być porównaniem skuteczności MSC z oryginalnymi systemami z literatury.** Do tego potrzebne są wspólne dane, modele, budżety, implementacje, zakres zagrożeń i definicje metryk. Zestawienie opublikowanych procentów z wynikami syntetycznego PoC nie spełnia tych warunków.

## 2. Dokumenty bazowe: wersja, strony i zakres

| Dokument | Zweryfikowany status | Wskazanie stron |
|---|---|---|
| Rejewski, 1980 [R01] | Artykuł w *Applicationes Mathematicae* 16(4); otrzymano 13 maja 1977 r.; podany plik jest 18-stronicowym składem tekstu | Numeracja podanego PDF: s. 4–11 oraz część II, §1, s. 12–14 |
| NIST IR 8536 [R02, R04] | Final, publikacja 9 września 2026 r.; akceptacja redakcyjna 18 sierpnia 2026 r. | §4.2.1–4.3.2: strony drukowane 35–38, strony pliku PDF 44–47 |
| NIST SP 2400-102e2026 [R03] | Initial Public Draft, 9 listopada 2026 r.; termin uwag 18 grudnia 2026 r. | §4.6–4.7: strony drukowane 69–71, strony pliku PDF 84–86 |

Numery stron PDF w tym raporcie liczone są od 1. Narzędzia ekstrakcji mogą prezentować indeksy od 0. Zweryfikowano również obrazy wybranych stron, aby sprawdzić zgodność numeracji z tekstem.

### 2.1. Rejewski: co rzeczywiście przenosi się na MSC

| Fragment [R01] | Treść istotna dla badania |
|---|---|
| S. 4–5 | Rekonstrukcja iloczynów permutacji z powtórzonych kluczy wiadomości. |
| S. 6–8 | Równania i własności iloczynów inwolucji bez punktów stałych; cykle występują w parach jednakowych długości. |
| S. 9–10 | Rekonstrukcja wymaga dodatkowej informacji; charakterystyki mogą odpowiadać różnym ustawieniom. |
| S. 11 | Sprzężenie permutacji i zachowanie struktury cykli. |
| S. 12–14 | Cyklometr, eliminowanie zależności od łącznicy przez charakterystyki cyklowe oraz katalog 105 456 pozycji. |

Najważniejsze zastrzeżenie znajduje się na s. 10: „the same characteristics do not guarantee the same setting of drums for both days”. To 14-wyrazowy cytat; dalsze omówienie jest parafrazą. [R01]

**Wniosek własny:** odpowiednikiem cyklometru może być indeksowanie klas przebiegów pod określoną równoważnością, a nie uniwersalny detektor intencji. Niezmiennik może jednocześnie być użyteczny i tracić informację bezpieczeństwa. W MSC trzeba ustalić, które nazwy wolno zamieniać, a które etykiety, mandaty, źródła lub skutki muszą pozostać rozróżnialne. Dowody i kontrprzykłady dla tej granicy należą do `FORMAL_MODEL.md`.

### 2.2. NIST IR 8536: mechanika pochodzenia i zawartość

§4.2.1 definiuje elementy rekordu, w tym odrębne znaczniki czasu wystąpienia i zapisania zdarzenia oraz identyfikator typu danych. §4.2.2 rozdziela otoczkę od zawartości i wskazuje schematy lub ontologie. §4.3.1 dotyczy integralności i przypisania pochodzenia; §4.3.2 — rekonstrukcji przez jednokierunkowe linki do poprzedników. Załącznik F opisuje implementację referencyjną jako laboratoryjny MVP. Nie badano jej kodu. [R02]

W przeszukanym tekście nie znaleziono określeń `SBOM`, `Meta-BOM` ani `Meta-SBOM`. Negatywny wynik wyszukania nie dowodzi braku wszelkiego pokrewieństwa koncepcyjnego, ale wyklucza przypisywanie dokumentowi dosłownej propozycji o takiej nazwie. Finalny raport NIST nie jest automatycznie obowiązkową normą bezpieczeństwa systemów agentowych. [R02]

Pierwszy publiczny projekt IR 8536 opublikowano **27 września 2024 r.**, drugi **31 lipca 2025 r.** Chronologii nie wolno rozpoczynać od wersji finalnej z 2026 r. Nie przeprowadzono porównania linia po linii wersji projektu i finalnej; nie stwierdza się więc, że każde zdanie finalne istniało już w 2024 r. [R04]

**Wniosek własny:** hash odsyłający do podpisanego rekordu pozwala sprawdzić zgodność zapisu z odniesieniem. Ustalenie, czy rekord opisuje rzeczywisty skutek, wymaga odrębnego modelu świadectw i zaufania. Implementacja MSC musi tę różnicę zachować.

### 2.3. NIST SP 2400-102e2026: bibliografia mechanizmów, nie certyfikat

§4.6 obejmuje m.in. topologię współpracy, komunikację, tożsamość, autoryzację, kontrolę przepływu i audyt zmowy. §4.7 rozszerza analizę na agentów działających długo, stan i pamięć. Dokument łączy opis zagrożeń z odwołaniami do publikacji. Nie znaleziono terminów `SBOM` ani `Meta-BOM` w przeszukanym tekście. [R03]

Jako projekt taksonomii dokument nie ustanawia wymogu implementacji konkretnego mechanizmu. Wynik pracy cytowanej przez NIST zachowuje własne założenia, zakres eksperymentu i ograniczenia. Samo przytoczenie pracy w NIST nie zamienia jej wyników w twierdzenie o wszystkich systemach agentowych.

## 3. Mapa wszystkich bezpośrednich odwołań w §4.6 i §4.7

Poniższa tabela rozdziela odczytanie tekstu od weryfikacji metadanych. „Tekst wybranych części” oznacza dostęp do publikacji i przeczytanie fragmentów istotnych dla MSC; nie oznacza odtworzenia wszystkich dowodów i eksperymentów. Numery w pierwszej kolumnie są numerami bibliografii **konkretnego projektu NIST z 9 listopada 2026 r.** [R03]

| Sekcja / nr NIST | Pozycja | Rzeczywisty poziom weryfikacji |
|---|---|---|
| 4.6 / [192] | Multi-Agent Risks from Advanced AI [R16] | Metadane i abstrakt autorów |
| 4.6 / [198] | Red-Teaming LLM Multi-Agent Systems via Communication Attacks [R17] | Metadane i abstrakt wydawcy |
| 4.6 / [259] | Prompt Infection [R18] | Metadane i abstrakt autorów |
| 4.6 / [355] | Self-replicating prompt injections exist [R19] | Pierwotny raport badawczy i opis środowiska |
| 4.6 / [331] | Terrarium [R20] | Metadane i abstrakt autorów |
| 4.6 / [471] | On the Resilience of LLM-Based Multi-Agent Collaboration with Faulty Agents [R21] | Strona wydawcy i wybrane części PDF |
| 4.6 / [492] | G-Safeguard [R05] | Metoda, zakres ewaluacji i ograniczenia w PDF |
| 4.6 / [3] | Firewalls to Secure Dynamic LLM Agentic Networks [R08] | Wybrane części pełnego tekstu HTML |
| 4.6 / [86] | Infrastructure for AI Agents [R15] | Metadane i abstrakt autorów |
| 4.6 / [452] | SAGA [R07] | Architektura, model zagrożeń i zakres weryfikacji formalnej w PDF |
| 4.6 / [228] | ControlValve [R06] | Metoda i ograniczenia w pełnym HTML |
| 4.6 / [330] | Colosseum [R09] | Abstrakt, framework i lista deklaracji autorów w HTML |
| 4.7 / [293] | OpenClaw in the Wild [R22] | Metadane i abstrakt na stronie wydawcy IEEE/CAA |
| 4.7 / [395] | OpenClaw and Ollama in Agentic AI [R23] | **Tylko wpis bibliograficzny w NIST; treści pierwotnej nie odczytano** |
| 4.7 / [347] | Understanding and Evaluating Claw-like Agent Security Through a Computer-Systems Lens [R24] | Metadane i abstrakt autorów |
| 4.7 / [450] | A Security Analysis of the OpenClaw AI Agent Framework [R25] | Metadane i abstrakt autorów |
| 4.7 / [231] | AgentLAB [R10] | PDF PMLR: benchmark, ocena i ograniczenia |
| 4.7 / [265] | Measuring and Controlling Instruction (In)Stability in Language Model Dialogs [R26] | Metadane i abstrakt autorów |
| 4.7 / [276] | Lost in the Middle [R27] | Metadane i abstrakt autorów |
| 4.7 / [499] | MAGE / ShadowMem [R12] | Historia wersji, abstrakt, początek PDF i architektura |

Pełna maszynowo czytelna mapa znajduje się w `sources/nist_citation_map.json`. Nie dopisano zawartości niedostępnej pozycji [395]. Dla prac odczytanych tylko na poziomie abstraktu raport nie przypisuje szczegółowych własności mechanizmu, których nie zweryfikowano.

## 4. Mechanizmy najbliższe MSC

| Praca i wersja | Co potwierdza odczytany tekst | Granica dowodu i znaczenie dla projektu |
|---|---|---|
| **G-Safeguard**, ACL 2025 [R05] | Wykrywanie anomalii w grafie i izolowanie elementów ogranicza dalsze rozchodzenie się kompromitacji w badanych układach. | Autorzy wyraźnie wyłączają zapobieganie początkowej kompromitacji. Ich ASR odnosi się do odsetka agentów z zachowaniem złośliwym lub błędnym; nie jest automatycznie ASR prób ataku w MSC. |
| **ControlValve**, v1 20.10.2025, v2 05.03.2026 [R06] | Osobne planowanie tworzy dozwolony graf wywołań i reguły kontekstowe egzekwowane podczas wykonania. | Błędny lub zbyt szeroki graf wygenerowany przez LLM osłabia kontrolę. Podobieństwo do M3 trzeba określić funkcjonalnie, bez nazywania uproszczonego baseline reimplementacją całej pracy. |
| **SAGA**, NDSS 2026 [R07] | Mechanizmy cyklu życia, polityki kontaktów i tokeny kryptograficzne; weryfikacja symboliczna wybranych własności poufności i uwierzytelnienia. | Założono zaufaną logikę dostawcy i rejestr oraz bezpieczeństwo kluczy i kanałów. ProVerif nie dowodzi poprawności interpretacji języka naturalnego przez wszystkich agentów. |
| **Firewalls**, v1 03.02.2025, v7 23.06.2026; TMLR 2026 według rekordu autorów [R08] | Strukturyzacja wiadomości przychodzących i ograniczenie danych wychodzących do zakresu zadania. | Poprawne protokołowo, lecz fałszywe wartości pozostają możliwe. W modelu zaufano bazie wiedzy użytkownika; zakres nie obejmuje pełnego problemu jej zatruwania. |
| **Colosseum**, v1 16.02.2026, v3 17.11.2026 [R09] | Audyt zmowy poprzez działania i odchylenie od kooperacyjnego optimum; rozróżnienie deklaracji i zachowań. | Framework audytu, bez ogólnej gwarancji egzekwowania bezpieczeństwa. W deklaracjach autorów zaznaczono brak wyników teoretycznych. |
| **AgentLAB**, arXiv 18.02.2026; ICML/PMLR 2026 [R10] | 28 środowisk, 644 przypadki i pięć rodzin ataków w długich interakcjach. | Kontrolowane środowiska upraszczają szum i awarie narzędzi; porównywanie trajektorii ma ograniczenia. Zestawu nie uruchomiono w MSC; liczby nie opisują własnego benchmarku. |
| **AuthGraph**, v1 26.05.2026 [R11] | Odrębne grafy pochodzenia i autoryzacji; kontrola źródeł parametrów operacji. | Załącznik B.2 wyłącza przypadki zatrutych obserwacji, których konsumpcję użytkownik autoryzował i które mają identyczną projekcję śladu. To bezpośrednia granica rozróżnialności istotna dla MSC. |
| **MAGE / ShadowMem**, v1 04.05.2026, v2 23.09.2026 [R12] | Osobna pamięć informacji istotnych dla bezpieczeństwa służy sprawdzaniu kolejnych działań. | NIST stosuje wcześniejszą nazwę MAGE; późniejsza wersja to ShadowMem, przyjęta do CCS 2026 według rekordu autorów. Taka pamięć nie jest niezależnym pomiarem skutku operacji. |

**Wniosek własny:** źródła uzasadniają projektowanie warstw uzupełniających się, ale nie potwierdzają, że suma tych warstw musi dominować każde rozwiązanie osobno. Warstwy mogą dzielić błędne źródło danych, wspólny model lub zależność od tego samego obserwatora. Tę zależność trzeba mierzyć albo modelować, a nie zastępować liczbą podpisów.

## 5. Standardy, taksonomie i wcześniejsze podstawy

| Źródło | Potwierdzony zakres | Skutek dla oceny MSC |
|---|---|---|
| CycloneDX 1.7, 21.10.2025 [R28] | Formulation obejmuje deklarowane i obserwowane workflow; specyfikacja zawiera również runtime topology i relacje zależności. | Sam pomysł BOM rozszerzonego na przebieg działania nie jest wystarczającym argumentem nowości. Schema określa reprezentację, nie prawdziwość zdarzeń. |
| CycloneDX BOM-Link [R29] | Odwołania między BOM i ich elementami. | Można rozważyć adapter formatu; własny hash rekordu nie oznacza automatycznej zgodności ze standardem. |
| SPDX 3.0.1, profile AI i Build [R30] | Modele dla informacji o AI i procesie budowania; wymagania zgodności specyfikacji. | Profil AI nie jest sam w sobie modelem autoryzacji agentów. Dokładnej daty wydania nie ustalono w tej kwerendzie. |
| SLSA 1.2, status Approved [R31] | Pochodzenie procesu budowy i weryfikacja związania artefaktu z zaufanym producentem. | Integralność i pochodzenie budowy nie rozstrzygają semantycznej poprawności późniejszej operacji. Nie ustalono dnia publikacji wersji. |
| in-toto, USENIX Security 2019 [R32] | Powiązanie kroków łańcucha dostaw, ich wykonawców i artefaktów za pomocą metadanych kryptograficznych. | Istotny antecedens wiązania działań z deklarowanym procesem. |
| Sigstore, oficjalny threat model [R33] | Jawne założenia tożsamości, podpisywania i weryfikacji oraz granice przy kompromitacji kont lub kluczy. | Podpis wymaga właściwej polityki zaufania; nie dowodzi nieszkodliwości podpisanego obiektu. |
| OWASP ASI07, edycja 2026 [R13] | Zagrożenia komunikacji między agentami, w tym rozbieżności interpretacji; schematy, związanie kontekstu, provenance i ochrona przed replay. | Praktyczne zalecenia społeczności, bez dowodu, że jednolity schemat wystarcza do wspólnej semantyki. |
| OWASP ASI08, edycja 2026 [R14] | Propagacja błędów, wzmacnianie przez ponawianie i reakcje obronne; limity, niezależne egzekwowanie polityki, wyłączniki i śledzenie zależności. | Uzasadnienie testów destabilizacji samej ochrony; opis ryzyka nie jest dowodem konkretnego incydentu produkcyjnego. |
| MITRE ATLAS przez oficjalne strony MITRE D3FEND [R34] | `AML.T0051` — prompt injection; `AML.T0080` — AI Agent Context Poisoning; `AML.T0080.000` — Memory Poisoning. | Identyfikator należy wiązać z wersją/kwerendą. Nie przypisywać całego bieżącego T0080 wyłącznie zatruwaniu pamięci. |
| CWE-436 [R35] | Konflikt interpretacji: komponenty inaczej rozumieją tę samą reprezentację. | Dobry punkt odniesienia dla styku parserów i domen; klasyfikacja słabości nie jest gwarancją detekcji. |
| Schneider, 2000 [R36] | Granice polityk egzekwowalnych przez monitory wykonania, przy określonym modelu obserwacji i interwencji. | Trzeba podać, co monitor widzi i może zatrzymać; nie każda własność globalna jest zwykłą własnością pojedynczego śladu. |
| Sabelfeld i Myers, 2003 [R37] | Bezpieczeństwo przepływu informacji: etykiety, deklasyfikacja i kanały pośrednie. | Operacyjne uprawnienie wywołania nie zastępuje kontroli przepływu informacji i zmiany jej statusu. |
| Bauer, Leucker i Schallhart, 2011 [R38] | Runtime verification LTL/TLTL i interpretacja obserwowanych prefiksów. | Uzasadnia jawne wyniki nierozstrzygnięte; nie oznacza automatycznej zgodności semantyki `UNKNOWN` w MSC z ich konkretną logiką. |
| Rozinat i van der Aalst, 2008 [R39] | Sprawdzanie zgodności zachowania z modelem procesu. | Porównywanie oczekiwanego przebiegu z logiem ma wcześniejsze podstawy; nowość wymaga konkretnego rozszerzenia. |
| Abadi i współautorzy, 2005 [R40] | Integralność przepływu sterowania względem dopuszczalnych przejść. | Kontrola krawędzi ma długą historię; semantyczne etykiety i świadectwa skutku wymagają osobnego uzasadnienia. |
| Buldyrev i współautorzy, 2010; Google SRE [R41, R42] | Model kaskad w sieciach zależnych oraz praktyczne mechanizmy przeciążenia, retry i redystrybucji ruchu. | Nie należy utożsamiać modelu perkolacyjnego z dynamiką kolejek ani bez danych przenosić jego parametrów na agentów. |
| Kalman, 1960; Tichonow, 1963 [R43, R44] | Klasyczne źródła estymacji stanu i regularyzacji problemów źle postawionych. | Dodatkowe założenia i obserwacje mogą poprawiać rekonstrukcję; sam wybór estymatora nie zapewnia identyfikowalności. Dla R44 odczytano tylko metadane. |
| Åström i Murray, wyd. 2, v3.1.5 z 24.07.2020 [R45] | §5.3–5.4: stabilność i funkcje Lapunowa; §8.1–8.2: obserwowalność i estymacja; §8.4: filtracja Kalmana. | Tło dla modelowania sprzężeń i obserwatora. Nie przenosi automatycznie twierdzeń o konkretnych modelach na dowolną zmienną topologię MSC. |

Status normatywny należy rozumieć lokalnie: specyfikacja może normować format i kryteria zgodności dla implementacji deklarującej ten format. Nie wynika z tego, że stanowi obowiązkową normę prawną albo certyfikat bezpieczeństwa całej aplikacji. Artykuły naukowe, preprinty, dokumentacja zagrożeń i zalecenia OWASP mają różne role dowodowe.

## 6. Macierz odniesienia Rejewski — NIST — projekt MSC

Ta macierz jest **interpretacją autora obecnego badania**, a nie tezą sformułowaną przez przywołane instytucje.

| Relacja | Rejewski | NIST IR 8536 / SP 2400-102 | Konsekwencja projektowa MSC |
|---|---|---|---|
| Obserwacja a ukryty stan | Charakterystyka ogranicza zbiór kandydatów. [R01] | Rekordy pochodzenia i chronologia wspierają analizę historii. [R02] | Odrębne przebiegi deklarowany, autoryzowany, obserwowany i zrekonstruowany. |
| Niezmienność | Sprzężenie zachowuje typ cyklowy. [R01] | NIST nie podaje analogicznego twierdzenia dla agentów. [R02, R03] | Każda klasa przekształceń wymaga własnej definicji i dowodu. |
| Wiązanie świadectw | Nie jest współczesnym protokołem attestacji. | Kryptograficzne powiązania w łańcuchu traceability. [R02] | Receipts wiążą kontekst, mandat, żądanie i obserwację skutku; prawdziwość pozostaje osobną kwestią. |
| Interwencja | Analiza kryptologiczna, nie kontroler agentów. | Przegląd topologii, kontroli przepływu i uprawnień. [R03] | Warstwy prewencji, detekcji, rekonstrukcji i ograniczania propagacji trzeba oceniać oddzielnie. |

## 7. Chronologia zewnętrzna i granice oceny nowości

| Data / okres | Potwierdzony punkt odniesienia |
|---|---|
| 1960–1963 | Estymacja i regularyzacja problemów odwrotnych. [R43, R44] |
| 1980, tekst otrzymany 1977 | Publikacja Rejewskiego opisująca wcześniejszą pracę kryptologiczną. [R01] |
| 2000–2011 | Monitory, IFC, CFI, conformance checking i runtime verification. [R36–R40] |
| 2019 | in-toto. [R32] |
| 27.09.2024 | Pierwszy projekt meta-framework NIST IR 8536. [R04] |
| 09.10.2024 | Prompt Infection. [R18] |
| 2025 | Firewalls, G-Safeguard, ControlValve i CycloneDX 1.7. [R05, R06, R08, R28] |
| 26.05.2026 | AuthGraph: rozdzielenie grafu pochodzenia i autoryzacji. [R11] |
| 09.09.2026 | Finalny IR 8536. [R02] |
| 09.11.2026 | Projekt SP 2400-102e2026. [R03] |

Materiały LAB i ich daty są analizowane w chronologii autorskiej w raporcie głównym. Ten plik nie przypisuje użytkownikowi pierwszeństwa na podstawie podobieństwa nazw, daty pliku lub deklaracji w aktualnym promptcie.

**Ocena własna:** możliwy wkład MSC leży w konkretnej integracji: formalnie określonych charakterystykach, oddzieleniu autoryzacji od pochodzenia, niezależnym sprawdzaniu skutku, rozliczaniu niepewności i interwencji z kontrolą stabilności. Sama obecność grafu, hashy, etykiet, receipts albo dynamicznego BOM nie wystarcza do wykazania nowej klasy mechanizmów. Potrzebny jest zarówno wynik dodatni na określonej klasie zagrożeń, jak i wykazanie różnicy względem właściwych wcześniejszych rozwiązań. Obecna kwerenda nie rozstrzyga pierwszeństwa w pełnej literaturze ani oceny patentowej.

## 8. Ograniczenia dostępu i rygor interpretacji

**R23 pozostaje niezweryfikowane treściowo.** Pierwotny adres arXiv zwracał błąd dostępu. Wpis w bibliografii NIST potwierdza, że NIST odwołuje się do takiej pozycji, lecz nie potwierdza samodzielnie jej rezultatów, metod ani daty pierwszej wersji. Nie użyto wtórnych agregatorów do odtworzenia domniemanej zawartości.

Dla części publikacji odczytano abstrakt lub metadane, co wskazano w tabeli i JSON. Odnalezienie dokumentu nie oznacza sprawdzenia danych, recenzji, kodu, dowodów lub wyników. Kopie robocze PDF służyły weryfikacji; pakiet źródłowy zawiera bibliografię i krótkie omówienia, bez redystrybucji pełnych cudzych publikacji.

Raport OpenAI o samopowielających się prompt injections opisuje **symulowane środowisko narzędziowe**, z wykryciem 27 czerwca i ujawnieniem 25 września 2026 r. Nie jest dowodem obserwacji propagacji poza treningiem i ewaluacją. [R19] Analogicznie modelowe scenariusze OWASP nie są automatycznie opisami udokumentowanych incydentów produkcyjnych. [R13, R14]

Daty arXiv odróżniają pierwszą wersję od wersji przeczytanej. Nazwa konferencji przy preprincie oznacza status podany w rekordzie autorów, jeżeli nie sprawdzono niezależnie strony postępowań. Dla stron aktualizowanych bez daty nie nadawano pozornej precyzji; podano wersję i dzień dostępu.

## 9. Bibliografia i odnośniki

Poniższe identyfikatory odpowiadają rekordom w `sources/bibliography.json`. Daty, zakres lektury, krótkie uzasadnienie użycia i ograniczenia znajdują się w tym rejestrze. `tool_source_refs` pozwalają śledzić materiał wykorzystany w sesji; same identyfikatory odpowiedzi narzędzia nie są niezależnym archiwum internetowym.

<!-- BIBLIOGRAPHY GENERATED BELOW -->

- **[R01]** [An Application of the Theory of Permutations in Breaking the Enigma Cipher](https://cryptocellar.org/enigma/files/rew80.pdf). Data: 1980. Wersja/status: Received 1977-05-13; supplied 18-page retypeset PDF.
- **[R02]** [Supply Chain Traceability Principles: A Manufacturing Meta-Framework](https://nvlpubs.nist.gov/nistpubs/ir/2026/NIST.IR.8536.pdf). Data: 2026-09-09. Wersja/status: NIST IR 8536 Final; editorial approval 2026-08-18.
- **[R03]** [Adversarial Machine Learning: A Taxonomy and Terminology of Attacks and Mitigations](https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.2400-102e2026.ipd.pdf). Data: 2026-11-09. Wersja/status: NIST SP 2400-102e2026 Initial Public Draft; comment deadline 2026-12-18.
- **[R04]** [NIST IR 8536 first public draft and publication history](https://csrc.nist.gov/pubs/ir/8536/ipd). Data: 2024-09-27. Wersja/status: IPD; second draft 2025-07-31; final 2026-09-09.
- **[R05]** [G-Safeguard: A Topology-Guided Security Lens and Treatment on LLM-based Multi-agent Systems](https://aclanthology.org/2025.acl-long.359/). Data: 2025-07. Wersja/status: ACL 2025 long paper.
- **[R06]** [Breaking and Fixing Defenses Against Control-Flow Hijacking in Multi-Agent Systems (ControlValve)](https://arxiv.org/abs/2510.17276). Data: 2025-10-20. Wersja/status: v2 2026-03-05.
- **[R07]** [SAGA: A Security Architecture for Governing AI Agentic Systems](https://www.ndss-symposium.org/ndss-paper/saga-a-security-architecture-for-governing-ai-agentic-systems/). Data: 2026. Wersja/status: NDSS2026; paper 2026-s869.
- **[R08]** [Firewalls to Secure Dynamic LLM Agentic Networks](https://arxiv.org/abs/2502.01822). Data: 2025-02-03. Wersja/status: v7 2026-06-23.
- **[R09]** [Colosseum: Auditing Collusion in Cooperative Multi-Agent Systems](https://arxiv.org/abs/2602.15198). Data: 2026-02-16. Wersja/status: v2 2026-05-27; v3 2026-11-17.
- **[R10]** [AgentLAB: Benchmarking LLM Agents against Long-Horizon Attacks](https://proceedings.mlr.press/v306/jiang26as.html). Data: 2026-07. Wersja/status: arXiv v1 2026-02-18, 2602.16901.
- **[R11]** [Aligning Provenance with Authorization: A Dual-Graph Defense for LLM Agents (AuthGraph)](https://arxiv.org/abs/2605.26497). Data: 2026-05-26. Wersja/status: v1.
- **[R12]** [Safeguarding LLM Agents against Long-Horizon Threats via Shadow Memory](https://arxiv.org/abs/2605.03228). Data: 2026-05-04. Wersja/status: MAGE in v1/NIST; ShadowMem in v2 2026-09-23.
- **[R13]** [ASI07: Insecure Inter-Agent Communication](https://genai.owasp.org/agentic-applications-2026/asi07-insecure-inter-agent-communication/). Data: 2026 edition. Wersja/status: Live page accessed 2026-11-27.
- **[R14]** [ASI08: Cascading Failures](https://genai.owasp.org/agentic-applications-2026/asi08-cascading-failures/). Data: 2026 edition. Wersja/status: Live page accessed 2026-11-27.
- **[R15]** [Infrastructure for AI Agents](https://arxiv.org/abs/2501.10114). Data: 2025-01-17. Wersja/status: v3 2025-06-19.
- **[R16]** [Multi-Agent Risks from Advanced AI](https://arxiv.org/abs/2502.14143). Data: 2025-02-19. Wersja/status: v1.
- **[R17]** [Red-Teaming LLM Multi-Agent Systems via Communication Attacks](https://aclanthology.org/2025.findings-acl.349/). Data: 2025-07. Wersja/status: ACL2025 Findings.
- **[R18]** [Prompt Infection: LLM-to-LLM Prompt Injection within Multi-Agent Systems](https://arxiv.org/abs/2410.07283). Data: 2024-10-09. Wersja/status: v1.
- **[R19]** [Self-replicating prompt injections exist](https://openai.com/safety-alignment/misalignment-reports/self-replicating-prompt-injections-exist/). Data: 2026-09-25. Wersja/status: Discovery2026-06-27; disclosure/update2026-09-25.
- **[R20]** [Terrarium: Revisiting the Blackboard for Multi-Agent Safety, Privacy, and Security Studies](https://arxiv.org/abs/2510.14312). Data: 2025-10-16. Wersja/status: v1.
- **[R21]** [On the Resilience of LLM-Based Multi-Agent Collaboration with Faulty Agents](https://proceedings.mlr.press/v267/huang25ay.html). Data: 2025-07. Wersja/status: ICML2025 PMLR267.
- **[R22]** [OpenClaw in the Wild: Security Analysis of Autonomous Agents](https://www.ieee-jas.net/article/doi/10.1109/JAS.2026.126209). Data: 2026-06. Wersja/status: IEEE/CAA JAS13(6):1257–1273.
- **[R23]** [OpenClaw and Ollama in Agentic AI: Toward Fully Autonomous and Scalable AI Agent Systems](https://arxiv.org/abs/2607.28629). Data: 2026 per NIST citation. Wersja/status: None.
- **[R24]** [Understanding and Evaluating Claw-like Agent Security Through a Computer-Systems Lens](https://arxiv.org/abs/2606.30755). Data: 2026-06-29. Wersja/status: v1.
- **[R25]** [A Security Analysis of the OpenClaw AI Agent Framework](https://arxiv.org/abs/2603.27517). Data: 2026-03-29. Wersja/status: v3 2026-05-13.
- **[R26]** [Measuring and Controlling Instruction (In)Stability in Language Model Dialogs](https://arxiv.org/abs/2402.10962). Data: 2024-02-13. Wersja/status: v4 2024-07-25.
- **[R27]** [Lost in the Middle: How Language Models Use Long Contexts](https://arxiv.org/abs/2307.03172). Data: 2023-07-06. Wersja/status: v3 2023-11-20.
- **[R28]** [CycloneDX specification overview and JSON1.7](https://www.cyclonedx.org/docs/1.7/json/). Data: 2025-10-21. Wersja/status: 1.7; future2.0 advertised separately.
- **[R29]** [CycloneDX BOM-Link](https://www.cyclonedx.org/capabilities/bomlink/). Data: brak zweryfikowanej daty pierwszej publikacji. Wersja/status: Live official capability documentation.
- **[R30]** [SPDX3.0.1 AI and Build profiles](https://spdx.github.io/spdx-spec/v3.0.1/model/AI/AI/). Data: brak zweryfikowanej daty pierwszej publikacji. Wersja/status: 3.0.1.
- **[R31]** [SLSA specification and threats](https://slsa.dev/spec/v1.2/). Data: brak zweryfikowanej daty pierwszej publikacji. Wersja/status: 1.2 Approved.
- **[R32]** [in-toto: Providing farm-to-table guarantees for bits and bytes](https://www.usenix.org/conference/usenixsecurity19/presentation/torres-arias). Data: 2019. Wersja/status: USENIX Security2019.
- **[R33]** [Sigstore Threat Model](https://docs.sigstore.dev/about/threat-model/). Data: brak zweryfikowanej daty pierwszej publikacji. Wersja/status: Live official documentation.
- **[R34]** [MITRE ATLAS technique definitions via MITRE D3FEND](https://d3fend.mitre.org/offensive-technique/attack/AML.T0080/). Data: brak zweryfikowanej daty pierwszej publikacji. Wersja/status: Current retrieved ontology.
- **[R35]** [CWE-436: Interpretation Conflict](https://cwe.mitre.org/data/definitions/436). Data: brak zweryfikowanej daty pierwszej publikacji. Wersja/status: CWE5.0 current page.
- **[R36]** [Enforceable Security Policies](https://www.cs.cornell.edu/fbs/publications/EnfSecPols.pdf). Data: 2000-02. Wersja/status: ACM TISSEC3(1):30–50; antecedentTR1998.
- **[R37]** [Language-Based Information-Flow Security](https://www.cs.cornell.edu/andru/papers/jsac/sm-jsac03.pdf). Data: 2003-01. Wersja/status: IEEE JSAC21(1):5–19.
- **[R38]** [Runtime Verification for LTL and TLTL](https://openresearch-repository.anu.edu.au/items/6fdb8d50-57cd-4882-bdf8-2b290465442f). Data: 2011. Wersja/status: Earlier technical report2007.
- **[R39]** [Conformance checking of processes based on monitoring real behavior](https://research.tue.nl/en/publications/conformance-checking-of-processes-based-on-monitoring-real-behavi/). Data: 2008. Wersja/status: Information Systems33(1):64–95.
- **[R40]** [Control-Flow Integrity](https://www.microsoft.com/en-us/research/wp-content/uploads/2005/11/ccs05.pdf). Data: 2005. Wersja/status: CCS2005.
- **[R41]** [Catastrophic cascade of failures in interdependent networks](https://doi.org/10.1038/nature08932). Data: 2010-04-15. Wersja/status: Nature464:1025–1028.
- **[R42]** [Addressing Cascading Failures](https://sre.google/sre-book/addressing-cascading-failures/). Data: brak zweryfikowanej daty pierwszej publikacji. Wersja/status: Google SRE book chapter22.
- **[R43]** [A New Approach to Linear Filtering and Prediction Problems](https://www.cs.unc.edu/~welch/kalman/media/pdf/Kalman1960.pdf). Data: 1960-03. Wersja/status: Journal of Basic Engineering82(1):35–45.
- **[R44]** [On the solution of ill-posed problems and the method of regularization](https://www.mathnet.ru/eng/dan/v151/i3/p501). Data: 1963. Wersja/status: Dokl.Akad.NaukSSSR151(3):501–504.
- **[R45]** [Feedback Systems: An Introduction for Scientists and Engineers, Second Edition](https://www.fbswiki.org/wiki/index.php/Feedback_Systems:_An_Introduction_for_Scientists_and_Engineers). Data: 2020-07-24. Wersja/status: Public electronic version v3.1.5.
