import importlib.util
import unittest
from pathlib import Path
import numpy as np

path=Path(__file__).resolve().parents[1]/'experiments'/'cascade_and_epistemic.py'
spec=importlib.util.spec_from_file_location('msc_dynamics',path)
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)

class DynamicsTests(unittest.TestCase):
    def test_protection_can_destabilize_even_with_attenuated_process(self):
        self.assertLess(d.rho(np.array([[.85,.2],[.15,.2]])),1)
        self.assertGreater(d.rho(np.array([[.35,.4],[1.1,.8]])),1)
    def test_stable_individual_modes_do_not_prove_switched_stability(self):
        a=np.array([[.5,1.],[0.,.5]])
        self.assertLess(d.rho(a),1)
        self.assertLess(d.rho(a.T),1)
        self.assertGreater(d.rho(a.T@a),1)
    def test_repeated_same_measurement_is_not_independent_evidence(self):
        self.assertAlmostEqual(d.update(.1,[True]),.5)
        self.assertGreater(d.update(.1,[True]*5),.999)
    def test_graph_and_mediation_remain_nonnegative(self):
        w,same=d.graph(np.random.default_rng(123))
        np.testing.assert_allclose(w.sum(axis=1),1)
        m=d.matrix(w,same,.7,.1,.1,.2,d.CONFIG['variants']['federated_bounded'])
        self.assertTrue(np.all(m>=0))
        self.assertEqual(m.shape,(36,36))
if __name__=='__main__':unittest.main()
