import copy
import unittest
from msc import build_case, evaluate, issue_event
from msc_extensions import source_inventory, create_meta_binding, verify_meta_binding


class MetaBindingExtensionTests(unittest.TestCase):
    def setUp(self):
        self.case = build_case(31)
        self.receipts = evaluate(self.case)['receipts']
        self.inventory = source_inventory()
        self.binding = create_meta_binding(self.case['public'], self.receipts, self.inventory)

    def verify(self, binding=None, public=None, receipts=None, inventory=None):
        return verify_meta_binding(binding or self.binding, public or self.case['public'],
                                   self.receipts if receipts is None else receipts,
                                   inventory or self.inventory)

    def test_complete_binding_valid_and_hardware_unknown(self):
        result = self.verify()
        self.assertEqual(result['status'], 'VERIFIED')
        self.assertEqual(result['hardware_status'], 'UNKNOWN')
        self.assertIn('msc/controller.py', self.binding['body']['software_inventory']['files'])

    def test_signature_tampering_rejected(self):
        self.binding['body']['request_digest'] = '0' * 64
        self.assertEqual(self.verify()['status'], 'CONTRADICTED')

    def test_changed_source_inventory_rejected(self):
        inventory = copy.deepcopy(self.inventory)
        inventory['files']['msc/controller.py'] = '0' * 64
        self.assertEqual(self.verify(inventory=inventory)['status'], 'CONTRADICTED')

    def test_changed_request_rejected(self):
        public = copy.deepcopy(self.case['public'])
        public['request']['amount'] += 1
        self.assertEqual(self.verify(public=public)['status'], 'CONTRADICTED')

    def test_changed_signed_receipt_rejected(self):
        receipts = copy.deepcopy(self.receipts)
        receipts[0]['body']['effect'] = {}
        receipts[0] = issue_event(receipts[0])
        self.assertEqual(self.verify(receipts=receipts)['status'], 'CONTRADICTED')

    def test_truncated_receipts_rejected(self):
        self.assertEqual(self.verify(receipts=self.receipts[:1])['status'], 'CONTRADICTED')

    def test_authorized_signer_false_claim_still_needs_local_comparison(self):
        self.binding['body']['software_inventory_digest'] = '0' * 64
        self.binding = issue_event(self.binding)
        result = self.verify()
        self.assertNotIn('META_SIGNATURE_OR_ROLE', result['errors'])
        self.assertIn('META_BINDING_MISMATCH', result['errors'])


if __name__ == '__main__':
    unittest.main()
