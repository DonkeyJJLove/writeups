import importlib.util
import unittest
from pathlib import Path
path=Path(__file__).resolve().parents[1]/'experiments'/'process_lab.py'
spec=importlib.util.spec_from_file_location('process_lab',path)
lab=importlib.util.module_from_spec(spec);spec.loader.exec_module(lab)

class ProcessLabTests(unittest.TestCase):
    def test_legitimate_process_effect(self):
        result=lab.run_case('legal')
        self.assertEqual(result['status'],'VERIFIED')
        self.assertFalse(result['harmful_effect'])
        self.assertTrue(result['executed'])
    def test_binding_blocks_before_process_write(self):
        result=lab.run_case('precommit_substitution')
        self.assertEqual(result['status'],'CONTRADICTED')
        self.assertFalse(result['executed'])
    def test_post_admission_compromise_detected_without_rewriting_harm(self):
        result=lab.run_case('post_admission_drift')
        self.assertEqual(result['status'],'CONTRADICTED')
        self.assertTrue(result['harmful_effect'])
    def test_missing_postflight_witness_not_success(self):
        result=lab.run_case('witness_unavailable_after')
        self.assertEqual(result['status'],'UNKNOWN')
        self.assertTrue(result['harmful_effect'])
    def test_readiness_gate_prevents_new_effect_without_required_witness(self):
        result=lab.run_case('witness_unavailable_before')
        self.assertEqual(result['status'],'UNKNOWN')
        self.assertFalse(result['executed'])
if __name__=='__main__':unittest.main()
