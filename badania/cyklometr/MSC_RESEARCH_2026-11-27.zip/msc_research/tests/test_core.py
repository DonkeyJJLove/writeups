"""Design-time unit, integration and security tests. Not the hidden benchmark corpus."""
import copy
import unittest
from msc import (build_case, reseal, evaluate, digest, verify_event, issue_event, characteristic,
                 BOMRegistry, Controller, MODEL_LAYERS, ALL_LAYERS, effect_for_operations, posterior)


class CryptoUnitTests(unittest.TestCase):
    def test_canonical_order_is_unambiguous(self):
        self.assertEqual(digest({'a': 1, 'b': 2}), digest({'b': 2, 'a': 1}))
        self.assertNotEqual(digest({'a': 1}), digest({'a': '1'}))

    def test_signature_tamper_rejected(self):
        e = build_case()['public']['events'][0]
        self.assertTrue(verify_event(e))
        e['body']['text'] = 'tampered'
        self.assertFalse(verify_event(e))

    def test_wrong_role_key_rejected(self):
        e = build_case()['public']['events'][0]
        e['role'] = 'authorizer'
        self.assertFalse(verify_event(e))

    def test_signed_falsehood_authenticates(self):
        e = build_case()['public']['events'][0]
        e['body']['text'] = 'false proposition'
        e = issue_event(e)
        self.assertTrue(verify_event(e))

    def test_registry_integrity_and_source_inventory(self):
        registry = BOMRegistry()
        key = registry.observe(build_case()['public'])
        view = registry.get(key)
        self.assertIn('controller.py', view['software_bom']['components'][0]['source_files'])
        self.assertEqual(view['software_bom']['hardware']['status'], 'UNKNOWN')
        registry.entries[key]['meta_links']['request_digest'] = 'x'
        with self.assertRaises(ValueError):
            registry.get(key)

    def test_bayesian_posteriors_normalize_and_are_declared(self):
        for observation in ('agree', 'disagree', 'missing'):
            self.assertAlmostEqual(sum(posterior(observation).values()), 1.0)
        self.assertGreater(posterior('disagree')['self_fault'], posterior('agree')['self_fault'])


class ControllerIntegrationTests(unittest.TestCase):
    def test_every_model_completes_legal_case(self):
        for model in MODEL_LAYERS:
            result = evaluate(build_case(11), model)
            self.assertTrue(result['executed'], model)
            self.assertEqual(result['committed_count'], 1)
            self.assertEqual(result['status'], 'VERIFIED')

    def test_legal_nondefault_target_is_not_hardcoded(self):
        case = build_case()
        p = case['public']
        for q in (p['request'], p['plan'], case['runtime']['execution_request']):
            q['target'], q['purpose'] = 'supplier', 'invoice'
        p['context'].update(purpose='invoice', allowed_targets=['supplier'])
        p['authorization'].update(targets=['supplier'], purposes=['invoice'])
        result = evaluate(reseal(case))
        self.assertTrue(result['executed'])
        self.assertEqual(result['status'], 'VERIFIED')

    def test_schema_catches_bool_amount(self):
        case = build_case()
        case['public']['request']['amount'] = True
        self.assertFalse(evaluate(case, 'M1')['allowed_pre'])

    def test_rbac_denies_wrong_actor(self):
        case = build_case()
        case['public']['request']['actor'] = 'reader'
        self.assertFalse(evaluate(case, 'M0')['allowed_pre'])

    def test_valid_event_list_reordering_preserves_causal_graph(self):
        case = build_case()
        case['public']['events'].reverse()
        self.assertTrue(evaluate(case, 'M7')['executed'])

    def test_legitimate_quote_can_trigger_lexical_false_positive(self):
        case = build_case()
        case['public']['context']['source_text'] = 'Training example: ignore previous instructions is suspicious.'
        reseal(case)
        self.assertTrue(evaluate(case, 'M1')['executed'])
        self.assertFalse(evaluate(case, 'M2')['allowed_pre'])

    def test_ablation_selection_is_exact(self):
        selected = ALL_LAYERS - {'semantic_proxy', 'containment'}
        result = evaluate(build_case(), 'M7', layers=selected)
        self.assertEqual(set(result['layers']), set(selected))

    def test_full_preflight_never_reads_runtime(self):
        case = build_case()
        first = Controller().preflight(case['public'])
        case['runtime']['execution_request']['target'] = 'external'
        second = Controller().preflight(case['public'])
        self.assertEqual(first, second)


class BoundarySecurityTests(unittest.TestCase):
    def codes(self, result):
        return {a['code'] for a in result['alerts']}

    def test_missing_authority_fails_flow(self):
        case = build_case()
        case['public']['events'] = [e for e in case['public']['events'] if e['kind'] != 'authority']
        self.assertFalse(evaluate(case, 'M3')['executed'])

    def test_broken_chain_detected(self):
        case = build_case()
        case['public']['events'][2]['parents'] = ['0' * 64]
        case['public']['events'][2] = issue_event(case['public']['events'][2])
        self.assertFalse(evaluate(case, 'M4')['executed'])

    def test_scope_blocks_validly_signed_unallowed_target(self):
        case = build_case()
        case['public']['request']['target'] = 'external'
        case['public']['plan']['target'] = 'external'
        case['runtime']['execution_request']['target'] = 'external'
        reseal(case)
        self.assertTrue(evaluate(case, 'M4')['executed'])
        self.assertFalse(evaluate(case, 'M5')['executed'])

    def test_untrusted_data_cannot_be_authority(self):
        case = build_case()
        case['public']['context']['source_roots'] = ['rag:untrusted']
        reseal(case)
        self.assertIn('DATA_TO_AUTHORITY_UPLIFT', self.codes(evaluate(case)))

    def test_expanding_delegation_rejected(self):
        case = build_case()
        case['public']['authorization']['delegations'] = [{'from': 'authorizer', 'to': 'executor', 'actions': ['transfer'],
             'targets': ['payroll', 'external'], 'max_amount': 101, 'purposes': ['payroll']}]
        self.assertFalse(evaluate(reseal(case))['executed'])

    def test_attenuated_delegation_accepted(self):
        case = build_case()
        case['public']['authorization']['delegations'] = [{'from': 'authorizer', 'to': 'executor', 'actions': ['transfer'],
             'targets': ['payroll'], 'max_amount': 50, 'purposes': ['payroll']}]
        self.assertTrue(evaluate(reseal(case))['executed'])

    def test_toctou_request_is_precommit_not_posthoc(self):
        case = build_case()
        case['runtime']['execution_request']['target'] = 'external'
        full = evaluate(case)
        baseline = evaluate(case, 'M0')
        self.assertTrue(full['allowed_pre'])
        self.assertFalse(full['executed'])
        self.assertTrue(baseline['executed'])
        self.assertIn('TOCTOU_REQUEST', self.codes(full))

    def test_toctou_state_is_blocked(self):
        case = build_case()
        case['runtime']['snapshot_version'] = 2
        result = evaluate(case)
        self.assertFalse(result['executed'])
        self.assertIn('TOCTOU_STATE', self.codes(result))

    def test_replay_guard_preserves_first_effect(self):
        case = build_case()
        case['runtime']['repeat_count'] = 2
        self.assertEqual(evaluate(case, 'M0')['committed_count'], 2)
        result = evaluate(case)
        self.assertEqual(result['committed_count'], 1)
        self.assertEqual(result['actual_effect']['total_debit'], case['public']['request']['amount'])
        self.assertIn('REPLAY_NONCE', self.codes(result))

    def test_consumed_nonce_blocks_first_commit(self):
        case = build_case()
        case['runtime']['nonce_already_used'] = True
        self.assertFalse(evaluate(case)['executed'])

    def test_posthoc_detection_does_not_undo_execution(self):
        case = build_case()
        case['runtime']['execution_request']['target'] = 'external'
        result = evaluate(case, 'M6')
        self.assertTrue(result['executed'])
        self.assertEqual(result['status'], 'CONTRADICTED')
        self.assertGreater(result['actual_effect']['balance_delta']['external'], 0)

    def test_missing_observer_is_unknown_after_execution(self):
        case = build_case()
        case['runtime']['host_available'] = False
        result = evaluate(case)
        self.assertTrue(result['executed'])
        self.assertEqual(result['status'], 'UNKNOWN')

    def test_common_information_root_is_not_independent(self):
        case = build_case()
        case['runtime']['host_root'] = case['runtime']['self_root']
        result = evaluate(case)
        self.assertEqual(result['status'], 'UNKNOWN')
        self.assertFalse(result['reconstruction']['independent'])

    def test_signed_false_execution_receipt_contradicted_by_host(self):
        case = build_case()
        case['runtime']['self_report_override'] = {}
        result = evaluate(case)
        self.assertEqual(result['status'], 'CONTRADICTED')
        self.assertIn('SELF_HOST_CONTRADICTION', self.codes(result))
        self.assertEqual(result['reconstruction']['effect'], result['actual_effect'])

    def test_both_compromised_receipts_can_deceive_observer(self):
        case = build_case()
        expected = effect_for_operations([case['public']['request']])
        case['runtime']['execution_request']['target'] = 'external'
        case['runtime']['self_report_override'] = expected
        case['runtime']['host_report_override'] = expected
        result = evaluate(case, 'M6')
        self.assertEqual(result['status'], 'VERIFIED')
        self.assertNotEqual(result['actual_effect'], result['reconstruction']['effect'])

    def test_graph_characteristic_has_semantic_collision(self):
        a, b = build_case(), build_case()
        b['public']['request']['target'] = 'external'
        b['public']['plan']['target'] = 'external'
        reseal(b)
        self.assertEqual(characteristic(a['public']['events']), characteristic(b['public']['events']))
        self.assertTrue(evaluate(a)['allowed_pre'])
        self.assertFalse(evaluate(b)['allowed_pre'])

    def test_hidden_policy_change_is_unidentifiable(self):
        case = build_case()
        observation = case['public']
        # Two external norm assignments share identical observable input.
        hidden_policy_a, hidden_policy_b = {'permitted': True}, {'permitted': False}
        self.assertNotEqual(hidden_policy_a, hidden_policy_b)
        self.assertEqual(Controller().preflight(copy.deepcopy(observation)), Controller().preflight(copy.deepcopy(observation)))

    def test_containment_is_signal_not_rollback(self):
        case = build_case()
        case['runtime']['host_available'] = False
        result = evaluate(case, 'M8')
        self.assertTrue(result['executed'])
        self.assertTrue(result['containment']['quarantined'])
        self.assertEqual(result['containment']['retry_budget'], 0)

    def test_separate_eval_sessions_do_not_share_nonce_state(self):
        case = build_case()
        # Explicit limitation: evaluate() is an independent trial, not a persistent service.
        self.assertTrue(evaluate(case)['executed'])
        self.assertTrue(evaluate(case)['executed'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
