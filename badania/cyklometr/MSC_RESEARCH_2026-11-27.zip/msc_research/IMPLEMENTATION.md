# Implementacja referencyjna MSC

## Zakres rzeczywiście wykonanego prototypu

MSC 0.1.0 jest działającym programem Python z syntetyczną księgą transferów. Operacje zmieniają stan słownika księgowego w procesie, a pomiar skutku jest odczytem tego stanu. Nie wysyła pieniędzy, nie kontaktuje się z usługami sieciowymi i nie uruchamia modeli językowych. „Agenci” są rolami i rekordami procesu. Odmienne interpretacje oraz błędy wykonania wprowadza niezależny generator przypadków. Wyniki oznaczają skuteczność mechanizmów na tej skończonej dziedzinie, nie skuteczność wobec naturalnego języka w dowolnym systemie.

Własne testy projektowe obejmują 33 przypadki jednostkowe, integracyjne i bezpieczeństwa; wszystkie zakończyły się powodzeniem. Wyniki są w `experiments/core_design_tests.log`. Zaliczenie testu kontrprzykładu oznacza prawidłowe wykazanie ograniczenia, a nie ochronę przed danym kontrprzykładem. Dotyczy to między innymi wspólnie sfałszowanych świadectw i semantycznej kolizji charakterystyk.

## Moduły

| Moduł | Działanie |
|---|---|
| `src/msc/crypto.py` | Ścisły kanoniczny JSON, SHA-256, podpisy Ed25519, weryfikacja podpisu i treści. |
| `src/msc/fixtures.py` | Jawne poprawne przypadki projektowe i generator grafu źródło–narzędzie, pomocnik ponownego podpisania. |
| `src/msc/graph.py` | Skierowany graf zdarzeń, charakterystyka stopni i typów, osiągalność, projekcje BOM, skróty plików źródłowych. |
| `src/msc/registry.py` | Rejestr widoków BOM adresowany skrótem treści, sprawdzenie integralności odczytu. |
| `src/msc/controller.py` | M0–M8 i warstwy ablacyjne; kontrola przed wykonaniem, rejestr mandatu/nonces, atomowy logicznie guard w pojedynczym wątku. |
| `src/msc/executor.py` | Syntetyczna księga, rzeczywiste w tym procesie transfery, osobne świadectwa wykonawcy i obserwatora. |
| `src/msc/reconstruction.py` | Konfrontacja self/host, wykrycie wspólnego korzenia, odtworzenie zaobserwowanego skutku, ilustracyjny model bayesowski. |
| `src/msc/runner.py` | Rozdział publicznych wejść preflight od danych runtime; pomiar faz, skutek i sygnał izolacji. |
| `src/msc/__main__.py` | Interfejs uruchomieniowy dla przypadku JSON. |
| `examples/bom_demo.py` | Podpisane metapołączenie BOM źródeł z łańcuchem konkretnego wykonania. |

## Odtworzenie

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python -m msc --model M7 --seed 17
PYTHONPATH=src python examples/bom_demo.py
```

Instalacja pakietów wymaga dostępnego repozytorium pakietów lub lokalnego cache. Sam eksperyment nie wymaga sieci. W tej sesji użyto już zainstalowanych bibliotek: Python 3.12.14, cryptography 50.0.0, NumPy 2.3.5, SciPy 1.17.0. NumPy i SciPy służą analizom eksperymentalnym; rdzeń MSC używa biblioteki standardowej i cryptography. Pełny zapis środowiska znajduje się w `experiments/core_environment.json`.

## Rozdział w czasie i skutki

```text
publiczny kontrakt → preflight → guard przy commit → zmiana księgi → świadectwa → postflight → ewentualny sygnał izolacji
```

Funkcja `Controller.preflight` otrzymuje wyłącznie `case['public']`. Nie otrzymuje mutacji wykonawcy, przyszłych świadectw, klasy ataku, etykiety bezpieczeństwa ani ground truth. Dopiero runner pobiera `case['runtime']`. Guard M5/M7/M8 porównuje skrót rzeczywiście przekazywanej operacji i wersję stanu z mandatem oraz zużywa nonce. W pojedynczym wątku sprawdzenie poprzedza commit. Brak blokady/porównania i wymiany między procesami jest jawnym ograniczeniem.

`actual_effect` powstaje z wykonanych operacji księgi, a nie z oświadczeń wykonawcy lub obserwatora. Wykrycie po operacji nie zeruje skutku. Każdy wynik zawiera `committed_count`, `allowed_pre` i fazę każdego alertu. Gdy sensor znika dopiero po wykonaniu, wynik może być jednocześnie `executed=true` i `status=UNKNOWN`. Ponowienie z tym samym nonce może pozostawić pierwszy legalny skutek i zablokować drugi; nie jest to wycofanie pierwszej operacji.

## Konfiguracje i ablacje

M0 sprawdza lokalną listę ról i operacji. M1 dodaje typy i strukturę żądania. M2 dodaje prosty filtr leksykalny; to zadeklarowany proxy semantyczny, nie model rozumiejący tekst. M3 dodaje kontrolę grafu i kolejności przyczynowej. M4 weryfikuje podpisy i łącza pochodzenia. M5 sprawdza relacyjne niezmienniki typowane: źródło, taint, plan, mandat, delegację, kontekst, cel, kwotę i związanie wykonania. M6 porównuje skutki po wykonaniu. M7 łączy warstwy. M8 dodaje lokalny sygnał izolacji i zerowy budżet automatycznych ponowień. Sama propagacja sieciowa jest osobną symulacją, a nie częścią pomiaru tego runnera.

Parametr `layers` w `evaluate` wybiera dokładny zbiór warstw. Pozwala uruchomić pełny model minus jedna warstwa. Modele M2–M6 są wariantami M1 z jedną dodatkową warstwą, a nie kolejnymi krokami kumulacyjnymi. Zapewnia to jawność porównania, lecz modele różnią się uprawnieniami obserwacyjnymi. M6 ma dostęp do świadectw, którego nie ma M0. Zysk takiej konfiguracji jest zyskiem dodatkowej obserwacji i logiki, nie przewagą algorytmu przy identycznej informacji.

## Charakterystyki i granice analogii do cyklometru

Ekstraktor `characteristic` zwraca skrót multizbioru lokalnych stopni i, opcjonalnie, typów zdarzeń. Jest niezmienniczy względem kolejności rekordów i zmiany identyfikatorów, ale nie stanowi pełnego testu izomorfizmu. Ignoruje m.in. treść operacji i część struktury globalnej. Test `test_graph_characteristic_has_semantic_collision` pokazuje identyczną charakterystykę dla procesu legalnego i naruszającego zakres mandatu.

M5 nie podejmuje decyzji na podstawie samego tego skrótu. Używa jawnych predykatów relacyjnych. Nie zaimplementowano kompletnego katalogu klas sprzężenia ani dekodera ukrytego znaczenia. Analogia do cyklometru dotyczy korzystania z obserwowalnych relacji i niezmienników przy niepełnym wglądzie; nie przenosi własności grupy permutacji na dowolny tekst.

## Odtworzenie skutku i model bayesowski

Rekonstruktor porównuje podpisane świadectwo wykonawcy i podpisany odczyt księgi przez rolę host. Zgodność mierzonego skutku z kontraktem jest rozstrzygana osobno od zgodności obu świadectw. Różne podpisy nie są uznawane za wystarczającą niezależność: zadeklarowane korzenie informacyjne muszą być niepuste i rozłączne. Ten test wykrywa jawny wspólny korzeń; nie dowodzi fizycznej ani organizacyjnej niezależności sensorów.

Hipotezy modelu bayesowskiego to zgodność, błąd self, błąd host oraz wspólny błąd. Priory i prawdopodobieństwa obserwacji zostały zadane syntetycznie i zapisane w kodzie. Posterior ilustruje abdukcję, nie jest skalibrowanym prawdopodobieństwem ataku. Wartości nie mogą stanowić podstawy oceny skuteczności w świecie rzeczywistym.

Odtwarzany jest końcowy skutek księgowy. Pełna trajektoria ukrytego stanu agenta pozostaje niewyznaczona. `claimed_event_trajectory` to zgłoszony łańcuch zdarzeń, natomiast `observed_trajectory` obejmuje wyłącznie dostępne świadectwa. Nie wolno raportować ich zgodności jako pomiaru pełnej rekonstrukcji stanów wewnętrznych.

## Zamrożenie i niezależność testu

Źródła `src/msc/*.py` zamrożono 27 listopada 2026 o 21:10:18 UTC, przed ujawnieniem wyników generatora testowego. Zbiorczy SHA-256 manifestu wynosi `ce6f42706f374aaf6600d91217d531ef14f0c0bc6feba62a06261f7e939edfe5`. Autor kontrolera nie odczytywał kodu niezależnego generatora ani jego ground truth przed zamrożeniem. Szczegółowy manifest jest w `experiments/core_freeze_manifest.json`.

Niezależność dotyczy rozdziału ról i danych w tej sesji. Nie jest to zewnętrzna, wieloośrodkowa replikacja ani kryptograficzna izolacja procesów badawczych. Reguły polityki były jawne obu implementacjom. Same klasy zagrożeń były wcześniej wymienione w zadaniu. Generalizacja dotyczy nieujawnionych konstrukcji mutacji, nie dowodu skuteczności wobec wszelkich nieznanych ataków.

## Dodatek po zamrożeniu: uwierzytelnione metapołączenie

`src/msc_extensions/meta_binding.py` jest oddzielnym dodatkiem spoza benchmarku M0–M8. Nie modyfikuje zamrożonego kontrolera. Funkcja `create_meta_binding` podpisuje jedną kopertę obejmującą dokładny inwentarz plików `src/**/*.py`, jego skrót, korzeń zdarzeń, korzeń świadectw, korzeń decyzji oraz skróty żądania, kontekstu i mandatu. `verify_meta_binding` porównuje podpisany obiekt z ponownie wyliczonymi danymi, weryfikując także podpisy związanych rekordów. Zmiana pliku, podmiana poprawnie podpisanego świadectwa lub zmiana żądania unieważnia takie związanie.

Siedem dodatkowych testów w `tests/test_extension_binding.py` zakończyło się powodzeniem. Te testy i przykład `examples/bom_demo.py` potwierdzają działanie metapołączenia jako mechanizmu integralności. Nie są częścią pomiaru skuteczności M0–M8, nie potwierdzają prawdziwości zapisów i pozostawiają sprzętową atestację w stanie `UNKNOWN`.
