# MSC — model formalny i granice rozstrzygalności

Data analizy: 27 listopada 2026, Europe/Warsaw. Status: formalizacja badawcza przygotowana w tej sesji. Twierdzenia niżej odnoszą się do jawnych modeli i założeń, nie stanowią dowodu bezpieczeństwa dowolnego agenta LLM. Inspirację historyczną omawia SOURCE_VERIFICATION.md; implementacyjne przybliżenia opisuje IMPLEMENTATION.md.

## 1. Obiekt badania

System opisuje dynamiczny, skierowany multigraf z typami. V obejmuje agentów, ludzi, narzędzia, zasoby, świadków i wystawców mandatów; E zawiera rozróżnione relacje reads, derives, delegates, authorizes, executes, observes, caused-by i contradicts. L obejmuje typy danych, klasyfikacje i znaczenia operacyjne. A obejmuje tożsamości, mandaty, ich zakresy, odwołania i domeny zaufania. X jest stanem rzeczywistym, częściowo ukrytym. Historia H jest częściowo uporządkowanym zbiorem zdarzeń, a nie koniecznie jedną globalną listą.

```text
G(t) = (V(t), E(t), L(t), A(t), X(t)); O(t) = π(X(t), H(t)); C(t) = Φ(G_obs(t), O(t), H_obs(t))
```

O jest faktycznie dostępną obserwacją. Kontroler nie może wyliczać cech z ukrytego X, jeżeli nie ma odpowiedniego sensora. Zapis Φ(G,X,H) z promptu jest definicją idealną; implementacja operuje na projekcji obserwowalnej. Każde stwierdzenie o zgodności musi podawać zakres obserwacji, wersję polityki, epokę konfiguracji i granicę czasu.

Styk jest przejściem pomiędzy domenami interpretacji, zaufania, uprawnień lub wykonania. Ten sam ciąg bajtów może otrzymać odmienne znaczenie przy innych parserach, kontekstach albo ontologiach. Różnica interpretacji sama w sobie nie stanowi naruszenia: naruszenie występuje, gdy prowadzi do skutku sprzecznego z kontraktem procesu.

```text
I₁(m,c₁) ≠ I₂(m,c₂); violation ⇔ effect(history) ∉ AuthorizedEffects(policy, trusted_context)
```

Wiedza o uprawnieniach systemowych nie musi zawierać mandatu biznesowego. Lokalne RBAC może dopuścić przelew, mimo że dany beneficjent lub cel procesu nie został zaakceptowany przez właściciela zadania.

## 2. Co dokładnie przenosimy z cyklometru

Dla permutacji P i S na tym samym skończonym zbiorze sprzężenie zmienia nazwy elementów, zachowując długości cykli. Jeżeli cykl P ma postać (a₁,...,aₖ), to odpowiedni cykl S⁻¹PS jest złożony z S⁻¹(a₁),...,S⁻¹(aₖ). To dowód niezmienniczości typu cyklowego. Niezależnie od przyjętej konwencji lewo/prawostronnego składania długości cykli pozostają takie same.

```text
cycle_type(S⁻¹ P S) = cycle_type(P)
```

Bezpieczny transfer metodologiczny polega na wybraniu klasy transformacji, które rzeczywiście nie zmieniają właściwości bezpieczeństwa, a następnie pomiarze cech odpornych na te transformacje. Odwracalne przemianowania mogą tworzyć grupę. Zastąpienie implementacji komponentu przez bezpieczne uszczegółowienie kontraktu nie musi być odwracalne ani tworzyć działania grupy; wymaga osobnej relacji symulacji, bisymulacji lub refinement. Nie utożsamiamy tych przypadków ani nie uznajemy interpretacji języka naturalnego za permutację.

W MSC dopuszczalne transformacje obejmują zmianę technicznych identyfikatorów z zachowaniem ich przypisania do ról, zamianę kolejności niezależnych zdarzeń bez zmiany zależności happens-before oraz zastąpienie implementacji narzędzia inną, która zachowuje jawny kontrakt obserwowalny. Zmiana właściciela konta, mandatu, klasyfikacji zaufania lub celu zadania nie jest dopuszczalnym przemianowaniem. Walidacja cech musi zachowywać te etykiety.

Zwykły izomorfizm nieetykietowanego grafu może zachować liczbę węzłów, stopnie i cykle, jednocześnie zamieniając odbiorcę uprawnionego z nieuprawnionym. Widmo macierzy sąsiedztwa, histogram stopni i wektor cykli także mają kolizje. Nie traktujemy ich jako pełnego dowodu równoważności semantycznej. Głębsza analogia historyczna obejmuje właśnie potrzebę dodatkowych obserwacji przy niejednoznacznej charakterystyce.

## 3. Twierdzenie o granicy każdej charakterystyki

Niech Ω będzie zbiorem możliwych przebiegów, Φ:Ω→C charakterystyką dostępną detektorowi, a Safe:Ω→{0,1} własnością bezpieczeństwa. Istnieje doskonały detektor D:C→{0,1}, dla którego Safe=D∘Φ, wtedy i tylko wtedy, gdy Safe jest stała na każdym włóknie Φ.

```text
∃D: Safe = D∘Φ ⇔ ∀ω₁,ω₂: Φ(ω₁)=Φ(ω₂) ⇒ Safe(ω₁)=Safe(ω₂)
```

Dowód konieczności: jeżeli dwie charakterystyki są równe, D otrzymuje ten sam argument i musi zwrócić tę samą odpowiedź. Dowód wystarczalności: dla każdego c z obrazu Φ definiujemy D(c)=Safe(ω), gdzie Φ(ω)=c; stałość na włóknie czyni definicję jednoznaczną. Poza obrazem wartość jest nieistotna.

Konsekwencja: jedna para obserwacyjnie nierozróżnialnych przebiegów, z których tylko jeden jest bezpieczny, falsyfikuje uniwersalną kompletność danej charakterystyki. Nie falsyfikuje jej użyteczności wobec klas naruszeń, które zmieniają obserwowalne relacje. Żaden mocniejszy model językowy nie odzyska brakującej informacji bez dodatkowego sygnału lub założenia.

Dla detektora losowego z identycznymi rozkładami obserwacji czułość na takiej parze jest równa odsetkowi blokad przypadku legalnego. Przy równych priorach minimalny błąd klasyfikacji wynosi 1/2. Dla różniących się rozkładów obserwacji ogólna granica optymalnego błędu Bayesowskiego przy równych priorach zależy od odległości total variation.

```text
P(O|unsafe)=P(O|safe) ⇒ TPR_pair = FPR_pair; BayesError* = (1−TV(P_unsafe,P_safe))/2
```

To twierdzenie o informacji dostępnej w eksperymencie, a nie ogólna nierozstrzygalność bezpieczeństwa maszyn Turinga. Nie wymaga odwoływania się do problemu stopu.

## 4. Co może być egzekwowanym niezmiennikiem

Niezmiennik polityki jest predykatem zachowanym przez dopuszczalne przejścia stanu. Nie jest tym samym co cecha niezmienna względem izomorfizmu. MSC łączy oba pojęcia, ale ich nie utożsamia. Topologia umożliwia porównywanie i lokalizację, a typowany predykat ustanawia, co ma być dozwolone.

| Predykat | Minimalna obserwacja | Granica |
|---|---|---|
| Delegacja nie rozszerza uprawnień | rodzic i dziecko capability, zasób, cel, czas, principal | legalny, lecz błędny mandat pozostaje legalny formalnie |
| Argumenty wykonania odpowiadają autoryzacji | kanoniczna operacja, wersja parsera, kontekst, digest i aktualna epoka | podpis nie naprawia różnicy parserów |
| Dane nie stają się samodzielnie źródłem władzy | pochodzenie i etykiety źródeł, zaufany grant | błędna etykieta w zaufanym rejestrze łamie założenie |
| Decyzja poprzedza zależne wykonanie | identyfikatory zdarzeń, parent links, lokalne liczniki | zegar ścienny sam nie dowodzi przyczynowości |
| Utrata obserwowalności nie rozszerza zakresu działań | świeżość i pokrycie sensorów oraz mapa wymaganych dowodów | nadmierne zamrożenie może naruszyć dostępność |
| Skutek zgadza się z zaakceptowaną operacją | niezależny świadek efektu i kontrakt | detekcja po efekcie nie cofa efektu |
| Reakcja ochronna mieści się w budżecie | scope izolacji, retry budget, rate limit, czas ważności | lokalny limit nie dowodzi globalnej stabilności |

```text
Scope(child) ⊆ Scope(parent); Allowed(O_poor) ⊆ Allowed(O_rich)
commit(a) ⇒ grant_valid(a) ∧ bound_context(a) ∧ epoch_current(a) ∧ preconditions(a)
```

Część właściwości jest relacyjna lub stanowi hyperproperty: wymaga porównania dwóch przebiegów, np. noninterference albo brak wpływu niezaufanego źródła na autorytet przy niezmienionych zaufanych przesłankach. Pojedynczy log nie wystarcza do udowodnienia całej takiej własności. Typowe ślady mogą jedynie wykazać jej naruszenie lub ograniczoną zgodność.

## 5. Modele lepiej dopasowane niż sama permutacja

| Model | Zastosowanie | Ograniczenie |
|---|---|---|
| Typowany graf provenance/autoryzacji | zależności, delegacje, wspólni przodkowie, lokalizacja | kompletność i poprawność etykiet nie są automatyczne |
| Automat stanów i monitor temporalny | auth-before-execution, revocation, jednokrotność | specyfikacja musi obejmować właściwy skutek |
| Częściowy porządek zdarzeń | równoległość, poprawne przeploty | brakująca krawędź nie dowodzi braku zależności |
| Bisymulacja z etykietami bezpieczeństwa | zamienność komponentów względem kontraktu | silna własność, często kosztowna; nie przenosi niezamodelowanych znaczeń |
| Równoważność obserwacyjna | formalne wskazanie, czego obserwator nie rozróżnia | może obejmować zarówno stan bezpieczny, jak szkodliwy |
| Abstrakcja zachowująca bezpieczeństwo | wiele reprezentacji mapowanych do typowanej operacji | nie jest zwykle odwracalna; wymaga udowodnienia soundness |
| Filtr Bayesowski / HMM | hipotezy o ukrytym stanie i zakłóceniach świadków | wynik zależy od modelu oraz kalibracji likelihood |

Niejednoznaczny parser powinien prowadzić do odrzucenia operacji albo do wspólnej kanonicznej reprezentacji sprawdzonej po obu stronach styku. Haszowanie wejściowych bajtów zapewnia tożsamość bajtów; dopiero związanie parsera, schematu i kanonicznych argumentów ogranicza rozbieżności interpretacji.

## 6. Warunkowy dowód prewencji w monitorze referencyjnym

Załóżmy, że stan początkowy spełnia P, wszystkie przejścia powodujące efekty przechodzą przez monitor, monitor jest odporny na modyfikację, polityka P jest kompletna w rozpatrywanym zakresie, autoryzowany argument jest atomowo związany z wykonaniem, a każdy zaakceptowany krok zachowuje P. Wtedy indukcja po kolejnych zatwierdzonych przejściach daje P dla całego przebiegu.

```text
P(x₀) ∧ ∀(x,a): [P(x) ∧ Admit(x,a) ⇒ P(δ(x,a))] ⇒ ∀n: P(xₙ)
```

Jest to użyteczny dowód warunkowy, lecz przenosi ciężar na complete mediation, politykę i atomowość. Kanał omijający executor, kompromitacja monitora, nieuwzględniony efekt asynchroniczny, nieodwoływalna operacja między check a use lub nadmiernie szeroki grant unieważniają odpowiednie przesłanki. Implementacja Python w jednym procesie pokazuje zachowanie tego kontraktu w modelu; nie egzekwuje izolacji systemu operacyjnego.

## 7. Meta-SBOM jako zdarzeniowy model odniesienia

Meta-SBOM jest tu roboczą nazwą warstwy łączącej referencje do kompozycji z rzeczywistym przebiegiem. Widoki Label, Authority, Decision i Execution BOM są projekcjami wspólnej przestrzeni zdarzeń, a nie czterema niezależnymi źródłami prawdy. Ich nazwy nie ustanawiają nowych standardów. Label BOM nie jest przypisywany autorowi jako odrębna teza; istotny jest metapoziom i relacje.

Rekord powinien zawierać typ i wersję schematu, identyfikator sesji, rolę podpisującego, zakres, rodziców, hash payloadu, odwołanie do BOM, hash polityki i kontekstu, licznik, epokę oraz deklarowaną klasę dowodu. Receipt decyzji wiąże zaakceptowaną operację; receipt wykonania wiąże wejścia, deklarowany wynik i obserwacje skutku. Klucze ról muszą mieć odrębne zaufane rejestry.

```text
hᵢ = H(domain || canonical(recordᵢ)); σᵢ = Sign(sk_role, hᵢ)
execution_receipt → decision_digest → policy/context/operation digests
execution_receipt → artifact_digest → SBOM_digest → build_provenance_digest
```

Łańcuch kryptograficzny ogranicza niewykrywalną modyfikację danych przy nieprzejętych kluczach i poprawnym zarządzaniu nimi. Sam nie dowodzi prawdy, kompletności, poprawnego czasu ani braku forków. Wykrywanie rollback/fork wymaga pamięci ostatniego zaakceptowanego stanu lub niezależnego kotwiczenia. Podpisany fałsz pozostaje możliwy. Nie potrzebujemy blockchainu do działania badanego PoC.

## 8. Rekonstrukcja jako problem odwrotny

```text
Yₜ = F(Xₜ,Uₜ,Θ)+εₜ
p(X₀:T,Θ|Y₀:T,U₀:T) ∝ p(Θ)p(X₀) ∏ₜ p(Xₜ|Xₜ₋₁,Uₜ,Θ) p(Yₜ|Xₜ,Uₜ,Θ)
```

Wynik to rozkład hipotez, zbiór trajektorii zgodnych lub minimalny kontrprzykład. Nie jest odczytem wewnętrznego rozumowania LLM. Deklarowany, autoryzowany, obserwowany i zrekonstruowany przebieg muszą pozostać oddzielone; potwierdzony skutek wymaga odpowiedniego świadka. W PoC rekonstrukcja porównuje typowane operacje i niezależny stan ledgera; dodatkowy eksperyment epistemiczny pokazuje rolę zależności sensorów.

Mnożenie likelihood niezależnych obserwacji jest dozwolone tylko przy uzasadnionej warunkowej niezależności. Pięć podpisów agentów powtarzających tę samą odpowiedź API nie stanowi pięciu niezależnych pomiarów. Model musi uwzględniać wspólnego przodka informacyjnego, właściciela i domenę awarii. Różny PID, certyfikat lub nazwa agenta nie gwarantują niezależności epistemicznej.

```text
VERIFIED ⇔ wymagane świadectwa spełniają określony kontrakt przy jawnych założeniach
CONTRADICTED ⇔ istnieje uwierzytelniony kontrprzykład dla sprawdzanej relacji
UNKNOWN ⇔ brak wystarczających lub rozstrzygających świadectw
```

Te statusy opisują konkretną tezę, nie globalną prawdziwość świata. VERIFIED nie może oznaczać, że źródło biznesowe jest prawdziwe, jeżeli kontroler potwierdził jedynie zgodność operacji z podpisanym grantem. UNKNOWN wymaga polityki reakcji: brak nowej władzy, ograniczony zakres, eskalacja lub bezpieczne zatrzymanie. Nie należy usuwać go z mianowników metryk ani utożsamiać z wykrytym atakiem.

W liniowym modelu stanu obserwowalność całego X wymaga pełnego rzędu macierzy obserwowalności. Do bezpieczeństwa wystarczy czasem słabsza własność: nierozróżnialne stany muszą mieć tę samą klasyfikację bezpieczeństwa. Pełna rekonstrukcja wszystkich stanów agenta może więc być zbędna, ale obserwowalność skutków istotnych dla polityki pozostaje konieczna.

## 9. Sprzężenia i stabilność regulatora

Niech x oznacza natężenie zaburzenia procesu w domenach, a q natężenie reakcji ochronnej, retry i obciążenia obserwacji. W lokalnym liniowym przybliżeniu:

```text
zₜ₊₁ = Mₜ zₜ + wₜ; zₜ=(xₜ,qₜ); Mₜ = [[Aₜ−Uₜ, Bₜ], [Kₜ, Rₜ]]
```

W implementowanej nieujemnej wersji tłumienie jest parametryzowane bezpośrednio macierzą A_eff zamiast odejmowania powodującego ujemne współczynniki. A_eff opisuje pozostałą propagację, B wpływ ochrony na obciążenie produkcyjne, K reakcję na zaburzenie, R pamięć i ponawianie reakcji. Dla stałego M brak wymuszenia i rho(M)<1 zapewniają asymptotyczny zanik. Nie oznacza to braku krótkotrwałego wzmocnienia w układach nienormalnych.

```text
M stała: ρ(M)<1 ⇒ Mⁿ→0
Mₜ≥0, ∃w>0,γ<1: ∀t Mₜw≤γw ⇒ ||zₜ||w ≤ γᵗ||z₀||w + bounded_input_term
||z||w = maxᵢ |zᵢ|/wᵢ; bounded_input_term ≤ supₛ ||wymuszenieₛ||w / (1−γ)
```

Warunek wspólnego w jest wystarczający dla przełączanej rodziny nieujemnych macierzy. Sprawdzanie samego rho(Mₜ)<1 w każdej chwili nie wystarcza ogólnie dla arbitralnego przełączania. Dla ogólnych macierzy można użyć wspólnej funkcji Lapunowa lub ograniczeń dwell time; nie dowodzimy ich dla produkcyjnego systemu.

Zmniejszenie A przez izolację może jednocześnie zwiększyć B, K lub R poprzez retry storm i utratę obserwowalności. Dlatego topologiczna interwencja nie jest z definicji stabilizująca. Lokalne regulatory, limity ponowień, histereza, ograniczony zakres izolacji i rezerwa kanału dowodowego są konkretnymi mechanizmami, które można testować. Sama nazwa „odwrócona piramida” nie wyznacza macierzy ani dowodu.

## 10. Minimalne warunki powodzenia

Potrzebne są typowane kontrakty skutków, zaufane źródło mandatu niezależne od swobodnej treści agenta, związanie autoryzacji z dokładnym wykonaniem, kompletność mediacji w określonym zakresie, chronione klucze i rejestr świeżości, przynajmniej jedna użyteczna obserwacja poza kontrolą badanego agenta oraz polityka radzenia sobie z brakami danych. Wymagana jest również wykonalność czasowa i zasobowa monitora oraz kontrola skutków jego reakcji.

Żaden z tych warunków nie wymaga pełnego odczytu wag, embeddingów ani prywatnego procesu rozumowania modelu. Wymaga natomiast wystarczającej obserwowalności bezpieczeństwa. To jest precyzyjny, ograniczony sens tezy o zabezpieczeniu struktury procesu bez poznania pełnej reprezentacji wewnętrznej.

## Źródła i zakres oryginalności

Twierdzenia w §3 i warunkowy dowód w §6 są elementarnymi wyprowadzeniami podanymi w całości, nie roszczeniem do nowości matematycznej. Konstrukcja w §2 odwołuje się do Rejewskiego (1980), https://cryptocellar.org/enigma/files/rew80.pdf. NIST IR 8536: https://doi.org/10.6028/NIST.IR.8536. Taksonomia agentów: https://doi.org/10.6028/NIST.SP.2400-102e2026.ipd. Bliskie podejście provenance/authority: https://arxiv.org/abs/2605.26497. Pozostałe źródła oraz statusy ich odczytu: SOURCE_VERIFICATION.md. Żaden z tych dokumentów nie jest przedstawiany jako zatwierdzenie MSC przez NIST lub autorów historycznych.
