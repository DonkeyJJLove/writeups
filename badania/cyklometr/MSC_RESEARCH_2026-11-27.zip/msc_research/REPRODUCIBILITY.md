# Odtwarzalność MSC

## Środowisko odniesienia

Eksperyment wykonano w Pythonie 3.12.14 na Linuksie x86_64. Użyte wersje bibliotek: `cryptography==50.0.0`, `numpy==2.3.5`, `scipy==1.17.0`. Dokładny zapis środowiska znajduje się w `experiments/environment.json`. Główny prototyp wymaga Python ≥3.11. Testy korzystają ze standardowego `unittest`; pytest nie jest potrzebny.

Do działania eksperymentu nie potrzeba API LLM, klucza płatniczego, połączenia z infrastrukturą LAB, usług chmurowych ani zewnętrznego celu ataku. Klucze Ed25519 powstają deterministycznie z danych testowych i nie stanowią materiału produkcyjnego.

W celu zachowania dostarczonych oryginalnych wyników wykonuj odtworzenie w osobnej kopii katalogu projektu. Polecenia poniżej zakładają bieżący katalog projektu, zawierający `src/`, `tests/` i `experiments/`.

## Instalacja i kontrola podstawowa

```bash
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
PYTHONPATH=src python3 -m unittest discover -s tests -v
PYTHONPATH=src python3 -m msc --model M7
```

Pierwsza instalacja bibliotek może wymagać sieci. Same eksperymenty wykonują się lokalnie. W bieżącym środowisku biblioteki były już dostępne; nie wykonywano odpłatnej inferencji. Kod kontrolera ma własny zestaw 33 testów projektowych, ewaluator ma 8 testów oracle/statystyki/oddzielenia etykiet, a dodatkowy eksperyment procesowy ma 5 testów. Po integracji z dodatkowymi testami formalnymi główny zestaw liczy 57 testów. Dwie próby `process_balance_probe.py` są odrębnym eksperymentem uzupełniającym, a nie dodatkowymi pozycjami tego licznika.

## Dane i benchmark główny

```bash
PYTHONPATH=src python3 -m msc_benchmark.dataset experiments/dataset
PYTHONPATH=src python3 -m msc_benchmark.evaluate .
python3 experiments/postprocess_results.py
python3 experiments/write_statistics_report.py
```

Pierwsze polecenie generuje trzy rozłączne zbiory przykładów i oddzielne pliki ground truth. Drugie wykonuje 55 040 ocen: 120 przypadków projektowych, 120 walidacyjnych i 3200 testowych, każdy w 16 konfiguracjach. W zapisanym wykonaniu trwało to około 82,78 s w samym runnerze, bez czasu tworzenia danych i późniejszej analizy. Czas odtworzenia zależy od sprzętu.

`postprocess_results.py` nie modyfikuje wyników decyzji ani bazowego `BENCHMARK_RESULTS.json`. Tworzy rozszerzony plik `experiments/STATISTICAL_POSTPROCESSING.json`, w którym wartości p mniejsze od zakresu float mają poprawną reprezentację dziesiętną i logarytmiczną. Dodaje również zestawienie etapów alarmów i porównanie czasu dla identycznych prawidłowych transakcji. Podstawowy JSON zachowuje numeryczny wynik SciPy; jego `exact_p=0.0` w skrajnych porównaniach oznacza underflow, a nie matematyczne prawdopodobieństwo równe zeru.

Wyniki główne to `BENCHMARK_RESULTS.csv`, `BENCHMARK_RESULTS.json`, `STATISTICAL_ANALYSIS.md` oraz skompresowane surowe rekordy `experiments/design_raw_results.jsonl.gz`, `validation_raw_results.jsonl.gz` i `test_raw_results.jsonl.gz`. Każdy surowy rekord zawiera wynik API, faktyczny skutek księgi, ocenę oracle, etykietę dostępną wyłącznie ewaluatorowi oraz pomiar czasu.

Ziarna, liczebności i skróty wejść zapisano w `experiments/dataset/DATASET_MANIFEST.json`. Zamrożenie kontrolera z niezależnej części implementacyjnej jest zapisane w `experiments/core_freeze_manifest.json`, a zamrożenie kodu kontrolera, generatora i ewaluatora tuż przed wykonaniem w `experiments/BENCHMARK_FREEZE.json`. `experiments/RUN_COMPLETE.json` potwierdza, że źródła nie zmieniły się w trakcie głównego wykonania.

Decyzje, liczby szkód, statusy i metryki zliczeniowe powinny być identyczne przy tych samych źródłach, zależnościach i ziarnach. Czas, znaczniki UTC i platforma nie będą identyczne. Skrypty nie próbują ujednolicać pomiarów czasu ani podpisywać wygenerowanych wyników kluczem produkcyjnym.

## Interpretacja zaślepienia

Implementator i autor generatora pracowali osobno i nie udostępniali sobie logiki kontrolera ani scenariuszy. Generator używa wyłącznie publicznego kontraktu `API_SPEC.md`. Kontroler nie dostaje ukrytego właściciela rachunku, etykiety ataku, nazwy rodziny ani oczekiwanego bezpiecznego skutku. Ten warunek jest egzekwowany przez funkcję `ensure_no_truth` oraz testy ewaluatora.

Była to separacja proceduralna w tym samym współdzielonym środowisku. Nie ma podstaw do określania jej niezależnym audytem ślepym w sensie organizacyjnym lub sprzętowym. Podział danych obejmuje sześć rodzin niebezpiecznych występujących tylko w teście; nie wszystkie rodziny testowe są niewidziane. Szczegóły i ograniczenia różnorodności opisuje `BENCHMARK_METHODOLOGY.md`.

## Kontrprzykład nierozróżnialności

Para `experiments/dataset/equivalence_pair.json` jest generowana razem z danymi. Ma identyczne obserwowalne wejście w dwóch światach o odmiennym właścicielu beneficjalnym rachunku. Ewaluator wykonuje ją dla M0–M8 i zapisuje `experiments/equivalence_results.json`. Bezpieczny i szkodliwy status świata wynika z operacji i rzeczywistej ukrytej własności; oracle nie używa flagi `malicious` do rozstrzygnięcia.

## Jawne eksperymenty uzupełniające

```bash
PYTHONPATH=src python3 experiments/supplemental_order_probe.py
PYTHONPATH=src python3 experiments/process_lab.py
PYTHONPATH=src python3 experiments/process_balance_probe.py
PYTHONPATH=src python3 experiments/cascade_and_epistemic.py
```

Pierwszy eksperyment wykonuje 27 ocen trzech wariantów porządku zdarzeń. Powstał po zauważeniu słabości głównego generatora: sama zmiana kolejności listy przy zachowanych odnośnikach nie zmienia porządku przyczynowego. Suplement odróżnia takie legalne przestawienie od rzeczywistego grafu `decision→authority`, przy nadal poprawnych podpisach. Nie zmienia kontrolera, danych ani głównego score. Wyniki: `experiments/supplemental_order_results.json`; jawne oznaczenie post hoc i manifest: `experiments/supplemental_order_freeze.json`.

Drugi eksperyment wykonuje rzeczywiste zapisy SQLite przez osobny proces wykonawcy i odczyty przez osobny proces obserwatora. Obejmuje prawidłową operację, podmianę przed commit, zmianę wykonania po dopuszczeniu, fałszywe self-receipt oraz brak obserwatora przed i po działaniu. Wyniki: `experiments/process_lab_results.json`. To także suplement po głównym benchmarku. Oddzielne procesy na jednym hoście nie zapewniają izolacji od wspólnego administratora ani obserwacji jądra systemu.

Dodatkowy `process_balance_probe.py` wykonuje dwie próby: legalną kontrolę oraz rzeczywistą zmianę sald SQLite bez wpisu w logu. Uruchamia oryginalny verifier i oracle, zachowując pierwotny kod i wyniki. Pokazuje ich błędny `VERIFIED` dla nieodnotowanego przelewu, a następnie wykrycie niezgodności przez osobny oracle porównujący salda z zaufanym stanem początkowym i zatwierdzonym skutkiem. To jawny kontrprzykład post hoc; nowy oracle wykrywa skutek po wykonaniu i nie dowodzi kompletnej mediacji. Szczegóły: `SUPPLEMENT_REVIEW.md` i `experiments/process_balance_probe_results.json`.

Skrypt `cascade_and_epistemic.py` wykonuje osobną symulację kaskad oraz epistemiczną symulację estymacji stanu. Obejmuje 3000 przebiegów kaskadowych (pięć wariantów po 600) oraz 150 trajektorii po 60 kroków w modelu ukrytego stanu. Konfiguracje, wyniki i surowe dane trafiają do `experiments/cascade_outputs/`. Są to symulacje o jawnych założeniach przejścia i wiarygodności sensorów, nie pomiary globalnej sieci ani istniejącego systemu agentowego.

## Co pozostaje nieodtworzone jako eksperyment rzeczywisty

Główny benchmark nie mierzy wywołania prompt injection w rzeczywistym LLM, działania mutatorów LAB, odporności prawdziwej infrastruktury, energii, TCO, pełnej rekonstrukcji stanów semantycznych ani przewagi nad opublikowanymi systemami konkurencyjnymi. Poziom `VERIFIED` dotyczy sprawdzonych kontraktów i dostępnych obserwacji. Nie stanowi gwarancji, że nie istnieje nieobserwowana własność zmieniająca bezpieczeństwo skutku.


## Odtworzenie oryginalnych operatorów semantycznych LAB

Poniższe polecenia uruchamiają 39 oryginalnych testów nieefektowego filtra LION oraz 10 jawnych sprawdzeń adaptera. Są odrębne od ślepego benchmarku M0–M8; szczegółowy zakres i pochodzenie opisuje `LAB_MUTATORS.md`. Polecenia zakładają katalog główny projektu.

```bash
(cd lab_evidence/mutator_lion_filter_r1 && python3 -m unittest -v test_filter)
python3 experiments/lab_mutator_adapter/run_transfer.py
```
