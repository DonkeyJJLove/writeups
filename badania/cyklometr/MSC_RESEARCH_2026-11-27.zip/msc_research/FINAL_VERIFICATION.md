# Końcowa weryfikacja pakietu MSC

Weryfikację wykonano 27 listopada 2026 o 22:20 CET (21:20 UTC) w dostarczonym środowisku badawczym. Polecenie `PYTHONPATH=src python -m unittest discover -s tests -v` zakończyło się kodem 0: **57 testów, 57 PASS, bez błędów i pominięć**. Czas raportowany przez unittest wyniósł 0,503 s. Pełny log znajduje się w `FINAL_TEST_RESULTS.txt`, a zapis maszynowy kontroli w `experiments/final_verification.json`.

| Zestaw głównego pakietu | Testy | Wynik |
|---|---:|---|
| Rdzeń MSC: jednostkowe, integracyjne i bezpieczeństwa | 33 | PASS |
| Ewaluator i statystyka benchmarku | 8 | PASS |
| Dynamika i symulacja | 4 | PASS |
| Rozszerzenie podpisanego metapołączenia | 7 | PASS |
| Dodatkowy eksperyment procesowy | 5 | PASS |
| **Razem** | **57** | **PASS** |

Oddzielnie zachowano i sprawdzono wynik **39 oryginalnych testów regresyjnych filtra LION: 39 PASS**, oraz **10 jawnych sprawdzeń adaptera: 10 PASS**. Ich log i wyniki znajdują się w `experiments/lab_mutator_adapter/`. Operatorzy LAB nie wykonali żadnego efektu bezpośrednio. Nie doliczono tych zestawów do 57 testów głównego pakietu ani do liczebności ślepego benchmarku.

## Integralność zamrożenia

Wszystkie **14/14 plików** objętych `experiments/BENCHMARK_FREEZE.json` mają SHA-256 identyczne z zapisanymi przed wykonaniem benchmarku. Dotyczy to dziesięciu plików rdzenia MSC oraz czterech plików generatora/ewaluatora. Zbiorczy skrót dziesięciu plików rdzenia został ponownie wyliczony w tym samym formacie kanonicznego JSON i odpowiada `experiments/core_freeze_manifest.json`.

```text
Rdzeń MSC, zbiorczy SHA-256 mapy nazw i skrótów:
ce6f42706f374aaf6600d91217d531ef14f0c0bc6feba62a06261f7e939edfe5

14 zamrożonych plików, zbiorczy SHA-256 mapy nazw i skrótów:
f2dcaa8a4becac8cf73df7351df8a0ede61c1aa39efcbb4a1f25b9fdae36e196

Manifest danych, zgodny z zamrożeniem:
c3e5505cfd3701d9e33d9e27f6a97e98f7708a8bcbd32a2eadde1496bb3a3064

FINAL_TEST_RESULTS.txt:
aa107fd640d61a59224f50a82d1212753321fdb3cbb4b9958ced9efbe45be6df

Oryginalny semantic_pre_model_filter.py:
6509c009140647956929afa77c81bfd8e93ff683263e383b1f6e596dcfa33ba7
```

Dokładna mapa oczekiwanych i odczytanych skrótów jest zapisana w `experiments/final_verification.json`. Nie zmieniano zamrożonego kodu. Pełnego benchmarku 55 040 ocen nie powtarzano podczas tej końcowej kontroli; zachowano jego wcześniej ukończone wyniki oraz zapis `RUN_COMPLETE.json`. Weryfikacja manifestu danych dotyczy jego bajtów względem zamrożenia, a nie nowej niezależnej kwalifikacji prawdziwości etykiet.

## Środowisko i zależności

| Składnik | Sprawdzona wersja |
|---|---|
| Python | 3.12.14, Clang 22.1.3 |
| Platforma | Linux 6.18.57, x86_64, glibc 2.41 |
| cryptography | 50.0.0 |
| NumPy | 2.3.5 |
| SciPy | 1.17.0 |
| Runner testów | unittest z biblioteki standardowej |

`requirements.txt` oraz `pyproject.toml` już zawierały dokładnie przypięte wersje cryptography, NumPy i SciPy; nie było potrzeby zmiany zależności. SciPy jest rzeczywistą zależnością statystycznej części benchmarku. Dodano do `REPRODUCIBILITY.md` brakujące polecenia uruchomienia oryginalnych testów LAB i adaptera.

## Granice wyniku

Zaliczenie testów potwierdza zgodność wykonanej implementacji z konkretnymi sprawdzeniami. Część testów celowo wykazuje ograniczenia, w tym nierozróżnialność obserwacyjną, prawidłowo podpisane fałszywe świadectwa, słabość samej charakterystyki grafu i brak trwałości nonce między niezależnymi sesjami. Ich PASS nie oznacza usunięcia tych ograniczeń.

Rdzeń benchmarku używa syntetycznych ról, polityk i księgi, a filtr M2 jest proxy leksykalnym. Dodatkowy eksperyment procesowy i podpisane metapołączenie pozostają poza głównym benchmarkiem. Oryginalny LAB operuje na typowanych zmianach grafu i nie jest generatorem ofensywnych payloadów. Nie zmierzono działania rzeczywistego LLM, niezależności sprzętowych sensorów, zużycia energii, odporności produkcyjnej ani skuteczności wobec wszystkich ataków semantycznych.
