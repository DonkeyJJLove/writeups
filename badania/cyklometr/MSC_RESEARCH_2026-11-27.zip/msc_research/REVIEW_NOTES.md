# Niezależny przegląd zakresu twierdzeń MSC

Data: 27 listopada 2026 r. Recenzent tej części przygotował weryfikację literatury, nie implementował kontrolera ani generatora benchmarku. Jest to przegląd przez oddzielną rolę w tej samej sesji i wspólnym środowisku, nie zewnętrzny audyt. Nie zmieniono kodu kontrolera, generatora ani ewaluatora.

## Zakres sprawdzenia

Przeczytano `FORMAL_MODEL.md`, `BENCHMARK_METHODOLOGY.md`, `IMPLEMENTATION.md`, `src/msc_benchmark/evaluate.py`, `src/msc_benchmark/statistics.py`, `src/msc/controller.py`, `runner.py`, `reconstruction.py`, `graph.py` oraz wybrane wyniki JSON. Porównano skróty 14 plików wykonawczych z `experiments/BENCHMARK_FREEZE.json`: podczas przeglądu wszystkie były zgodne. Nie odtwarzano całego przebiegu 55 040 ocen.

**Ocena ogólna:** model formalny ma jasno oddzielone założenia i granice, a benchmark pozwala badać konkretne kontrakty syntetycznej operacji. Najpoważniejsze ryzyko dotyczy interpretacji nazw konfiguracji i metryk jako dowodu działania znacznie szerszej architektury. Należy zachować poniższe ograniczenia w streszczeniu i rozstrzygnięciach głównych, a nie wyłącznie w dokumentacji technicznej.

## Ustalenia wymagające jednoznacznej interpretacji

### 1. Pole `unjustified_pre_authorization` nie mierzy bezpośrednio nieuprawnionych mandatów

W `score()` i `summarize()` wskaźnik jest obliczony z etykiety `malicious` oraz `allowed_pre`. W rodzinie zmieniającej operację dopiero na etapie wykonania publiczne żądanie może być prawidłowo autoryzowane. Późniejszy commit guard może poprawnie zatrzymać zmianę, mimo że przypadek zaliczono do tego wskaźnika.

**Poprawna nazwa opisowa:** „odsetek prób ataku przechodzących preflight”. Nie należy interpretować wartości 37,5% dla M7 jako stwierdzenia, że 37,5% jego mandatów było nieuzasadnionych. Nazwę pola w zamrożonym wyniku można zachować jako historyczny identyfikator, z jawnym wyjaśnieniem definicji. Właściwy pomiar nieuzasadnionej autoryzacji wymaga osobnego oracle normatywnego dla decyzji preflight, rozróżniającego poprawne żądanie od późniejszej podmiany.

### 2. M2 jest leksykalnym punktem odniesienia

`Controller.preflight()` używa jednego wyrażenia regularnego wykrywającego kilka angielskich fraz. Nie ma modelu językowego, klasyfikatora intencji, kalibracji ani mechanizmu obronnego z cytowanej publikacji. FPR M2/M7 nie określa zatem jakości „filtrów semantycznych” jako całej klasy.

Usunięcie `semantic_proxy` w tym zbiorze zachowuje ASR 12,5%, a zmniejsza FPR z 10% do 0% i zwiększa legalne ukończenie z 90% do 100%. To istotny wynik negatywny dla zastosowanego proxy. Nie jest uzasadnieniem tezy, że każda ochrona językowa jest zbędna.

### 3. M5 nie izoluje wkładu charakterystyki grafowej

`characteristic()` tworzy skrót multizbioru stopni i wybranych typów. `Controller` nie wykorzystuje tego skrótu do podejmowania decyzji. M5 obejmuje liczne jawne kontrole kontraktu, źródeł, zakresu delegacji, zgodności żądania i planu, wersji stanu oraz nonce.

Różnica M7 względem `M7_without_typed_invariants` mierzy łączny wkład tego pakietu reguł. Nie jest dowodem przyczynowej skuteczności katalogu charakterystyk, algorytmu cyklometru, dekodera ukrytego znaczenia ani samej topologii. Poprawna konkluzja dotyczy **typowanych kontraktów i związania autoryzacji z wykonaniem**. Test kolizji charakterystyki pozostaje użytecznym wynikiem falsyfikacyjnym.

### 4. M8 jest sygnałem przyszłej interwencji

W `runner.evaluate()` konfiguracja M8 zmienia pole `containment` po wykonaniu operacji i ustaleniu statusu. `retry_budget=0` nie steruje pętlą wykonania w tym benchmarku. Nie modeluje się sieci, wyłączenia krawędzi, przekazywania zakażonej wiadomości ani dalszego ruchu.

Równość M7 i M8 pod względem ASR/TPR/FPR wynika z konstrukcji programu. Wynik nie potwierdza ani nie obala skuteczności interwencji topologicznej. Osobna symulacja kaskad może badać zachowanie modelu dynamicznego, ale nie zamienia tego benchmarku w empiryczne badanie sieci agentów.

### 5. Rekonstrukcja dotyczy końcowego skutku księgowego

Rekonstruktor po sprawdzeniu podpisu kopiuje pole `effect` z host receipt. Ewaluator porównuje je z faktycznym stanem syntetycznej księgi. Wynik 100% trafności dostępnych rekonstrukcji oznacza zgodność tych danych w przebadanych przypadkach, przy osobno raportowanym pokryciu. Nie jest pomiarem rekonstrukcji pełnej trajektorii ukrytego stanu.

Logiczna rola host działa w tym samym procesie. Rozłączne deklarowane `roots` nie dowodzą organizacyjnej, sprzętowej ani statystycznej niezależności. Przy wspólnym błędzie obserwatora i wykonawcy możliwy jest zgodny, podpisany fałsz. Zależność ta została uczciwie opisana w dokumentacji i musi pozostać widoczna przy wyniku liczbowym.

### 6. Wynik warstwy kryptograficznej nie jest wynikiem kompletnego Meta-BOM

M4 w głównym benchmarku weryfikuje podpisy zdarzeń i linki rodzicielskie. Runner nie wywołuje `materialize_bom()` jako warunku dopuszczenia operacji. Rozszerzenie demonstrujące podpisane powiązanie ze składem oprogramowania stanowi osobny artefakt.

Nie należy przypisywać wynikom M4 ani M7 mierzonej przewagi kontroli zgodności sprzętu, measured boot, provenance buildów czy pełnego rejestru BOM. Nie pomierzono też kosztu tych elementów w latencji głównego benchmarku.

## Formalizacja: ocena i doprecyzowania

**Twierdzenie o włóknach charakterystyki jest poprawne.** Konieczność wynika z deterministycznego argumentu detektora, a wystarczalność z jednoznaczności definicji na obrazie funkcji. Wniosek probabilistyczny wymaga tych samych rozkładów obserwacji i jawnych priorów; tekst podaje równe priory przy granicy błędu 1/2. Nie jest to twierdzenie o problemie stopu ani roszczenie do nowej matematyki.

**Warunkowy dowód zachowania niezmiennika jest poprawny** przy kompletności mediacji i prawdziwych przesłankach. Nie stanowi dowodu, że konkretna implementacja operacyjna te przesłanki spełnia. W szczególności atomowość jednowątkowego modelu nie ustanawia atomowości usług rozproszonych.

**Zalecane doprecyzowanie języka transformacji:** grupa jest właściwa dla odwracalnych przemianowań. Zastąpienie komponentu implementacją zachowującą kontrakt nie musi być działaniem grupy. Należy mówić osobno o izomorfizmie lub sprzężeniu oraz o symulacji, bisymulacji czy refinamencie. Bezpieczeństwo zachowane przez jednostronny refinement nie oznacza równości wszystkich charakterystyk.

**Stabilność:** warunek `rho(M)<1` jest właściwy dla stałej macierzy w czasie dyskretnym. Wskazany warunek wspólnego dodatniego wektora dla macierzy nieujemnych jest wystarczającym warunkiem kurczenia w ważonej normie maksimum. Dla czytelności można podać `||z||_w=max_i |z_i|/w_i`, a wymuszenia ograniczyć w tej samej normie. Nie wolno zamienić tego w kryterium „każda macierz chwilowa ma promień mniejszy od 1, więc system przełączany jest stabilny”. Tekst już ostrzega przed tą zamianą.

Źródła tła: Schneider [R36], runtime verification [R38], conformance checking [R39] oraz Åström–Murray [R45] w `SOURCE_VERIFICATION.md`. Żadne z nich nie jest dowodem kompletności MSC.

## Metryki i statystyka

Rozdzielenie ASR od statusu końcowego jest poprawne: wykrycie po commit nie cofa nieuprawnionego skutku. `UNKNOWN` nie jest zaliczane do dodatniej detekcji i pozostaje jawnie raportowane. Wynik oracle opiera się na księdze i normatywnym świecie biznesowym, nie na deklaracji wykonawcy. To mocne strony eksperymentu.

Zestaw zawiera 16 ręcznie zdefiniowanych rodzin ataków oraz warianty parametrów i ziaren. 1600 przypadków nie jest 1600 niezależnymi klasami zagrożeń. Bootstrap po rodzinie i ziarnie opisuje zmienność tej mieszaniny szablonów, bez gwarancji dla populacji ataków produkcyjnych. Dokładny test McNemara per-case zachowuje parowanie, ale jego mała wartość p nie usuwa zależności od wspólnych konstrukcji.

Lokalizacja oznacza dopasowanie do zapisanej taksonomii naruszonych styków. Trafienie w jeden element zbioru dopuszczalnych lokalizacji jest słabsze od pełnej rekonstrukcji przyczyn. Należy prezentować ją wraz z wariantem ścisłej zgodności i wyłączeniami z mianownika.

Wyniki czasowe obejmują wykonany kod Python i lokalną kryptografię. Nie obejmują inferencji LLM, sieci ani kosztu pozyskania niezależnej telemetrii. Brak pomiaru energii i pełnej trajektorii pozostaje oznaczony `null`, co jest właściwe.

## Zalecany zakres końcowego rozstrzygnięcia

Można stwierdzić, że w uruchomionym modelu syntetycznym typowane kontrakty, kontrola granicy wykonania i kryptograficzne sprawdzanie zapisów ograniczyły nieuprawnione skutki względem zdefiniowanych własnych baseline. Można też wskazać wykazane kolizje obserwacyjne, koszt blokowania legalnego cytatu i granicę podpisanego fałszu.

Pozostają nierozstrzygnięte: przewaga nad rzeczywistymi opublikowanymi architekturami, odporność na adaptacyjne ataki na LLM, pełna integracja wykonania z SBOM/HBOM, skala produkcyjna, fizyczna niezależność świadków oraz odrębność naukowa „cyklometru semantycznego” jako nowej klasy. Słowo „potwierdzona” przy hipotezie musi wskazywać konkretną dziedzinę i zmierzoną konfigurację.
