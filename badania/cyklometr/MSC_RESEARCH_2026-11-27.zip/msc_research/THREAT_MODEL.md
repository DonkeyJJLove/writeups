# Model zagrożeń MSC

## Aktywa i granice

Chronione aktywa to uprawniony cel działania, syntetyczne saldo, zakres mandatu, integralność dziennika, powiązanie decyzji z wykonaniem oraz możliwość ustalenia skutku. Granice są interpretacyjne, autoryzacyjne i wykonawcze: tekst–kontekst, kontekst–plan, plan–mandat, mandat–decyzja, decyzja–narzędzie, narzędzie–commit oraz skutek–świadectwo.

W eksperymencie atakujący może zmieniać dostarczone rekordy i treści, wykonywany request, kolejność/relacje zdarzeń, deklaracje pochodzenia i raporty wykonania. Generator ma dostęp do jawnych kluczy testowych, co pozwala badać kryptograficznie poprawne fałszywe deklaracje. Nie jest to próba łamania Ed25519. Modyfikacja po podpisaniu modeluje naruszenie integralności; ponowny poprawny podpis modeluje skompromitowanego lub błędnie działającego uprawnionego autora rekordu.

## Model zaufania

| Element | Założenie operacyjne | Kontrprzykład / ryzyko |
|---|---|---|
| Polityka użytkownika | Zakres i intencja dostarczone do kontrolera odpowiadają normie oceny. | Jednoczesna podmiana celu i poprawnego mandatu może zachować wszystkie obserwacje. |
| Klucze ról | Podpis identyfikuje wystawcę; kod weryfikacji jest nienaruszony. | Uprawniony wystawca może podpisać fałsz. Klucze prototypu są publiczne. |
| Powiązania zdarzeń | Rodzice i etykiety pochodzenia reprezentują rzeczywiste zależności. | Ukryty wspólny przodek lub źle opisane korzenie daje pozorną niezależność. |
| Wykonawca | Wszystkie efekty przechodzą przez kontrolowany commit. | Inny kanał zapisu omija kontroler. |
| Stan i nonce | Jeden wątek wykonania, jedna instancja rejestru w trialu. | Wyścig między procesami, restart lub kolejna niezależna sesja dopuszcza replay bez trwałego magazynu. |
| Obserwator | Host odczytuje skutek bez polegania na deklaracji wykonawcy. | Wspólne przejęcie obserwatora i wykonawcy może podstawić zgodny fałsz. |
| Regulator | Reakcje mają ograniczony koszt i zakres. | Retry storm, nadmierna izolacja lub zależność od jednego obserwatora może obniżać dostępność. |

## Zjawiska rozróżniane w pomiarze

Rozbieżność interpretacji może pozostawić prawidłową składnię i prawidłowe lokalne uprawnienia. Przykładem jest transfer do konta spoza kontraktu przy roli nadal dopuszczonej do wykonywania transferów. M0 może dopuścić taki przypadek, M5 może zablokować relację cel–mandat. Nie wynika stąd, że klasyczny system polityk nie mógłby implementować równoważnych reguł ABAC lub kontroli transakcyjnej.

Fałszywy execution receipt jest innym zagrożeniem niż nieautoryzowany efekt. System może legalnie wykonać zadanie, a następnie utracić rzetelny zapis. Kontroler może wykryć nieprawdziwy zapis, choć nie zapobiega to wcześniejszemu skutkowi. Metryki detekcji i ASR muszą pozostać odrębne.

Brak obserwacji jest stanem epistemicznym. Może oznaczać awarię sensora, celowe wyłączenie albo niekompletną integrację. Nie dowodzi sam w sobie ataku ani bezpieczeństwa. Blokowanie wszystkich takich przypadków może poprawiać konserwatywną prewencję i jednocześnie pogarszać dostępność; eksperyment powinien mierzyć oba skutki.

## Wyłączenia i ograniczenia

Nie badano podatności rzeczywistych modeli językowych na prompt injection, RAG lub memory poisoning. Badano syntetyczne skutki tych klas na publicznych rekordach i operacjach. Nie wykonywano ataków na zewnętrzną infrastrukturę. Nie zastosowano rzeczywistego eBPF, TPM, TEE, logów usług zewnętrznych ani pomiarów energii. Nie ma podstaw do podawania procentowej skuteczności w infrastrukturze produkcyjnej lub skuteczności wykrywania 0-day.

Nie zapewniono stałej kontroli dostępności sensora przed każdą operacją. Zanik po wykonaniu jest raportowany jako `UNKNOWN`, a nie retrospektywna prewencja. Nie zapewniono trwałego, rozproszonego zużywania nonce ani odporności na fork między maszynami. Graf weryfikuje lokalne łącza, ale nie posiada zewnętrznego, append-only dziennika transparentności.

Testy zawierają negatywne wyniki: kolizję charakterystyk przy różnym bezpieczeństwie, prawidłowe podpisy pod fałszem, brak możliwości ustalenia ukrytej normy na podstawie identycznego wejścia, wspólnie podmienione świadectwa oraz brak trwałości registry między niezależnymi wywołaniami runnera. Są to ograniczenia konstrukcji i obserwacji, nie wyniki wymagające ukrycia.

## Interpretacja ewentualnej przewagi

M0/M1 to proste implementacje bazowe, a nie kompletne wzorce najlepszej praktyki przemysłowej. M2 jest leksykalnym proxy. M3/M4 także są uproszczone. Przewaga M7 nad tymi wariantami wykazuje użyteczność dodanych kontraktów i obserwacji w modelu, ale nie rozstrzyga przewagi nad SAGA, ControlValve, produkcyjnym ABAC, transakcyjnym reference monitorem czy rozbudowanym runtime verification. Porównanie z tymi rozwiązaniami wymagałoby ich odtworzenia i uruchomienia na wspólnych agentach oraz zasobach.
