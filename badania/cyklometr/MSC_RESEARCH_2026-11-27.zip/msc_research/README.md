# MSC — pakiet badawczy z 27 listopada 2026

Punktem wejścia jest [RESEARCH_REPORT.md](RESEARCH_REPORT.md). Raport odpowiada na sześć pytań badawczych, podaje zakres dowodów, wyniki negatywne oraz elementy niewykonane.

## Najważniejsze materiały

| Materiał | Zawartość |
|---|---|
| [RESEARCH_REPORT.md](RESEARCH_REPORT.md) | Raport główny: źródła, chronologia, formalizacja, wyniki i rozstrzygnięcia. |
| [FORMAL_MODEL.md](FORMAL_MODEL.md) | Definicje, dowód rozróżnialności, warunki mediacji i stabilności. |
| [SOURCE_VERIFICATION.md](SOURCE_VERIFICATION.md) | 45 źródeł, historia wersji i granice odczytu. |
| [LAB_ANALYSIS.md](LAB_ANALYSIS.md), [LAB_MUTATORS.md](LAB_MUTATORS.md) | Materiały autora, konkretne repozytoria i odtworzony oryginalny filtr LION. |
| [ARCHITECTURE.md](ARCHITECTURE.md), [THREAT_MODEL.md](THREAT_MODEL.md) | Architektura referencyjna, model zaufania i wyłączenia. |
| [BENCHMARK_METHODOLOGY.md](BENCHMARK_METHODOLOGY.md) | Zamrożenie, podział danych i rzeczywisty zakres M0–M8. |
| [BENCHMARK_RESULTS.csv](BENCHMARK_RESULTS.csv), [BENCHMARK_RESULTS.json](BENCHMARK_RESULTS.json) | Wyniki główne w formacie maszynowym. |
| [STATISTICAL_ANALYSIS.md](STATISTICAL_ANALYSIS.md) | Ablacje, niepewność, lokalizacja, koszt i wada scenariusza kolejności. |
| [FALSIFICATION_REPORT.md](FALSIFICATION_REPORT.md) | Kontrprzykłady dla architektury i samego aparatu badawczego. |
| [REVIEW_NOTES.md](REVIEW_NOTES.md), [SUPPLEMENT_REVIEW.md](SUPPLEMENT_REVIEW.md) | Odrębne przeglądy zakresu twierdzeń i suplementów. |
| [REPRODUCIBILITY.md](REPRODUCIBILITY.md) | Polecenia wykonania wszystkich eksperymentów. |
| [FINAL_VERIFICATION.md](FINAL_VERIFICATION.md), [FINAL_TEST_RESULTS.txt](FINAL_TEST_RESULTS.txt) | 57 testów głównego pakietu oraz kontrola zamrożonych hashy. |
| [API_SPEC.md](API_SPEC.md), [IMPLEMENTATION.md](IMPLEMENTATION.md) | Interfejs, moduły i granice implementacji. |

## Zakres kodu i danych

- src/msc/ — zamrożony kontroler i model operacji.
- src/msc_benchmark/ — generator, ewaluator i statystyka.
- src/msc_extensions/ — dodatek podpisanego metapołączenia, poza benchmarkiem.
- tests/ — 57 testów jednostkowych, integracyjnych i bezpieczeństwa.
- experiments/dataset/ — oddzielne wejścia oraz normatywna prawda ewaluatora.
- experiments/*_raw_results.jsonl.gz — wszystkie zapisane oceny głównego przebiegu.
- experiments/cascade_outputs/ — 3000 przebiegów modelu kaskad i 9000 kroków HMM.
- experiments/process_lab* oraz process_balance_probe* — rzeczywiste subprocessy i SQLite, w tym błąd pierwotnego verifiera.
- lab_evidence/ — rejestry pochodzenia, skróty oraz zachowany oryginalny nieefektowy filtr LION.
- sources/ — bibliografia maszynowa i mapa odwołań NIST.
- RESEARCH_BRIEF.txt — oryginalne polecenie badawcze użytkownika.

## Szybkie uruchomienie

Wypakuj archiwum i wejdź do katalogu msc_research. Odtwarzaj w osobnej kopii, aby zachować dostarczone oryginalne pomiary.

~~~bash
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
PYTHONPATH=src python3 -m unittest discover -s tests -v
PYTHONPATH=src python3 -m msc --model M7
~~~

Własności bezpieczeństwa liczb i decyzji są odtwarzalne dla zamrożonej konfiguracji. Latencje i identyfikatory procesów zależą od wykonania. Szczegóły pełnego benchmarku oraz suplementów znajdują się w REPRODUCIBILITY.md.

## Jak czytać wyniki

Badanie wykazuje warunkową przydatność typowanych kontraktów i dodatkowej obserwacji. Nie jest benchmarkiem prawdziwego LLM ani porównaniem z implementacjami SAGA, AuthGraph czy ControlValve. M5 nie podejmuje decyzji z pomocniczego skrótu charakterystyki grafowej. M8 emituje sygnał interwencji. Symulacje dynamiki mają osobne, zadane parametry.

Wynik negatywny jest częścią deliverable: dwa identyczne wejścia mogą mieć różne ukryte znaczenie bezpieczeństwa; poprawny podpis może obejmować fałsz; pierwotny obserwator procesowy ignoruje dostępne salda i daje błędny VERIFIED. Nie ukryto tych wyników ani nie poprawiono po nich zamrożonego benchmarku.

MANIFEST_SHA256.json zawiera skróty wszystkich dołączonych plików poza samym manifestem. Archiwum pomija tylko odtwarzalne pliki cache Python. Hashe potwierdzają integralność kopii; nie są niezależnym znacznikiem czasu, podpisem wydawcy ani dowodem bezpieczeństwa.

