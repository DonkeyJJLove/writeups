# MSC — raport falsyfikacyjny

**Data: 27 listopada 2026 r.** Uniwersalna teza, że badany zestaw niezmienników, zapisów kryptograficznych i obserwatorów zawsze rozróżnia bezpieczny proces od niebezpiecznego, została **SFALSYFIKOWANA**. Wykazano zarówno brak informacji koniecznej do rozstrzygnięcia, jak i niewykorzystanie informacji już dostępnej. Warunkowa użyteczność kontroli kontraktów pozostaje niesfalsyfikowana: w określonej domenie syntetycznych operacji ogranicza ona skutki części ataków. Te dwa wyniki są zgodne.

Raport obejmuje zamrożony benchmark, testy projektowe, odrębne symulacje oraz jawne próby diagnostyczne wykonane później. Nie zmieniano zamrożonego kontrolera ani generatora. M0 jest prostym lokalnym punktem odniesienia RBAC, nie najlepszą możliwą klasyczną architekturą. W benchmarku nie uruchomiono LLM; nazwy rodzin opisują zasymulowane skutki ataków. Rzeczywiste operacje SQLite i podprocesy występują wyłącznie w osobnym eksperymencie. Dokumentacja metod: [BENCHMARK_METHODOLOGY.md](BENCHMARK_METHODOLOGY.md), [REVIEW_NOTES.md](REVIEW_NOTES.md).

Próby post hoc służą znalezieniu i wyjaśnieniu kontrprzykładu. Pojedynczy poprawnie skonstruowany przypadek wystarcza do odrzucenia odpowiedniej tezy uniwersalnej, lecz nie wystarcza do oszacowania częstości niepowodzeń. Dlatego nie łączono ich z głównym mianownikiem ASR, nie traktowano jako niezależnego zbioru generalizacyjnego i nie zastępowano nimi pierwotnych wyników. Zapisy freeze dokumentują integralność artefaktów; nie są niezależnym znacznikiem czasu ani dowodem izolacji badaczy.

## 1. Nierozróżnialność i utrata obserwacji

W rodzinie `hidden_business_ownership` publiczne żądanie pozostaje legalne i niezmienione. Rachunek docelowy ma jednak innego rzeczywistego beneficjenta w normatywnym świecie ewaluatora. W M7 wszystkie **100 przypadków** doprowadziło do nieuprawnionego skutku i otrzymało status **VERIFIED**. Różnica bezpieczeństwa nie wynika z arbitralnej zmiany etykiety: oracle sprawdza ukrytą relację własności rachunku. Ta relacja nie jest dostępna kontrolerowi. [E1, E2]

Osobna para równoważności ma identyczne wejście kontrolera i tę samą wykonaną operację w świecie bezpiecznym i niebezpiecznym. Zmienia się wyłącznie beneficjent. Wynik M7 pozostaje VERIFIED. Wniosek formalny jest ścisły: jeśli dwa przebiegi mają tę samą obserwację, lecz różny status bezpieczeństwa, doskonały detektor oparty wyłącznie na tej obserwacji nie istnieje. Mocniejszy klasyfikator nie uzupełnia nieobecnego źródła wiedzy. Dowód faktoryzacji przez włókna charakterystyki podaje [FORMAL_MODEL.md](FORMAL_MODEL.md), §3. [E3]

W rodzinie `observation_loss` wynik jest inny: **100 szkodliwych wykonań, 100 statusów UNKNOWN**, bez dodatniej detekcji. Scenariusz łączy spójnie skażony zaufany kontekst z niedostępnością hosta; nie izoluje skutku samej utraty sensora. UNKNOWN poprawnie ujawnia brak świadectwa, lecz pojawia się po wykonaniu i nie cofa szkody. Falsyfikowana jest interpretacja „brak potwierdzenia oznacza bezpieczne zatrzymanie”, nie sama zasadność trójwartościowego wyniku. [E1, E2]

## 2. Kolizja charakterystyk i rzeczywisty mechanizm M5

Test `test_graph_characteristic_has_semantic_collision` tworzy dwa procesy: w drugim zmieniono docelowy rachunek na `external`. Po ponownym podpisaniu mają one identyczną wartość `characteristic()`, mimo że pełny kontroler dopuszcza pierwszy i odrzuca drugi. Funkcja wylicza skrót multizbioru lokalnych stopni i wybranych typów. Nie koduje kompletnej semantyki żądania. [E4, E5]

To kontrprzykład dla kompletności tej charakterystyki, bez łamania SHA-256: kolizja wynika z identycznej abstrakcji, nie ze znalezienia kryptograficznej kolizji różnych wejść skrótu. Co więcej, **charakterystyka nie steruje decyzjami M5**. M5 stosuje jawne predykaty dotyczące mandatu, źródeł, delegacji, kontekstu, nonce i związania wykonania. Poprawa wyniku tej konfiguracji nie dowodzi skuteczności katalogu klas grafowych ani dekodowania ukrytego znaczenia. Ablacja usuwa cały pakiet reguł, więc również nie izoluje wkładu hipotetycznego cyklometru. [E5]

## 3. Podpisany fałsz i poprawność lokalna

`test_signed_falsehood_authenticates` potwierdza, że wystawca posiadający uprawniony klucz może podpisać fałszywą treść, a weryfikacja podpisu zakończy się sukcesem. Mocniejszy kontrprzykład, `test_both_compromised_receipts_can_deceive_observer`, podmienia wykonanie na przelew zewnętrzny, po czym self receipt i host receipt zgodnie opisują oczekiwany legalny skutek. M6 zwraca VERIFIED, mimo że `actual_effect` różni się od rekonstrukcji. Testy zakończyły się powodzeniem właśnie dlatego, że oczekiwano ujawnienia ograniczenia. [E4, E6]

Nie jest to złamanie Ed25519. Scenariusz zakłada możliwość wystawienia fałszywych świadectw przez podmioty posiadające odpowiednie klucze. Rozłączne nazwy korzeni informacyjnych nie dowodzą ich fizycznej niezależności. Natomiast przy jednym fałszywym self receipt i prawidłowym hoście test wykrywa sprzeczność. Granicą jest zatem model zaufania do świadków, a nie liczba podpisów. [E4]

Lokalne dopuszczenie aktora `executor` i działania `transfer` nie ogranicza automatycznie beneficjenta ani celu biznesowego. W testach zmieniony przelew przechodzi M0, a poprawnie podpisany przekroczony zakres może przejść M4 i zostać zatrzymany przez M5. M0 osiąga ASR 100% w skonstruowanym zbiorze ataków. Ten wynik pokazuje niedostateczność **tej** listy ról i operacji; nie dowodzi nieskuteczności rozbudowanego RBAC/ABAC, monitorów referencyjnych lub klasycznych polityk transakcyjnych. [E1, E4]

## 4. Detekcja po szkodzie i szkodliwy dodatek ochronny

M6 zwiększa liczbę wykrytych ataków z **100 w M1 do 443**, ale ASR obu wariantów pozostaje **93,75%**. Dodatkowe **343 detekcje następują po szkodliwym wykonaniu**. Rekonstruktor ma wartość diagnostyczną, jednak w tym programie nie jest barierą prewencyjną ani mechanizmem wycofania transakcji. Wysoki TPR bez informacji o fazie interwencji dawałby mylny obraz ochrony. [E1, E7]

Ablacja proxy leksykalnego daje wyraźny wynik negatywny. Usunięcie `semantic_proxy` z M7 zachowuje **ASR 12,5%**, zmniejsza **FPR z 10% do 0%** i zwiększa ukończenie poprawnych zadań z **90% do 100%**. Proxy reaguje m.in. na legalne cytowanie podejrzanych instrukcji. W tej próbce dodana warstwa obniża użyteczność bez zmniejszenia szkód. Nie jest to wynik dotyczący wszystkich filtrów językowych: M2 stosuje krótkie wyrażenie regularne, bez modelu semantycznego. [E1, E4, E5]

Pole `unjustified_pre_authorization` wymaga osobnego zastrzeżenia. Mierzy ono przejście preflight przez próbę oznaczoną jako atak. Poprawne publiczne żądanie może przejść ten etap, a późniejsza podmiana zostać prawidłowo zatrzymana przed commit. Wskaźnika nie należy przedstawiać jako bezpośredniego odsetka nieuprawnionych mandatów. [E8]

## 5. Falsyfikacja interpretacji testu kolejności

Generator rodziny `event_order_violation` zamienia pozycje authority i decision w liście, zachowując podpisane linki rodzicielskie i numery kroków. Jednocześnie zmienia docelowy rachunek. Taki przypadek nie izoluje naruszenia przyczynowej kolejności. Zamiana kolejności serializacji przy zachowanych zależnościach może być legalna, a blokada M7 wynikać z kontroli zakresu. Brak zmiany po ablacji `control_flow` nie dowodzi więc zbędności tej warstwy. [E2]

Oddzielna próba **post hoc** obejmuje trzy przypadki i dziewięć konfiguracji, czyli **27 ocen**. Wszystkie warianty dopuszczają proces pierwotny i legalną zmianę serializacji. Po rzeczywistym przestawieniu przyczynowym, przeliczeniu kroków, linków i podpisów, **M3, M7 i M8** zatrzymują operację z `FLOW_REQUIRED_EDGE`; pozostałe warianty wykonują ją. To potwierdza rozróżnienie konstrukcji testowych i falsyfikuje interpretację „kontrola kolejności nic nie wnosi”. Nie poprawiano wstecz głównego zbioru ani jego wyników i nie doliczano tych prób do jego liczebności. [E9]

## 6. Nowy kontrprzykład: sensor widzi saldo, weryfikator go nie sprawdza

W eksperymencie procesowym worker wykonuje rzeczywisty zapis SQLite. Oddzielny proces obserwatora odczytuje zarówno transakcje, jak i salda. Pierwotny weryfikator ocenia jednak zgodność **listy transakcji** z zatwierdzoną operacją. Jego pole `harmful_effect` także opiera się na tej liście. Udostępnienie szerszych danych nie oznacza, że polityka rzeczywiście je wykorzystuje. [E10]

Próba `process_balance_probe.py` wykonuje dwa jawne przypadki post hoc: kontrolny i z zaburzeniem. Po legalnym przelewie 12 z `ops` na `payroll` dodatkowy podproces przenosi 7 z `ops` na `external`, **bez wpisu w tabeli transakcji**. Oryginalny kod weryfikacji działa bez zmian. Wynik pokazuje:

| Stan po operacji | ops | payroll | external | Suma |
|---|---:|---:|---:|---:|
| Oczekiwany z zaufanego stanu początkowego i mandatu | 988 | 12 | 0 | 1000 |
| Rzeczywisty po dodatkowej modyfikacji | 981 | 12 | 7 | 1000 |

Pierwotny weryfikator zwraca **VERIFIED**, a pierwotny oracle **`harmful_effect=false`**. Błędne salda są już obecne w jego odczycie `observed`; problemem jest niekompletny predykat zgodności. Podpisany agregat utrwala także te dane, ale podpis nie koryguje błędnego statusu. Sama konserwacja sumy również nie pomaga: w obu stanach suma wynosi 1000. [E11]

Nowy, osobny oracle oblicza oczekiwane salda z zaufanego baseline i zaakceptowanej operacji. Dla kontroli zwraca VERIFIED, dla zaburzenia **CONTRADICTED / `harmful_effect=true`**, wskazując niewyjaśnione różnice `ops:-7`, `external:+7`. To detekcja po fakcie, bez rollback. Nie zmieniono oryginalnego `process_lab.py` ani zapisanych sześciu wyników; zgodność potwierdzają hashe w manifeście próby. [E11]

Kontrprzykład jest deterministyczny, lokalny i ograniczony do syntetycznej bazy. Nie jest oszacowaniem częstości ataku ani dowodem izolacji systemowej. Worker emituje **niepodpisany JSON**; dopiero verifier podpisuje agregat. Parametr utraty gotowości świadka w oryginalnym laboratorium jest przełącznikiem scenariusza, nie rzeczywistym health checkiem. Osobny PID przy wspólnym hoście, UID i administratorze nie ustanawia niezależnej domeny zaufania. [E10, E11]

## 7. Ochrona może destabilizować proces

M8 w głównym benchmarku emituje sygnał kwarantanny i pole `retry_budget=0` dopiero w wyniku. Pole nie steruje pętlą wykonania i nie odcina krawędzi sieci. Identyczne ASR M7/M8 jest konsekwencją implementacji; nie dowodzi równoważności architektur z rzeczywistą interwencją. Dynamikę bada osobny, bezwymiarowy model. [E5]

W zapisanym kontrprzykładzie stałego układu liniowego promień spektralny wynosi:

| Wariant | Promień spektralny |
|---|---:|
| Stabilny układ bazowy | 0,893273 |
| Ochrona wzmacniająca reakcje i ponowienia | 1,275446 |
| Ograniczona reakcja lokalna | 0,477069 |

Obniżenie bezpośredniej propagacji może zostać przeważone przez wzrost sprzężeń reakcji ochronnej. Falsyfikowana jest teza „więcej izolacji zawsze stabilizuje”. Drugi kontrprzykład obejmuje dwie macierze o promieniach **0,5 i 0,5**, których iloczyn za dwa kroki ma promień **1,457107**. Stabilność każdego trybu osobno nie zapewnia stabilności przy przełączaniu. [E12]

Również lokalność nie dominuje uniwersalnie. W 600 losowaniach parametrów ograniczony wariant federacyjny był stabilny w **96,17%**, a porównywalny wariant współdzielony z tym samym tłumieniem i limitem retry — w **97,33%**. Są to udziały w zadanej mieszaninie parametrów, nie prawdopodobieństwa awarii produkcji. Wynik rozdziela wpływ topologii od wpływu limitów i przeczy prostemu rankingowi „lokalne zawsze lepsze”. [E12]

## 8. Pięć kopii świadectwa nie stanowi pięciu pomiarów

Symulacja HMM obejmuje 150 trajektorii po 60 kroków i pięć kopii sygnału sensora. Naiwne potraktowanie kopii jako niezależnych daje Brier **0,09899**; model uwzględniający zależność — **0,03372**. Odsetek błędnych skrajnie pewnych rozstrzygnięć wynosi odpowiednio około **9,91% i 0,21%**. Prawdziwie niezależne sensory stanowią osobny wariant, nie interpretację kopiowania danych. [E13]

Wniosek dotyczy podwójnego liczenia dowodu. Założono znane przejścia ukrytego stanu i skalibrowane prawdopodobieństwa sensora. Nie wyuczono modelu kompromitacji LLM ani nie zmierzono wiarygodności produkcyjnej telemetrii. Symulacja falsyfikuje automatyczne mnożenie likelihood powielonej informacji; nie dowodzi skuteczności dowolnego estymatora określanego jako Kryptologika.

## 9. Koszt i zakres niewykonanych falsyfikacji

Dla 160 zwykłych legalnych przypadków mediana czasu M0 wynosi około **0,582 ms**, M7 **1,779 ms**; mediana sparowanej różnicy to **1,175 ms**. Pomiar obejmuje lokalny Python, kryptografię i syntetyczną księgę. Nie jest TCO: nie obejmuje LLM, sieci, kolejek, przechowywania historii, pozyskania niezależnych świadectw ani pełnej obsługi BOM. Energia pozostaje niezmierzona. Nie potwierdzono niewykonalności kosztowej, ale nie wykazano też produkcyjnej opłacalności. [E7]

Nie wykonano adaptacyjnego red teamingu rzeczywistych modeli, prób obejścia izolacji systemu operacyjnego ani porównania z oryginalnymi implementacjami AuthGraph, ControlValve, SAGA czy G-Safeguard. Wyników MSC nie należy przedstawiać jako ich pokonania. Zaliczone testy kontrprzykładów i małe wartości p nie usuwają ograniczeń zakresu modelu.

## 10. Warunki zachowania ograniczonej użyteczności

Kontrprzykłady wskazują konkretne wymagania dalszej architektury:

1. **Obserwowalność właściwej relacji:** mandat musi obejmować rzeczywistego beneficjenta i cel; brak tej wiedzy wymaga UNKNOWN albo ograniczonej operacji.
2. **Zaufany punkt odniesienia:** deklaracje uczestników nie mogą samodzielnie przepisywać normatywnego kontraktu lub stanu początkowego.
3. **Kompletność mediacji:** wszystkie skutki, również zmiany poza logiem i opóźnione zadania, muszą przechodzić przez kontrolę albo zostać niezależnie rozliczone.
4. **Sprawdzenie dostępnych danych:** obserwator musi mierzyć właściwy stan, a verifier porównywać go z zatwierdzoną transformacją; samo zebranie sald nie wystarcza.
5. **Rozdzielenie prewencji od detekcji:** reguły przed commit, idempotencja i świeżość mandatu mają inny zakres niż analiza po szkodzie.
6. **Jawne zależności świadectw:** podpis, PID i certyfikat nie zastępują analizy wspólnych źródeł oraz awarii.
7. **Ograniczenie reakcji ochronnej:** limity retry, opóźnienia i zmiany topologii wymagają warunków stabilności oraz pomiaru dostępności.

**Rozstrzygnięcie:** uniwersalna kompletność MSC, równoważność podpisu z prawdą oraz automatyczna stabilizująca rola każdej ochrony są **SFALSYFIKOWANE**. Warunkowa przydatność typowanych kontraktów i porównywania świadectw pozostaje **niesfalsyfikowana, z dodatnim wynikiem w ograniczonym laboratorium**. Przewaga nad stanem techniki, skuteczność wobec rzeczywistych LLM i status nowej samodzielnej klasy mechanizmów są **NIEROZSTRZYGNIĘTE**.

## Rejestr dowodów

- **[E1]** [BENCHMARK_RESULTS.json](BENCHMARK_RESULTS.json), `splits.test`, `per_family`; [BENCHMARK_RESULTS.csv](BENCHMARK_RESULTS.csv).
- **[E2]** [dataset.py](src/msc_benchmark/dataset.py), rodziny `hidden_business_ownership`, `observation_loss`, `event_order_violation`; [DATASET_MANIFEST.json](experiments/dataset/DATASET_MANIFEST.json).
- **[E3]** [equivalence_results.json](experiments/equivalence_results.json) i [equivalence_pair.json](experiments/dataset/equivalence_pair.json).
- **[E4]** [test_core.py](tests/test_core.py), nazwane testy kryptografii, granic i integracji.
- **[E5]** [controller.py](src/msc/controller.py), [graph.py](src/msc/graph.py), [runner.py](src/msc/runner.py), [reconstruction.py](src/msc/reconstruction.py).
- **[E6]** [core_design_tests.log](experiments/core_design_tests.log): 33 zaliczone testy projektowe, w tym oczekiwane kontrprzykłady.
- **[E7]** [SUPPLEMENTARY_METRICS.json](experiments/SUPPLEMENTARY_METRICS.json), fazy alertów i sparowane pomiary czasu.
- **[E8]** [evaluate.py](src/msc_benchmark/evaluate.py), funkcje `oracle`, `score`, `summarize`.
- **[E9]** [supplemental_order_probe.py](experiments/supplemental_order_probe.py), [supplemental_order_results.json](experiments/supplemental_order_results.json), [supplemental_order_freeze.json](experiments/supplemental_order_freeze.json): 27 odrębnych ocen post hoc.
- **[E10]** [process_lab.py](experiments/process_lab.py), [process_lab_results.json](experiments/process_lab_results.json): pierwotne sześć prób procesowych.
- **[E11]** [process_balance_probe.py](experiments/process_balance_probe.py), [process_balance_probe_results.json](experiments/process_balance_probe_results.json), [process_balance_probe_freeze.json](experiments/process_balance_probe_freeze.json): dwie odrębne próby sald post hoc.
- **[E12]** [cascade_summary.json](experiments/cascade_outputs/cascade_summary.json), [cascade_raw.csv](experiments/cascade_outputs/cascade_raw.csv) i [cascade_and_epistemic.py](experiments/cascade_and_epistemic.py).
- **[E13]** [epistemic_summary.json](experiments/cascade_outputs/epistemic_summary.json), [epistemic_hmm_raw.csv](experiments/cascade_outputs/epistemic_hmm_raw.csv).
