# Architektura referencyjna Meta-SBOM i MSC

## Cel i jednostka kontroli

Jednostką kontroli jest konkretne przejście od informacji do uprawnionego wykonania. Publiczny kontrakt łączy źródła, cel, reprezentację operacji, mandat i wersję stanu. Podpisane rekordy dokumentują deklaracje ról, a obserwacja skutku dostarcza odrębnej przesłanki. Rejestr BOM jest projekcją tych rekordów, nie zamiennikiem kontroli dostępu ani samodzielnym źródłem prawdy.

```text
SOURCE → DATA → CONTEXT → INTERPRETATION → AUTHORITY → DECISION → TOOL → EXECUTION → EFFECT → EVIDENCE
```

Planner tworzy plan, Authorizer wydaje mandat, Executor wykonuje operację, a Verifier wiąże rekordy i konfrontuje skutki. W prototypie role używają oddzielnych kluczy Ed25519, lecz działają w jednym procesie; klucze są jawnie odtwarzalnymi kluczami testowymi. Wdrożenie wymagałoby procesowej lub sprzętowej separacji uprawnień oraz ochrony sekretów.

## Metapoziom, widoki i metapołączenie

Poniższe nazwy oznaczają widoki jednego metamodelu, a nie twierdzenie o odrębnym autorstwie każdej kategorii BOM.

| Widok | Zawartość w prototypie | Czego nie potwierdza |
|---|---|---|
| SBOM / AI-BOM | Wersja MSC i syntetycznej księgi; SHA-256 rzeczywistych plików kodu. Nie użyto modelu AI, więc brak modelowego składnika AI-BOM. | Tożsamości uruchomionej binarki, środowiska boot, modelu produkcyjnego. |
| Label BOM | Etykieta, taint i deklarowane korzenie każdego zdarzenia. | Pełnego znaczenia tekstu ani prawdziwości pochodzenia w skompromitowanym źródle. |
| Identity/Authority BOM | Wystawca, podmiot, zakres, delegacje, ograniczenia, skróty żądania i kontekstu. | Samodzielnie nie wykazuje legalności rzeczywistej intencji użytkownika. |
| Decision BOM | Związane z rodzicami rekordy decyzji i skróty przesłanek. | Wewnętrznego toku obliczeń lub rozumowania modelu. |
| Execution BOM | Role świadectw, żądanie, wersja i raportowany skutek. | Rzeczywistego sprzętu, procesu systemowego lub stanu sieci. |
| Decision Receipt | Podpisany rekord `decision` powiązany z mandatem i kontekstem. | Prawdziwości podpisanej decyzji. |
| Execution Receipt | Podpisane rekordy `execution` i `evidence`. | Niezależności fizycznej źródeł tylko dlatego, że mają różne klucze. |

```text
Agent Execution Chain ↔ signed Meta Attestation ↔ Source-code BOM
```

Przykład `examples/bom_demo.py` wylicza skróty plików źródłowych i łańcucha zdarzeń, tworzy widok BOM adresowany treścią, a następnie podpisuje rekord metapołączenia zawierający obie referencje. Wynik rzeczywistego uruchomienia znajduje się w `experiments/bom_demo_result.json`. Ten podpis wiąże deklarację wykonania z inwentaryzacją źródeł; nie stanowi atestacji uruchomienia tych źródeł na określonym sprzęcie. Pole sprzętowe ma status `UNKNOWN`.

## Mechanizmy według momentu działania

| Faza | Mechanizm | Skutek |
|---|---|---|
| Przed wykonaniem | RBAC, schemat, filtr proxy, wymagane ścieżki grafu, podpisy, delegacje, przepływ taint, zakres i związanie kontekstu. | Może odmówić przekazania operacji do wykonawcy. |
| Bezpośrednio przy commit | Skrót faktycznej operacji, wersja stanu, nonce. | Może zablokować zmianę między akceptacją a wykonaniem lub powtórzenie. |
| Po wykonaniu | Podpisane self/host, zgodność z żądaniem, wykrycie wspólnych korzeni. | Rozstrzyga zgodność obserwowanego skutku; nie cofa wykonanej operacji. |
| Ograniczanie skutków | Sygnał lokalnej izolacji i zerowy budżet automatycznych ponowień w M8. | Może zostać użyty przez regulator dalszej propagacji; sam runner nie modeluje sieci. |
| Rekonstrukcja | Graf pochodzenia i projekcje BOM. | Ułatwia ustalenie naruszonej relacji i hipotez zgodności. |

## Kontrakt semantyczny a pełne znaczenie

Minimalny kontrakt ma postać relacji między polami typowanymi. Przelew musi być zgodny z planem, celem, kontem docelowym, kwotą, zakresem mandatu i wersją stanu. Delegacja może ograniczać, ale nie poszerzać zakresu. Źródło o statusie niezaufanym nie może uzyskać statusu instrukcji autoryzacyjnej bez jawnego mandatu z zaufanego korzenia.

Taki kontrakt pozwala zablokować niektóre skutki rozbieżnych interpretacji bez rekonstrukcji reprezentacji wewnętrznej modelu. Warunkiem jest to, że właściwość bezpieczeństwa została ujęta w kontrakcie i jest obserwowalna. Gdy zmienia się niewidoczny sens biznesowy, a wszystkie obserwowalne pola pozostają identyczne, kontroler nie ma przesłanki do odróżnienia przypadków. Ta granica pozostaje nawet przy bezbłędnej kryptografii.

## Kompletność mediacji i obserwowalność

W syntetycznej księdze wszystkie efekty powstają przez jeden punkt commit. To zapewnia kompletną mediację wyłącznie w granicach modelu. Nie zainstalowano filtrów syscall, eBPF, kontroli kontenerów, proxy sieciowego ani blokad dostępu do zewnętrznych usług. Nie można przenieść kompletności mediacji tego programu na rzeczywisty host.

Obserwator host jest osobną funkcją odczytującą stan księgi. Nie jest systemowym sensorem eBPF ani odseparowanym usługodawcą. Wspólna pamięć i proces są wspólną domeną kompromitacji. `host_report_override` jest celowym mechanizmem laboratoryjnym do sprawdzania tego ograniczenia.

Kontroler rozróżnia `VERIFIED`, `CONTRADICTED` i `UNKNOWN`. `VERIFIED` oznacza zgodność z kontraktem i aktywnymi warstwami, nie absolutne bezpieczeństwo. Brak host-trace daje `UNKNOWN` w warstwie rekonstrukcyjnej. Prototyp może wykryć ten brak dopiero po commit; realizacja zasady „utrata obserwowalności = utrata uprawnień” wymagałaby dodatkowego, świeżego tokenu gotowości sensora przed wykonaniem i anulowania możliwości commit po jego wygaśnięciu.

## Minimalne warunki wdrożeniowe

Wdrożenie musiałoby zapewnić zaufane źródło polityki i mandatu, kompletną mediację operacji, autentyczność oraz świeżość rekordów, nieodwracalną ochronę przed replay między sesjami, spójność kontroli stanu z commit, niezależną obserwację skutku i ograniczony koszt reakcji. Niezależne regulatory lokalne powinny posiadać jawne budżety retry i izolacji. Każdy z tych warunków jest założeniem do zweryfikowania; prototyp realizuje jedynie ich ograniczoną wersję w pojedynczym procesie.

## Granica wyników benchmarku i dodatku integralności

Podpisane metapołączenie zrealizowano w oddzielnym module `msc_extensions.meta_binding`, po zamrożeniu rdzenia MSC. Dodatek wiąże szczegółowy inwentarz źródeł, rekordy decyzji i wykonania, kontekst oraz mandat. Jego siedem testów integralności i podpisany przykład są osobnym wynikiem implementacyjnym. Wartości ASR/TPR/FPR benchmarku M0–M8 nie zawierają tego dodatku.
