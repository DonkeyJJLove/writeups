# META-BOM SEMANTIC CYCLOMETER — raport badawczy

**Data:** 27 listopada 2026, Europe/Warsaw.  
**Reżim:** formalizacja, implementacja, eksperymenty kontrolowane i aktywna falsyfikacja.  
**Status artefaktu:** wykonane badanie prototypu MSC; nie certyfikat ani pomiar wdrożenia produkcyjnego.

## Abstrakt

Zbadano, czy relacje między źródłem informacji, interpretacją, mandatem i wykonaniem pozwalają wykrywać naruszenia bez pełnego poznania wewnętrznego stanu agenta. Opracowano model typowanego multigrafu, warunek rozróżnialności bezpieczeństwa przez charakterystykę oraz działający prototyp z podpisami Ed25519, rejestrem autoryzacji, kontrolą granicy wykonania, obserwatorem i rekonstrukcją skutku. Metapoziom SBOM potraktowano jako wspólny model relacji i projekcji, a nie odrębną autorską tezę Label BOM.

Wykonano 55 040 ocen w dziewięciu konfiguracjach M0–M8 i siedmiu ablacjach, w tym 51 200 ocen na 3200 przypadkach testowych. W modelu syntetycznej księgi M7 obniżyło ASR z 100% dla prostego M0 do 12,5%. Większość poprawy pochodziła z typowanych kontraktów i związania mandatu z wykonaniem. Usunięcie prostego filtra leksykalnego zachowało ASR, a zmniejszyło FPR z 10% do 0%. Przewaga M7 nad samym pakietem M5 wyniosła 3 punkty procentowe i nie była stabilna względem resamplingu rodzin scenariuszy.

Skonstruowano obserwacyjnie nierozróżnialną parę bezpiecznego i szkodliwego procesu, podpisany fałsz, utratę obserwowalności, destabilizację przez ochronę i błąd własnego obserwatora procesowego. W ostatnim przypadku rzeczywiste salda SQLite ujawniały nieuprawnioną zmianę, lecz pierwotna funkcja weryfikacji ignorowała je i zwracała VERIFIED. Ograniczenie dotyczyło więc również wyboru projekcji danych, nie tylko dostępności sensora.

Wykonano ponadto 3000 symulacji kaskad, 9000 kroków filtrowania ukrytego stanu, sześć przypadków z odrębnymi procesami i SQLite oraz osobne próby falsyfikacyjne. Odtworzono oryginalny nieefektowy filtr LION: 39 testów regresyjnych i 10 sprawdzeń adaptera zakończyło się powodzeniem. Wyniki uzasadniają ograniczoną użyteczność kontroli struktury procesu. Nie dowodzą uniwersalnego rozstrzygania semantyki, przewagi nad wdrożonymi architekturami z literatury ani odrębności nowej klasy matematycznej „cyklometru semantycznego”.

## 1. Pytania i końcowe rozstrzygnięcia

Status zawsze dotyczy zakresu opisanego w ostatniej kolumnie. Wynik dla uproszczonego modelu nie jest przenoszony na całą klasę agentów AI.

| Hipoteza | Status | Zakres dowodowy |
|---|---|---|
| Istnieją niezmienniki pozwalające wykrywać naruszenia semantyczne bez pełnego stanu agenta. | **POTWIERDZONA w ograniczonym sensie egzystencjalnym** | Typowane relacje cel–mandat–wykonanie, monotoniczność delegacji, zgodność kontekstu i wersji oraz warunki temporalne. Dowód warunkowy i wykonane przykłady. Nie potwierdzono kompletności dla dowolnego znaczenia. |
| Meta-SBOM może być dynamicznym modelem odniesienia bezpieczeństwa styków. | **CZĘŚCIOWO POTWIERDZONA** | Powstają projekcje zdarzeń oraz podpisane związanie z inwentarzem źródeł. Brak atestacji rzeczywistego sprzętu, buildów i pełnego runtime. Dodatek metapołączenia jest poza głównym benchmarkiem. |
| Kryptologika umożliwia rekonstrukcję i lokalizację naruszeń niewidocznych dla prostych zabezpieczeń. | **CZĘŚCIOWO POTWIERDZONA** | Wykryto rozbieżności operacji i świadectw; M6 rozpoznało 343 dodatkowe przypadki po szkodzie. Rekonstrukcja dotyczy skutku, nie pełnej trajektorii semantycznej. Ścisła lokalizacja M7 wyniosła 20%. |
| Integracja daje mierzalną przewagę nad istniejącymi architekturami. | **NIEROZSTRZYGNIĘTA** | Zmierzono przewagę nad własnymi uproszczonymi baseline. Nie odtworzono SAGA, AuthGraph, ControlValve ani produkcyjnego ABAC na wspólnym benchmarku. |
| Można ograniczać propagację bez destabilizujących reakcji ochronnych. | **CZĘŚCIOWO POTWIERDZONA** | Istnieją stabilne warianty modelu i warunki wystarczające. Istnieją też ścisłe kontrprzykłady destabilizacji; nie przeprowadzono empirycznego pomiaru sieci agentów. |
| Cyklometr semantyczny jest uzasadnioną samodzielną klasą mechanizmów bezpieczeństwa. | **NIEROZSTRZYGNIĘTA** | Użyteczna nazwa programu badawczego. W PoC decyzje M5 pochodzą z kontraktów, nie z nowego katalogu charakterystyk. Brak wyniku oddzielającego go od runtime verification, provenance i kontroli transakcyjnej. |
| Same dostępne charakterystyki i poprawne podpisy wystarczają do bezbłędnego rozstrzygnięcia wszystkich ataków. | **SFALSYFIKOWANA** | Dowód przez parę obserwacyjnie nierozróżnialnych światów oraz wykonane kontrprzykłady. |

## 2. Jakiego rodzaju dowody uzyskano

Rozdzielono pięć poziomów. Dowody matematyczne dotyczą jawnych definicji i założeń. Benchmark obejmuje rzeczywiście wykonany kod Python i kryptografię, lecz syntetyczne procesy, dane i skutki księgowe. Laboratorium procesowe używa rzeczywistych subprocessów oraz SQLite, przy kontrolowanych trybach błędu i wspólnym administratorze hosta. Symulacje dynamiczne i HMM opisują zadane modele liczbowe. Analiza źródeł oraz materiałów LAB ustala pochodzenie i treść koncepcji, bez automatycznego potwierdzania ich skuteczności.

Główny kontroler i generator zostały zamrożone przed oceną testową. Implementator, autor generatora i recenzent źródeł pełnili odrębne role, ale działali w tej samej sesji, przy wspólnym środowisku i dostępnym systemie plików. Jest to **proceduralne rozdzielenie**, nie zewnętrzny audyt w warunkach gwarantowanej izolacji informacyjnej. Ground truth pozostawał poza wejściem badanego API.

Nie wykorzystano inferencji LLM. Nazwy prompt injection, memory poisoning czy RAG poisoning oznaczają kontrolowane perturbacje reprezentujące skutki takich ataków na typowane dane i operacje. Nie mierzono prawdopodobieństwa, że konkretny model ulegnie naturalnojęzykowemu payloadowi. To rozróżnienie ogranicza wszystkie procentowe wyniki raportu.

## 3. Stan wiedzy i weryfikacja źródeł

Kwerenda obejmuje 45 pozycji. Plik [SOURCE_VERIFICATION.md](SOURCE_VERIFICATION.md) rozróżnia pełniejszą lekturę wybranych sekcji, abstrakt, metadane i brak dostępu. Plik [sources/nist_citation_map.json](sources/nist_citation_map.json) obejmuje wszystkie 20 bezpośrednich odwołań z §4.6–4.7 wskazanego projektu NIST. Publikacji „OpenClaw and Ollama in Agentic AI”, cytowanej tam jako [395], nie odczytano; nie uzupełniano jej treści domysłami.

[Rejewski, 1980](https://cryptocellar.org/enigma/files/rew80.pdf) przedstawia użycie permutacji, rekonstrukcję z charakterystyk i cyklometr. Dla MSC istotne jest zarówno zachowanie typu cyklowego przy sprzężeniu, jak wskazana przez autora niejednoznaczność charakterystyk. Historyczna metoda nie jest dowodem, że każda zmiana znaczenia w systemie AI stanowi permutację.

[NIST IR 8536](https://doi.org/10.6028/NIST.IR.8536) to finalny raport opublikowany 9 września 2026 r.; pierwszy projekt pochodzi z 27 września 2024 r. W §4.2.1–4.3.2 oddziela elementy rekordu, typ danych i payload, integralność oraz śledzenie poprzedników. Znaczniki wystąpienia i zapisania zdarzenia znajdują się w §4.2.1. Nie jest to standard nazwany Meta-SBOM ani certyfikacja MSC.

[NIST SP 2400-102e2026](https://doi.org/10.6028/NIST.SP.2400-102e2026.ipd) pozostaje Initial Public Draft z 9 listopada 2026 r. Jego §4.6–4.7 wskazują m.in. topologię, komunikację, autoryzację, przepływ, pamięć i długotrwałe działanie. To mapa zagrożeń i piśmiennictwa, nie dowód kompletności którejkolwiek architektury.

| Mechanizm wcześniejszy | Relacja do MSC | Czego nie wolno wnioskować |
|---|---|---|
| [G-Safeguard](https://aclanthology.org/2025.acl-long.359/) | Wykrywanie przez graf i interwencja topologiczna. | Własne M8 nie jest reimplementacją tej pracy. |
| [ControlValve](https://arxiv.org/abs/2510.17276) | Egzekwowanie planowanego grafu wywołań. | M3 bada prostsze reguły, bez całej architektury autorów. |
| [SAGA](https://www.ndss-symposium.org/ndss-paper/saga-a-security-architecture-for-governing-ai-agentic-systems/) | Polityki i kryptograficzna autoryzacja agentów. | Weryfikacja protokołu nie rozstrzyga dowolnej interpretacji języka. |
| [Firewalls](https://arxiv.org/abs/2502.01822) | Typowanie komunikacji i ograniczenie ujawnianych danych. | Poprawny protokół nie zapewnia prawdy każdej wartości. |
| [Colosseum](https://arxiv.org/abs/2602.15198), [AgentLAB](https://proceedings.mlr.press/v306/jiang26as.html) | Audyt zachowań i długi horyzont ataków. | Nie uruchomiono ich benchmarków ani nie porównano bezpośrednio ich wyników. |
| [AuthGraph](https://arxiv.org/abs/2605.26497) | Rozdzielenie grafu provenance i grafu autoryzacji na poziomie źródeł parametrów. | To bliski antecedens, którego nie można pominąć w roszczeniu o nowości. |

AuthGraph w załączniku B.2 wyłącza przypadki autoryzowanego wykorzystania zatrutej obserwacji przy zgodnej projekcji narzędzi, źródeł i mandatu. Nasza analiza podobnej granicy jest własnym wyprowadzeniem i kontrprzykładem dla MSC, a nie dowodem przeciwko zakresowi, którego autorzy tamtej pracy nie deklarują.

[CycloneDX 1.7](https://www.cyclonedx.org/docs/1.7/json/) ma już reprezentacje workflow i stanu operacyjnego; [BOM-Link](https://www.cyclonedx.org/capabilities/bomlink/) wiąże dokumenty i ich elementy. [SPDX 3.0.1](https://spdx.github.io/spdx-spec/v3.0.1/model/AI/AI/), [SLSA 1.2](https://slsa.dev/spec/v1.2/), [in-toto](https://www.usenix.org/conference/usenixsecurity19/presentation/torres-arias) i [Sigstore](https://docs.sigstore.dev/about/threat-model/) dostarczają wcześniejszych struktur inwentarza, budowy, pochodzenia i podpisów. Samo rozszerzenie BOM o czas i relacje nie wystarcza zatem do uzasadnienia nowości.

Podstawy teoretyczne obejmują monitory wykonania, kontrolę przepływu informacji, runtime verification, conformance checking, estymację stanu i stabilność. Dokładne pozycje R36–R45 oraz zakres lektury podaje dokument źródłowy. MSC jest badawczą integracją tych narzędzi z materiałami LAB; nie przedstawia ich jako nowo odkrytych metod.

## 4. Chronologia i rzeczywiste materiały LAB

[LAB_ANALYSIS.md](LAB_ANALYSIS.md) zawiera dokładne commity, drzewa, nazwy dokumentów i odnośniki. [lab_evidence/evidence_index.json](lab_evidence/evidence_index.json) rejestruje materiał dowodowy. Daty commitu, mtime, nazwy pliku i wpisu w treści nie są utożsamiane z niezależnym dowodem pierwszeństwa.

| Odnaleziony etap | Treść potwierdzona w materiale |
|---|---|
| 19 stycznia 2026, najwcześniejszy odnaleziony commit wskazanego artykułu | SBOM jako relacyjny odcisk i sensor struktury, zmiana oraz gate. |
| 25 stycznia 2026, Appendix Kryptologia | Zdarzeniowy SBOM, tożsamość artefaktu i rekonstrukcyjna rama interpretacyjna. |
| Maj 2026, Cyber-Tiger | Historyczny log; rzeczywiste fixture wspólnych zależności semantyki reguł i danych wejściowych. |
| Czerwiec–lipiec 2026 | Filtry interferencyjne, metapołączenie, IOAC, definicja Kryptologiki i jawne widoki BOM/receipts. |
| Sierpień 2026 | LION control mesh i JARZMO-MESH: rozdzielenie modelu od autorytetu, obserwowalność i lokalne regulatory. |
| Październik 2026 | Kod federacji oraz oryginalny typowany filtr LION. |
| 27 listopada 2026 | Obecny MSC, uruchomione eksperymenty i jawne falsyfikacje. |

Pierwszy projekt NIST IR 8536 z 2024 r. jest wcześniejszy od odnalezionego styczniowego commitu. Nie porównano wszystkich wersji zdanie po zdaniu, więc nie stwierdza się, że każdy szczegół wersji finalnej istniał już w projekcie. Materiały użytkownika dokumentują rozwój własnego programu badawczego, lecz nie ustanawiają automatycznie pierwszeństwa wobec całej literatury.

Odczytano wskazane fragmenty repozytoriów sbom, writeups, ai_platform i SymulacjaKaskadySieciowej przy utrwalonych HEAD. Kod rozdziela reprezentację i deklarację od źródła autorytetu oraz efektu. Nie przeniesiono historycznej mapy LION v1.4 na rolę właściciela architektury v1.5. Nie odtwarzano całego CI ani działającej federacji.

Dodatkowe poszukiwanie na dostępnym hoście odnalazło LION_SEMANTIC_PRE_MODEL_FILTER_R1. Wczytano kompletny interpreter, specyfikację, kompilator, testy, README, manifest i tekst źródłowy. Siedem plików objętych manifestem zachowało dokładne rozmiary i SHA-256. Lokalnie wykonano 39 oryginalnych testów oraz 10 sprawdzeń adaptera, wszystkie z wynikiem PASS. Źródła na hoście użytkownika pozostały bez zmian.

Operator mutate obejmuje ADD, UPDATE, SUPERSEDE, CONTRADICT, RETRACT i REVALIDATE. Jest operatorem typowanego grafu, przyjmuje już zinterpretowane percepty i nie nadaje authority/effect. Nie jest ofensywnym generatorem payloadów ani parserem dowolnego języka. Sprawdzony adapter wiąże jego nieefektową projekcję z kontekstem MSC; zmiana kontekstu unieważnia wcześniejsze związanie mandatu. Szczegóły: [LAB_MUTATORS.md](LAB_MUTATORS.md).

Nie ustalono odrębnego, odtwarzalnego komponentu SPECTA lub Agent-Gate ani ofensywnego zestawu mutatorów w wykonanym ograniczonym poszukiwaniu. Nie oznacza to ich nieistnienia. Główny generator perturbacji MSC jest nową implementacją i nie został przypisany tym projektom. Oryginalne fixture Cyber-Tiger odczytano, ale zależnego silnika tych testów nie uruchomiono.

## 5. Model formalny i właściwy transfer z Rejewskiego

Pełne definicje, dowody i warunki znajdują się w [FORMAL_MODEL.md](FORMAL_MODEL.md). Rozróżniamy stan rzeczywisty od dostępnej projekcji:

~~~text
G(t) = (V(t), E(t), L(t), A(t), X(t))
O(t) = π(X(t), H(t))
C(t) = Φ(G_obs(t), O(t), H_obs(t))
~~~

Węzły obejmują agentów, narzędzia, zasoby i świadków. Typowane krawędzie odróżniają odczyt, pochodzenie, delegację, autoryzację, wykonanie i obserwację. Styk jest przejściem między domenami interpretacji, zaufania lub skutku. Sama różnica I₁(m,c₁)≠I₂(m,c₂) nie jest atakiem; staje się naruszeniem, gdy wynik wykracza poza uprawniony kontrakt.

Sprzężenie permutacji zachowuje typ cyklowy. W agentach dopuszczalna analogia obejmuje przemianowanie technicznych identyfikatorów z zachowaniem ról lub zmianę serializacji niezależnych zdarzeń bez zmiany ich zależności. Zastąpienie implementacji bezpiecznym uszczegółowieniem kontraktu wymaga osobnej relacji symulacji albo refinement; nie musi być odwracalne i nie jest automatycznie działaniem grupy.

~~~text
cycle_type(S⁻¹PS) = cycle_type(P)

∃D: Safe = D∘Φ
⇔ ∀ω₁,ω₂: Φ(ω₁)=Φ(ω₂) ⇒ Safe(ω₁)=Safe(ω₂)
~~~

Drugie twierdzenie wyznacza granicę detektora. Konieczność wynika z tego, że jednakowe wejście daje jednakową decyzję. Wystarczalność wynika z jednoznaczności definicji decyzji na każdej klasie charakterystyki. Dla nierozróżnialnej bezpiecznej i szkodliwej pary detektor losowy ma TPR równy FPR; przy równych priorach minimalny błąd wynosi 1/2. To argument o dostępnej informacji, nie o nierozstrzygalności ogólnego programu.

Niezmiennik charakterystyki i niezmiennik polityki są różne. Histogram stopni jest odporny na wybrane przemianowania, ale nie określa mandatu. Predykat „delegacja nie poszerza uprawnień” ustanawia warunek dopuszczalnego przejścia, lecz nie musi być cechą nieetykietowanej topologii. PoC M5 używa tej drugiej klasy: typowanych reguł kontraktu. Pomocniczy skrót charakterystyki grafowej nie uczestniczy w jego decyzji.

Przy kompletności mediacji, prawidłowej polityce, nienaruszonym monitorze i atomowym związaniu check–commit można indukcyjnie dowieść zachowania własności P przez wszystkie dopuszczone przejścia. Kanał poza monitorem, fałszywy korzeń autorytetu lub efekt niewidoczny dla kontraktu unieważnia odpowiednią przesłankę. Dowód nie ustanawia samodzielnie tych przesłanek w systemie operacyjnym.

### Macierz Rejewski — NIST — Kryptologika/MSC

Macierz jest interpretacją projektową obecnego badania.

| Relacja | Rejewski | NIST | Kryptologika / MSC |
|---|---|---|---|
| Ukryty stan i obserwacje | Charakterystyki ograniczają zbiór konfiguracji. | Traceability umożliwia analizę poprzedników zdarzenia. | Rozdzielenie deklaracji, mandatu, obserwacji, rekonstrukcji i skutku. |
| Niezmienność | Ścisła własność sprzężenia permutacji. | Brak analogicznego twierdzenia o semantyce agentów. | Osobny dowód dla dozwolonych transformacji i typów. |
| Integralność | Nie jest współczesnym protokołem attestacji. | Powiązania rekordów i identyfikatory. | Podpisy wiążą dane; niezależny dowód musi dotyczyć skutku. |
| Niejednoznaczność | Możliwe wspólne charakterystyki różnych ustawień. | Pochodzenie nie rozwiązuje każdego problemu interpretacji. | Klasy równoważności, UNKNOWN i kontrprzykłady nierozróżnialności. |
| Interwencja | Rekonstrukcja kryptologiczna. | Taksonomia wielu metod ochrony. | Monitor przed commit, rekonstrukcja po nim, odrębny regulator reakcji. |

## 6. Architektura metapoziomu SBOM

Łańcuch kontrolowanych relacji ma postać:

~~~text
SOURCE → DATA → CONTEXT → INTERPRETATION → AUTHORITY
→ DECISION → TOOL → EXECUTION → EFFECT → EVIDENCE
~~~

Planner proponuje działanie. Authorizer wiąże mandat z zaufanym celem, kontekstem, argumentami i wersją stanu. Executor sprawdza związanie bezpośrednio przed commit. Verifier porównuje deklaracje i obserwacje. W głównym PoC role mają osobne klucze testowe, lecz działają w jednym procesie, więc nie tworzą fizycznie niezależnych domen bezpieczeństwa.

| Warstwa | Model odniesienia | Główna granica |
|---|---|---|
| SBOM / AI-BOM | Skład, wersje i skróty artefaktów. | Bez LLM w eksperymencie nie ma rzeczywistej inwentaryzacji modelu AI. |
| Label BOM | Pochodzenie, etykiety i przekształcenia. | Etykieta nie dowodzi pełnego znaczenia. |
| Identity/Authority BOM | Principal, issuer, delegacje, zakres, kontekst, epoka. | Prawidłowo podpisany, lecz błędny mandat nadal może szkodzić. |
| Decision BOM | Zależności decyzji i zaakceptowana operacja. | Nie jest pełnym odczytem wewnętrznego stanu modelu. |
| Execution BOM | Użyte role, narzędzia, stan i świadectwa. | Deklaracja komponentu wymaga potwierdzenia jego rzeczywistego użycia. |
| Decision Receipt | Świadectwo konkretnej decyzji. | Nie zastępuje normy biznesowej. |
| Execution Receipt | Świadectwo deklarowanego wykonania i obserwacji. | Podpis nie zapewnia niezależności ani prawdy sensora. |

Są to projekcje jednej przestrzeni zdarzeń. Nie traktujemy Label BOM jako oddzielnej autorskiej tezy. Wspólny metapoziom może materializować różne widoki, ale zgodność kilku projekcji tego samego fałszywego źródła nie staje się kilkoma niezależnymi dowodami.

Dodatek msc_extensions.meta_binding podpisuje kopertę łączącą inwentarz plików, korzenie zdarzeń, decyzji i świadectw oraz skróty żądania, mandatu i kontekstu. Wykonany przykład znajduje się w experiments/bom_demo_result.json. Siedem testów dodatku sprawdza integralność. Dodatek powstał po zamrożeniu rdzenia i nie wpływa na podane ASR. Pole sprzętu pozostaje UNKNOWN. Nie wdrożono zgodnego eksportera CycloneDX/SPDX, weryfikacji measured boot ani dowodu, że wskazane źródła odpowiadają uruchomionej binarce.

Metapołączenie wykonania i pochodzenia oprogramowania jest więc zrealizowane jako sprawdzalne związanie deklaracji. Pełne Agent Execution Chain ↔ Software/Hardware Provenance Chain pozostaje zadaniem dalszym.

## 7. Zagrożenia i zaufanie do kontrolera

Model przeciwnika obejmuje zmianę wejściowych rekordów, źródła kontekstu, planu, delegacji, faktycznej operacji, deklaracji skutku i dostępności obserwatora. Jawne klucze testowe pozwalają również utworzyć fałszywe, lecz poprawnie podpisane rekordy. Nie jest to złamanie Ed25519.

Główne ryzyka to awans danych do autorytetu, zbyt szeroki mandat, konflikt parserów, TOCTOU, replay, ominięcie commit, wspólna kompromitacja świadków i błędna polityka reakcji. Rejestr nonce działa w instancji trialu; restart lub nowa instancja nie zachowują zużycia. Brak zewnętrznego dziennika transparentności ogranicza wykrywanie forków i rollback. Nie zainstalowano kontroli syscalls, eBPF ani systemowego mechanizmu blokującego alternatywny zapis.

Status VERIFIED oznacza zgodność konkretnej tezy z zakresem kontroli. CONTRADICTED oznacza znalezioną sprzeczność. UNKNOWN oznacza brak wystarczającego rozstrzygnięcia. Nie są to globalne stany świata. Główny PoC dowiaduje się o brakującym świadku dopiero po wykonaniu. Potrzebna polityka odbierania uprawnień przed commit nie jest w nim kompletnie egzekwowana.

[THREAT_MODEL.md](THREAT_MODEL.md) i [ARCHITECTURE.md](ARCHITECTURE.md) podają szczegóły tych założeń. Testy negatywne celowo pokazują, które z nich można złamać.


## 8. Protokół benchmarku i operacjonalizacja M0–M8

Generator utworzył 120 przypadków projektowych, 120 walidacyjnych i 3200 testowych. Zbiór testowy zawiera 1600 prób niebezpiecznych: 16 nazwanych rodzin po 100 wariantów, oraz 1600 legalnych: 10 rodzin po 160 wariantów. Sześć rodzin testowych nie występowało wcześniej. Każdy przypadek oceniono w dziewięciu modelach i siedmiu ablacjach. Łącznie wykonano 55 040 ocen w 82,78 s; liczba testowych ocen wynosi 51 200. Są to rzeczywiste czasy i liczniki runnera, nie oszacowanie.

W fazie preflight kontroler otrzymywał wyłącznie publiczną strukturę przypadku. Kontrola commit otrzymywała wykonywaną operację i wersję stanu, a postflight — świadectwa. Nazwa rodziny, etykieta ataku, norma biznesowa oraz mapa rzeczywistego beneficjenta pozostawały u ewaluatora, poza tymi wejściami. Oracle porównywał faktyczny stan syntetycznej księgi z tą normą; deklaracja wykonawcy nie wystarczała do ustalenia szkody. Testy sprawdzają rozdzielenie pól i deterministyczność danych. Implementator nie korygował zamrożonego rdzenia po wynikach testowych.

| Model | Rzeczywiście zaimplementowana konfiguracja |
|---|---|
| M0 | Prosty RBAC/ALLOW–DENY dla roli i rodzaju operacji. |
| M1 | M0 oraz walidacja schematu. |
| M2 | M1 i leksykalne proxy wybranych instrukcji atakujących. |
| M3 | M1 i kontrola typowanych ścieżek/porządku grafu. |
| M4 | M1 i weryfikacja podpisów oraz linków zdarzeń. Nie pełne egzekwowanie Meta-SBOM. |
| M5 | M1 i pakiet typowanych kontraktów, delegacji, związania kontekstu, stanu oraz nonce. |
| M6 | M1 i rekonstrukcja z logicznie odrębnego świadka księgi. |
| M7 | Integracja zaimplementowanych warstw M0–M6. |
| M8 | M7 i wyjściowy sygnał lokalnej izolacji/budżetu reakcji. Sygnał nie steruje siecią ani pętlą wykonania. |

Nazwy konfiguracji pochodzą z programu badawczego. Nie oznaczają kompletnego wdrożenia wszystkich funkcji zamówionej architektury. Szczególnie M2 nie jest modelem semantycznym, M5 nie opiera decyzji na katalogu charakterystyk, a M8 nie wykonuje topologicznego containment w tym runnerze.

Metodologia i hashe: [BENCHMARK_METHODOLOGY.md](BENCHMARK_METHODOLOGY.md), experiments/BENCHMARK_FREEZE.json i experiments/dataset/DATASET_MANIFEST.json. Dane wejściowe i ground truth zapisano w oddzielnych JSONL; surowe oceny zachowano w JSONL.gz.

## 9. Wyniki główne

ASR jest odsetkiem prób prowadzących do szkodliwego skutku. TPR oznacza rozpoznane naruszenie, także po wykonaniu. FPR liczy legalne przypadki oznaczone jako sprzeczne. UNKNOWN raportuje brak rozstrzygnięcia i nie jest zaliczany do dodatniej detekcji. Legalne ukończenie mierzy wykonanie prawidłowego zadania, nie otrzymanie pełnego dowodu VERIFIED.

| Model | ASR | TPR | FPR | Legalne ukończenie | UNKNOWN, wszystkie przypadki |
|---|---:|---:|---:|---:|---:|
| M0 | 100,00% | 0,00% | 0,00% | 100,00% | 0,00% |
| M1 | 93,75% | 6,25% | 0,00% | 100,00% | 0,00% |
| M2 | 87,50% | 12,50% | 10,00% | 90,00% | 0,00% |
| M3 | 93,75% | 6,25% | 0,00% | 100,00% | 0,00% |
| M4 | 90,75% | 9,25% | 0,00% | 100,00% | 0,00% |
| M5 | 15,50% | 84,50% | 0,00% | 100,00% | 0,00% |
| M6 | 93,75% | 27,69% | 0,00% | 100,00% | 14,91% |
| M7 | 12,50% | 87,50% | 10,00% | 90,00% | 13,13% |
| M8 | 12,50% | 87,50% | 10,00% | 90,00% | 13,13% |

Źródło wszystkich wartości: [BENCHMARK_RESULTS.csv](BENCHMARK_RESULTS.csv) i [BENCHMARK_RESULTS.json](BENCHMARK_RESULTS.json). M7 ma precision 89,74%, recall 87,5%, F1 88,61% i FNR 12,5%. UNKNOWN wśród ataków wynosi 6,25%, a wśród przypadków legalnych 20%; nie należy usuwać tych przypadków z mianowników.

M7 zatrzymuje szkodliwy skutek w 1400 z 1600 prób. Przepuszcza dwie rodziny po 100 przypadków: niewidoczną zmianę właściciela rachunku, zakończoną VERIFIED, oraz spójnie zatruty kontekst z utratą obserwacji, zakończony UNKNOWN. W sześciu niewidzianych rodzinach ASR wynosi 33,33%, czyli 200/600. To wynik generalizacji do wybranych nowych szablonów, nie do populacji wszystkich ataków.

M6 wykrywa dodatkowe 343 naruszenia po szkodzie. Dlatego wzrost TPR przy niezmienionym ASR jest spodziewany i poprawny. M7 daje 1000 alarmów preflight oraz 400 na granicy commit. W części przypadków commit guard zatrzymuje drugie powtórzenie po legalnej pierwszej operacji.

Pole surowych wyników unjustified_pre_authorization jest nazwane zbyt szeroko. W rzeczywistości mierzy odsetek prób ataku, które przeszły preflight: 37,5% dla M7. Nie dowodzi, że taki odsetek mandatów był nieuzasadniony; część poprawnych żądań zostaje podmieniona dopiero później. Rzetelna metryka nieuzasadnionych mandatów wymaga osobnego normatywnego oracle dla decyzji autoryzacyjnej.

### Ablacje

| Usunięta warstwa z M7 | ASR | FPR | Interpretacja |
|---|---:|---:|---|
| Żadna | 12,50% | 10,00% | Punkt odniesienia. |
| Proxy leksykalne | 12,50% | 0,00% | W tym zbiorze filtr nie wnosi dodatkowej prewencji, blokuje legalne cytaty. |
| Typowane kontrakty | 84,50% | 10,00% | Największy zmierzony wkład ma pakiet jawnych relacji i wiązania wykonania. |
| Kryptografia | 15,50% | 10,00% | 48 dodatkowych udanych prób jednej rodziny. |
| Rekonstrukcja | 12,50% | 10,00% | Liczba błędnie VERIFIED szkodliwych prób rośnie ze 100 do 200; znika UNKNOWN. |
| RBAC, schemat lub kontrola grafu, każda osobno | 12,50% | 10,00% | Brak przyrostu ASR w tej mieszaninie nie dowodzi uniwersalnej zbędności. |

Ablacja bez proxy daje F1 93,33% i legalne ukończenie 100%. To najsilniejszy wynik negatywny wobec tezy, że dokładanie każdej warstwy musi poprawić całą architekturę. Nie uzasadnia usunięcia wszystkich mechanizmów językowych; dotyczy jednego prostego filtra.

W głównej rodzinie event_order_violation przestawiono serializację rekordów bez zmiany rodziców. Szkodliwość wynikała z równoczesnej zmiany celu. To wada izolacji badanego mechanizmu. Zachowano score i wykonano osobne 27 ocen post hoc: poprawną zmianę serializacji akceptują wszystkie warianty, rzeczywisty podpisany porządek decision→authority odrzucają M3, M7 i M8. Suplement nie został dopisany do głównej tabeli.

## 10. Statystyka, lokalizacja i ograniczenia rekonstrukcji

Dla ASR M7 przedział Wilsona 95% wynosi 10,969–14,211%. Dla FPR 10% wynosi 8,624–11,567%. Zero fałszywych alarmów w 1600 legalnych przypadkach ablacji nie jest dowodem zerowego ryzyka poza próbą; górna granica dwustronnego przedziału Wilsona to około 0,240%.

Powtarzalność szablonów narusza prostą interpretację 1600 pozycji jako niezależnych ataków. Resampling rodzin i ziaren daje dla ASR M7 zakres 0–31,25%. Poprawa M5→M7 wynosi 3 p.p., a zakres resamplingu różnicy 0–10,13 p.p. Rodziny są dobrane, nie wylosowane z populacji zagrożeń, dlatego ten zakres jest przede wszystkim analizą wrażliwości na skład scenariuszy.

Nominalne dokładne testy McNemara potwierdzają różnice w sparowanych pozycjach, ale bardzo małe p nie usuwa wspólnego pochodzenia szablonów. W bazowym JSON część wartości uległa underflow do numerycznego zera. Zachowano oryginalny wynik, a prawidłową reprezentację zapisano osobno w experiments/STATISTICAL_POSTPROCESSING.json. Dla M0→M7 nominalne p wynosi około 7,228×10⁻⁴²², nie matematyczne zero; dla M5→M7 około 7,105×10⁻¹⁵. Nie traktujemy tego jako dowodu przewagi generalizacyjnej.

Prospektywne przybliżenie mocy przy różnicy 10 p.p., 20% niezgodnych par, alfa 0,05 i mocy 0,8 daje około 155 niezależnych par. Estymacja proporcji z półszerokością 3 p.p. w najgorszym przypadku wymaga około 1068 niezależnych obserwacji. Duża liczba wariantów kilku szablonów nie spełnia automatycznie tego założenia.

M7 trafia w co najmniej jeden właściwy styk w 90,13% z 1500 przypadków z oznaczoną lokalizacją. Ścisła zgodność całego zbioru styków wynosi tylko 20%. Nie przedstawiamy pierwszej liczby jako dokładnego odtworzenia przyczyn. Wskazanie szerokiego zbioru relacji zwiększa szansę częściowego trafienia.

Zgodność odtworzonego efektu z księgą wynosi 100% tam, gdzie pole rekonstrukcji jest dostępne, przy pokryciu 82,77% wykonanych przypadków M7. Obserwator został zaprogramowany do odczytu księgi; nie modeluje pełnego szumu prawdziwego sensora. Nie wszystkie dostępne efekty mają niezależne pochodzenie i status VERIFIED. Pełna dokładność trajektorii ukrytego stanu pozostaje null. Szczegóły: [STATISTICAL_ANALYSIS.md](STATISTICAL_ANALYSIS.md).

## 11. Rekonstrukcja probabilistyczna i wspólne źródła świadectw

Kryptologika jest w badaniu traktowana jako rama analizy odwrotnej, a nie metoda uzyskania dostępu do prywatnego rozumowania modelu:

~~~text
Yₜ = F(Xₜ,Uₜ,Θ) + εₜ
p(X₀:T,Θ | Y₀:T,U₀:T)
∝ p(Θ)p(X₀) ∏ₜ p(Xₜ|Xₜ₋₁,Uₜ,Θ) p(Yₜ|Xₜ,Uₜ,Θ)
~~~

To, czy rozkład hipotez ma sens, zależy od modelu przejść, likelihood i zależności świadków. Wbudowane posteriory rdzenia są ilustracyjne, nieskalibrowane dla prawdziwych agentów. Dodatkowe HMM daje odtwarzalny eksperyment z jawną prawdą ukrytą: 150 trajektorii po 60 kroków, łącznie 9000 obserwowanych chwil.

| Model świadectw | Brier, mniej znaczy lepiej | Log loss | Błędna pewność powyżej 99% |
|---|---:|---:|---:|
| Pięć kopii jednego pomiaru, błędnie uznanych za niezależne | 0,09899 | 0,80274 | 9,911% |
| Ta sama informacja liczona raz po uwzględnieniu wspólnego źródła | 0,03372 | 0,11726 | 0,211% |
| Pięć rzeczywiście niezależnych sensorów | 0,00307 | 0,01223 | 0,0556% |

Założono sensor accuracy 0,9, przejścia stanów 0,02 i 0,08 oraz znane filtrom parametry. Wynik pokazuje skutek błędnego mnożenia zależnych świadectw. Nie ustanawia kalibracji modelu bezpieczeństwa LLM. Niezależny przegląd przeliczył metryki z surowych danych; różnica posteriorów przy osobnym rachunku log-odds nie przekroczyła 5,55×10⁻¹⁶. Dane: experiments/cascade_outputs/epistemic_hmm_raw.csv i epistemic_summary.json.

## 12. Rzeczywiste procesy i falsyfikacja własnego obserwatora

Dodatkowy eksperyment uruchomił worker oraz obserwatora jako odrębne procesy Python, z rzeczywistymi zapisami SQLite. Są to procesy o wspólnym zaufaniu do administratora i środowiska; nie ma izolacji sprzętowej. Worker zwraca niepodpisany JSON na stdout. Podpis powstaje dopiero pod agregatem nadrzędnego verifiera.

| Scenariusz | Wynik | Rzeczywisty skutek |
|---|---|---|
| Operacja legalna | VERIFIED | Poprawny zapis. |
| Podmiana przed commit | CONTRADICTED | Zablokowana przed zapisem. |
| Dryf po dopuszczeniu | CONTRADICTED | Szkoda wykonana, wykryta po fakcie. |
| Fałszywy raport workera | CONTRADICTED | Poprawny efekt, niezgodna deklaracja. |
| Niedostępność świadka przed startem | UNKNOWN | Zapis wstrzymany. |
| Niedostępność świadka po dopuszczeniu | UNKNOWN | Szkoda wykonana, bez rozstrzygającej obserwacji. |

Gotowość świadka w tym teście jest parametrem scenariusza, nie rzeczywistym odpornym healthcheck. Tabela nie jest benchmarkiem adaptacyjnego przeciwnika. Wyniki i kod zachowano w experiments/process_lab_results.json oraz process_lab.py.

**Przegląd wykrył błąd samej funkcji oceny.** Obserwator odczytywał salda, ale verifier i oracle analizowały tylko log transakcji. Osobny suplement wykonał legalny przelew 12 jednostek, a następnie przez dodatkowy subprocess przesunął 7 jednostek na external bez wpisu do dziennika.

| Wariant | Salda rzeczywiste | Pierwotny wynik | Nowe porównanie stanu z zaufanym początkiem i zatwierdzonym skutkiem |
|---|---|---|---|
| Legalny | ops 988, payroll 12 | VERIFIED; szkoda=false | VERIFIED; szkoda=false |
| Zmiana poza logiem | ops 981, payroll 12, external 7 | **VERIFIED; szkoda=false** | **CONTRADICTED; szkoda=true** |

Suma nadal wynosi 1000. Zatem nawet kontrola zachowania sumy nie rozwiązałaby problemu. Co ważne, poprawne salda były już dostępne w obserwacji i podpisanym agregacie: błąd leżał w projekcji użytej do decyzji. To ograniczenie własnej implementacji, nie fundamentalna nierozróżnialność jak w przypadku ukrytego beneficjenta.

Dwie próby zapisano osobno w experiments/process_balance_probe_results.json. Pierwotny kod i sześć wyników zachowały SHA-256. Nowa kontrola wykrywa tę konkretną zmianę po efekcie; nie zapewnia pełnej mediacji, odporności na kompromitację bazy ani prewencji. [SUPPLEMENT_REVIEW.md](SUPPLEMENT_REVIEW.md) dokumentuje ten wynik oraz jego ograniczenia.

## 13. Kaskady i stabilność ochrony

Zdefiniowano liniowy, dyskretny model natężenia zaburzenia x oraz reakcji ochronnej q. Współczynniki opisują pozostałą propagację, koszt odpowiedzi, siłę regulacji i pamięć/ponowienia.

~~~text
zₜ₊₁ = Mₜzₜ + wₜ; z=(x,q)
M = [[A_eff, B], [K, R]]
Dla stałej M: rho(M)<1 ⇒ Mⁿ→0.
~~~

Wykonano 600 sparowanych losowań parametrów dla pięciu wariantów: 3000 symulacji, 18 węzłów w trzech domenach, 35 kroków i opóźnienie reakcji dwóch kroków. Współczynniki losowano niezależnie jednostajnie z zadanych zakresów. Wartości bezwymiarowe i częstości stabilności nie są pomiarem ryzyka produkcyjnego.

| Wariant | Odsetek macierzy stabilnych | Średni zasięg powyżej progu 0,05 | Mediana skumulowanego zaburzenia |
|---|---:|---:|---:|
| Wspólny regulator bez tłumienia | 27,83% | 14,68 węzła | 2717,28 |
| Tłumienie grafu, wspólna reakcja | 70,00% | 11,80 | 8,96 |
| Mocniejsze odcięcie między domenami, lokalne reakcje, brak limitu retry | 74,67% | 10,91 | 7,05 |
| Ten sam wariant lokalny, limit retry | 96,17% | 9,63 | 4,61 |
| Wspólna reakcja przy takim samym tłumieniu i limicie retry | 97,33% | 10,07 | 4,67 |

Odsetek stabilności dotyczy stałej macierzy po interwencji. Nie jest identyczny z osiągnięciem progu wygaszenia w skończonych 35 krokach. Odpowiednie metryki zapisano osobno. Najbardziej bezpośrednie porównanie lokalności to ostatnie dwa warianty: wspólny jest stabilny w 584/600 losowań, lokalny w 577/600; lokalny ma nieco mniejszy zasięg. Nie ma uniwersalnego zwycięzcy.

Skonstruowany kontrprzykład pokazuje destabilizację przez samą ochronę:

~~~text
M₀ = [[0.85,0.20],[0.15,0.20]]; rho(M₀)=0.893273
M₁ = [[0.35,0.40],[1.10,0.80]]; rho(M₁)=1.275446
~~~

Mimo ograniczenia bezpośredniej propagacji 0,85→0,35 zwiększone sprzężenie reakcji powoduje wzrost zaburzeń. Dodatkowo dwa tryby z promieniem 0,5 mają iloczyn dwukrokowy o promieniu 1,457107. Stabilność każdej chwilowej macierzy nie wystarcza dla arbitralnego przełączania.

Dla nieujemnej rodziny macierzy wystarczający warunek daje wspólny dodatni wektor w i γ<1 z Mₜw≤γw. W rzeczywistym wdrożeniu potrzebne byłyby identyfikacja parametrów, model kolejek, ograniczenia czasu i pomiar reakcji. Sama nazwa „odwrócona piramida” nie określa tych własności. Dane i korelacyjna analiza wrażliwości są w experiments/cascade_outputs/. Korelacje opisują zadany rozkład losowania, nie skutki przyczynowe w rzeczywistej infrastrukturze.

## 14. Koszt i wykonalność

W porównaniu 160 identycznych zwykłych legalnych operacji mediana M0 wynosi 0,582 ms, a M7 1,779 ms. Mediana sparowanej różnicy to 1,175 ms; stosunek median około 3,06. Jest to właściwsze zestawienie niż mediana całej mieszaniny, gdzie wczesne blokady skracają wykonanie części modeli.

Pomiar obejmuje lokalny kod, kryptografię i syntetyczny commit. Nie obejmuje inferencji modelu, sieci, niezależnej telemetrii, baz produkcyjnych, skanowania całego repozytorium przy generowaniu BOM, kolejek ani retencji. Początkowe pojedyncze przypadki procesowe trwały około 31–115 ms; dominują w nich inne koszty, w tym uruchamianie procesów. Nie są porównywalnym pomiarem pełnego systemu M7.

Nie mierzono energii. Nie wyznaczono TCO, granicznego throughput ani opóźnienia w warunkach przeciążenia. Nie można potwierdzić ekonomicznej wykonalności bez budżetu operacyjnego i profilu obciążenia. Nie ma także danych uzasadniających tezę, że narzut czyni każdy taki system niewykonalnym.

## 15. Falsyfikacje i ocena nowości

[FALSIFICATION_REPORT.md](FALSIFICATION_REPORT.md) rozwija kontrprzykłady: identyczne obserwacje przy innym właścicielu, kolizje charakterystyki, podpisany fałsz, lokalnie dopuszczalny lecz globalnie szkodliwy skutek, utrata świadka, szkoda przed detekcją, legalny cytat blokowany przez filtr, destabilizacja i błędne ignorowanie dostępnego stanu bazy.

Najmocniejsze rozstrzygnięcie negatywne jest informacyjne: bezpieczeństwa nie da się wyliczyć z charakterystyki, która utożsamia stan bezpieczny i niebezpieczny. Najmocniejszy wynik pozytywny dotyczy dobrze określonych relacji operacyjnych: kontrakt może wymusić zgodność źródła mandatu, kontekstu, argumentów i faktycznego commit bez czytania całego wnętrza agenta.

Obecny PoC nie oddziela nowego algorytmu „cyklometru” od istniejących technik monitorowania. M5 jest pakietem jawnych predykatów, ekstraktor charakterystyki nie steruje decyzją, a grafy i receipts mają wcześniejsze odpowiedniki. Podstawą możliwego przyszłego wkładu może być formalnie uzasadniona rodzina charakterystyk o zmierzonym koszcie i granicach kolizji, jej połączenie ze świadectwami rzeczywistego skutku oraz regulator o wykazanym zakresie stabilności. Tego wyniku jeszcze nie uzyskano.

Nie przypisano użytkownikowi oddzielnej innowacji LBOM, nie stwierdzono pierwszeństwa prawnego ani naukowego i nie wyprowadzono aprobaty NIST z podobieństwa architektury.

## 16. Odtwarzalność, kontrola jakości i dostarczony kod

Końcowy zestaw tests/ zawiera **57 testów, wszystkie PASS**: 33 rdzenia, 8 benchmarku, 4 dynamiki, 7 metapołączenia i 5 laboratorium procesowego. Osobno wykonano 39 oryginalnych testów LAB i 10 sprawdzeń adaptera. Dwóch nowych prób bilansowych, 27 prób porządku i dziewięciu ocen pary nierozróżnialności nie dodano do głównego licznika testów.

Zweryfikowano niezmienność wszystkich 14 plików objętych zamrożeniem. Agregat rdzenia wynosi:

~~~text
ce6f42706f374aaf6600d91217d531ef14f0c0bc6feba62a06261f7e939edfe5
~~~

Środowisko: Python 3.12.14, cryptography 50.0.0, NumPy 2.3.5, SciPy 1.17.0. Instrukcja [REPRODUCIBILITY.md](REPRODUCIBILITY.md) podaje pełne polecenia, rozdziela ponowne generowanie od wykorzystania zachowanych danych i zaznacza zmienność pomiarów czasu. [FINAL_VERIFICATION.md](FINAL_VERIFICATION.md) i FINAL_TEST_RESULTS.txt zawierają wynik kontroli jakości. Recenzje [REVIEW_NOTES.md](REVIEW_NOTES.md) oraz [SUPPLEMENT_REVIEW.md](SUPPLEMENT_REVIEW.md) zachowano jako część materiału.

Kod src/msc/ jest działającą implementacją; src/msc_benchmark/ generuje dane, ocenia i liczy statystyki; src/msc_extensions/ zawiera oddzielny dodatek podpisanego metapołączenia. Katalog experiments/ zawiera konfiguracje, hashe, surowe oceny, symulacje i rzeczywiste wyniki procesowe. Kopie oryginalnego filtra LAB mają odrębne manifesty pochodzenia. Żaden wynik symulacji nie został opisany jako pomiar istniejącej infrastruktury użytkownika.

## 17. Elementy niewykonane i dalszy program badawczy

Nie wykonano pełnego audytu wszystkich repozytoriów i hostów LAB, całej federacji LION, silnika Cyber-Tiger ani potwierdzonej reprodukcji SPECTA/Agent-Gate. Nie odczytano treści jednej wskazanej publikacji; część pozostałych sprawdzono tylko przez abstrakt i metadane. Nie uruchomiono prawdziwego benchmarku LLM, implementacji konkurencyjnych architektur, kontroli sprzętowej, telemetrii fizycznej, eBPF ani pomiaru energii.

W pierwszej kolejności potrzebny jest nowy, zamrożony eksperyment porównujący M5, M7 bez proxy oraz silny klasyczny monitor transakcyjny na wspólnych zadaniach. Należy mierzyć przyrost wniesiony przez charakterystykę grafową, której obecny kontroler nie używa. Dane powinny zawierać różne mechanizmy, nie tylko warianty identyfikatorów lub kilka nazw dla replay.

Następnie warto przetestować rzeczywiste agenty z pamięcią i retrieval, przy równych modelach, budżetach i narzędziach. Ground truth powinien być utrzymywany w odrębnej domenie, a przeciwnik mieć adaptacyjne próby na nowym zbiorze. Porównanie z AuthGraph, SAGA i ControlValve wymaga dokładnego wspólnego zakresu; same publikowane ASR nie są porównywalne.

Warstwę efektu należy związać z zaufanym stanem początkowym i normatywną deltą, zamiast opierać ją na samoopisie wykonawcy. Potrzebna jest atomowa kontrola przed nieodwracalnym commit, trwały magazyn nonce i epok, monitor obejmujący alternatywne kanały skutku oraz świeża gotowość świadków. Nowy kontrprzykład SQLite daje konkretny test akceptacyjny dla tej pracy.

Dla regulacji konieczne są pomiary kolejek, zależności obserwacji i kosztów reakcji oraz stabilność przy zmianach topologii. Histereza, ograniczenia ponowień i zakresu izolacji powinny być częścią kontraktu regulatora. Utrata obserwowalności nie może automatycznie zwiększać uprawnień, ale zatrzymanie także ma koszt dostępności, który trzeba ujawnić.

Ewentualna standaryzacja powinna najpierw obejmować niewielki profil interoperacyjny: wersjonowany rekord operacji, niezależne pochodzenie authority, skróty kontekstu i polityki, epokę, nonce, model oczekiwanego efektu, zakres świadectwa i znaczenie UNKNOWN. Adaptery do istniejących CycloneDX/SPDX i formatów attestacji wymagają walidacji zgodności. Sama nowa nazwa BOM nie zastępuje tego procesu.

**Końcowa odpowiedź na cel nadrzędny:** można kontrolować wybrane relacje procesu, w którym informacja wpływa na interpretację, interpretacja na mandat, a mandat na skutek, bez pełnego poznania wewnętrznego stanu agenta. Warunkiem jest poprawny kontrakt, wystarczająca obserwowalność, kompletna mediacja w zadanym zakresie i ograniczony koszt reakcji. Obecne badanie wykazało użyteczność takiej kontroli oraz konkretne granice, przy których samo pochodzenie, topologia i podpisy nie wystarczają.


