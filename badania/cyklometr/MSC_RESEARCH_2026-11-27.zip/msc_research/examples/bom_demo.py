"""Creates and verifies signed cross-link; extension excluded from M0–M8 benchmark."""
import json
from msc import build_case, evaluate, BOMRegistry
from msc_extensions import create_meta_binding, verify_meta_binding
case = build_case(17)
result = evaluate(case, 'M7')
registry = BOMRegistry()
bom_key = registry.observe(case['public'], result['receipts'])
view = registry.get(bom_key)
meta_receipt = create_meta_binding(case['public'], result['receipts'])
verification = verify_meta_binding(meta_receipt, case['public'], result['receipts'])
assert verification['status'] == 'VERIFIED'
print(json.dumps({'bom': view, 'meta_attestation': meta_receipt, 'verification': verification,
                  'benchmark_scope': 'extension outside frozen M0-M8 benchmark',
                  'limitations': 'Public fixture keys; local code inventory; no measured boot or process isolation.'},
                 ensure_ascii=False, indent=2))
