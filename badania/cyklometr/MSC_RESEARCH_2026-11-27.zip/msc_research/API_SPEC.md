# MSC API contract (public, pre-freeze)

Python 3.11+, cryptography; set `PYTHONPATH=src`. Import `build_case`, `reseal`, `evaluate`, `Controller`, `ToyExecutor`, `digest`, `issue_event`, `default_keyring` from `msc`.

`build_case(seed=1)` creates an independent, legal synthetic transfer case. All data is JSON-serializable. The controller receives only `case['public']` at preflight; runtime behavior and evaluator truth are not supplied to it.

```json
{
 "public": {
  "request": {"id":"case-1","actor":"executor","action":"transfer","source":"ops","target":"payroll","amount":25,"currency":"PLN","purpose":"payroll","snapshot_version":1},
  "context": {"user_goal":"Pay payroll from ops","purpose":"payroll","allowed_targets":["payroll"],"max_amount":100,"snapshot_version":1,"source_text":"Pay payroll from ops","source_roots":["user:root"],"trusted_roots":["user:root"],"policy_id":"payroll-policy-v1"},
  "plan": {"same fields as request":"..."},
  "authorization": {"issuer":"authorizer","subject":"executor","actions":["transfer"],"targets":["payroll"],"max_amount":100,"purposes":["payroll"],"request_digest":"...","context_digest":"...","snapshot_version":1,"nonce":"nonce-1","delegations":[],"approved_source_roots":["user:root"]},
  "events": []
 },
 "runtime": {
  "execution_request": {"same fields as request":"..."},
  "snapshot_version":1,
  "self_report_override":null,
  "host_report_override":null,
  "host_available":true,
  "host_root":"host:kernel",
  "self_root":"agent:executor",
  "replay_nonce":false
 }
}
```

Seven preflight events follow `source → data → context → interpretation → authority → decision → tool`. Each signed event has `id, kind, role, step, parents` (parent digest list), `body, roots, taint, label, digest, signature`. Roles: source/data `ingestor`, context/interpretation `planner`, authority `authorizer`, decision `planner`, tool `executor`. Preflight chains can include auxiliary `note` nodes; mandatory roles and precedence still apply. Hash is SHA-256 of canonical JSON unsigned event; Ed25519 authenticates digest bytes. Signatures use deterministic **test-only keys**. No real secrets or external calls.

`reseal(case, refresh_bindings=True, rebuild_events=True)` updates authorization request/context bindings and regenerates a correct signed chain. Set `refresh_bindings=False` to preserve intentionally stale/mismatched bindings. `reseal` never changes runtime execution_request, policy context, plan or authority scope. `issue_event(event)` rehashes/signs one event (provided `role` exists in keyring); it does not repair descendants' parent digests. Helpers are evaluator capabilities, never supplied to tested controller.

For direct event edits, set exact `body` and use `issue_event`; source roots/taint are public evidence. A cryptographically valid false record is allowed in a case and must not be equated with truth.

`evaluate(case, model='M7', layers=None)` executes preflight, runtime commit and postflight. Returns `allowed_pre`, `executed`, `status` (`VERIFIED|CONTRADICTED|UNKNOWN`), `alerts`, `locations`, `actual_effect`, `reconstruction`, `timings_ms`, `containment`, `model`, `layers`. Any postflight detection leaves already performed `actual_effect` intact. `actual_effect` is read directly from the synthetic ledger, not from either receipt. Empty effect means no transfer was committed. Ground truth and case family are evaluator-only and must not be passed inside `public`.

Executor supports integer positive transfers from `ops` to any string account, balance initially 1,000,000. Runtime version mismatch or request alteration is blocked at commit only when `typed_invariants` is enabled. Other variants execute the runtime request if valid; replays may execute twice unless nonce/typed guard blocks. The baseline executor has physical validity checks (integer positive amount and sufficient balance), not a hidden security oracle.

Receipts: self and host each sign `{request_digest, effect, snapshot_version, roots}` as `execution` and `evidence` records. Overrides replace claimed effect only; actual ledger remains independent. Same root makes evidence epistemically non-independent even when keys differ. No host evidence gives UNKNOWN for reconstruction layers.

Policy scope: operation must match plan and approved request digest, purpose, context target/budget, local authorization scope, trusted source roots; delegated scope may only attenuate. Delegation item schema is `{from, to, actions, targets, max_amount, purposes}`; first `from` is authorization issuer; final `to` is subject. Policy context is fixed by the experiment, while its supplied representation may be corrupted in challenge cases.

Layers: `rbac`, `schema`, `semantic_proxy`, `control_flow`, `crypto`, `typed_invariants`, `reconstruction`, `containment`.

| Model | Enabled layers |
|---|---|
| M0 | rbac |
| M1 | rbac, schema |
| M2 | M1, semantic_proxy (deterministic lexical heuristic; no LLM) |
| M3 | M1, control_flow |
| M4 | M1, crypto |
| M5 | M1, typed_invariants |
| M6 | M1, reconstruction |
| M7 | all except containment |
| M8 | all |

`layers` overrides model selection and supports full-minus-one ablations. Locations are named transitions: SOURCE→DATA, DATA→CONTEXT, CONTEXT→INTERPRETATION, INTERPRETATION→AUTHORITY, AUTHORITY→DECISION, DECISION→TOOL, TOOL→EXECUTION, EXECUTION→EFFECT, EFFECT→EVIDENCE. A rejection can report multiple distinct alerts. Synthetic reconstruction reports actual observed tuple only when a valid independent host exists; this is not hidden-state semantic omniscience.

Output shapes: `alerts=[{"code":"SCOPE_TARGET","location":"AUTHORITY→DECISION","phase":"preflight","detail":"..."}]`; `locations` is sorted unique strings. `actual_effect={}` for zero commits, otherwise `{ "operations":[<full committed request dict>],"total_debit":25,"balance_delta":{"ops":-25,"payroll":25}}`. `committed_count` counts irreversible toy ledger writes. `reconstruction={"effect":<host claimed effect or null>,"observed_trajectory":[<event kind strings>],"posterior":{...},"independent":true/false,"coverage":"synthetic-ledger-only"}`. The posterior is a declared illustrative Bayesian model, not calibrated confidence in real-world truth.

`runtime.repeat_count` positive int (default 1); `runtime.replay_nonce=true` requests at least 2 identical commits. `runtime.nonce_already_used=true` initializes that nonce as consumed; typed guard blocks it. A nonce is consumed at first guarded commit. Repeat count is bounded to 20 to keep experiments finite; larger requests are UNKNOWN. `seed` alters request id, nonce and amount (1+seed%99), never policy. Subject is `executor`; benign targets may vary only when explicit context and scope permit them. Actual source account is ops. Exact runtime commit alerts are phase `commit`; preflight and postflight alerts have their respective phase.
