# Materiały LAB i chronologia koncepcji

Stan odczytu: 27 listopada 2026. Źródła obejmują podane polecenie, wcześniejsze zachowane dokumenty użytkownika, świeże odczyty GitHub oraz ograniczone odczyty drzew Cyber-Tiger, ai_platform, DirtyFrag i 0!n na dostępnym hoście. Wykonano audyt źródłowy i lokalne odtworzenie skopiowanego nieefektowego filtra LION; nie uruchamiano istniejącej federacji LION ani nie zmieniano jej repozytoriów lub usług. Nie utożsamiamy daty w treści, daty dodania pliku, daty commitu, pierwszej publikacji i dowodu pierwszeństwa.

## 1. Potwierdzona chronologia

| Data zapisu / źródła | Materiał | Rzeczywisty zakres | Granica dowodowa |
|---|---|---|---|
| 19.01.2026, metadata Git | `writeups/sbom-as-sigillum-relationis_systemic-risk-control.md`, commit `d02b065c504ac4c70d097c3668577cd46219f470` | SBOM jako relacyjny odcisk i sensor struktury; połączenie pomiaru, delty i decyzji | Najwcześniejszy odnaleziony commit tego pliku, nie niezależny znacznik pierwszego stworzenia idei |
| 25.01.2026, metadata Git | `sbom/docs/90_APPENDIX_KRYPTOLOGIA.md`, commit `d654dc028900ae4b43a3699ef0b9e41907b2f92d` | Zdarzeniowy SBOM, AID, delta, gate; kryptologia informacyjna jako rama interpretacyjna | Esej koncepcyjny; metafora SBOM jako hashu nie dowodzi unikalności strukturalnej |
| 24.05.2026, data zachowanego pliku | Log prac Cyber-Tiger `Wklejony tekst (2)(3).txt` | Rejestr powierzchni poleceń, architektura i wybrane wyniki testów z lokalnego projektu | Historyczny log użytkownika, nie nowa reprodukcja tych wyników |
| 25.06.2026, data zachowanego pliku | `Wklejony tekst(163).txt` | Program badania filtrów interferencyjnych: źródło, kontekst, rola, mandat, czas, narzędzie, proces i akcja; podział kernel/user space | Prompt badawczy i projekt implementacji, nie dowód gotowego kontrolera |
| 09.07.2026, data zachowanego pliku | `Wklejony tekst(207).txt` | Definicja metapołączenia kryptologicznego przez hashe, podpisy, commitments i receipts; wiązanie łańcuchów | Pierwotny kontekst dotyczył BTC i tokenów AI; nie należy automatycznie przenosić wszystkich tez ekonomicznych na MSC |
| 18.07.2026, dane wersji i plików | `ASTRA-IOAC_v1.1_release_note.txt` i `ASTRA-IOAC_v1.1.1.txt` | Separacja ról, Authority Gate, monotoniczna delegacja, osobne Execution Receipts i niezależna obserwacja logiczna/fizyczna | Specyfikacja architektoniczna; nie odczytano działającego koprocesora ani pomiarów energii |
| 19.07.2026, data zachowanego pliku | `Wklejony kod markdown (2)(6).md` | Kryptologika jako rekonstrukcja ukrytych stanów z rozproszonych, częściowo zależnych śladów; autentyczność nie implikuje prawdziwości | Zachowany materiał koncepcyjny; propozycja metodologii, nie uznana odrębna dyscyplina |
| 22.07.2026, data zachowanych plików | `Wklejony tekst (2)(40).txt` i `Wklejony kod markdown (2)(12).md` | Jawne rozróżnienie Identity/Authority BOM, Label BOM, Decision BOM, Execution BOM i receipts oraz luki provenance wykonania | Pierwszy to zadanie badawcze, drugi wcześniejszy opracowany raport; nie niezależne potwierdzenie skuteczności |
| 12.08.2026, data zadeklarowana w tekście | `LINUX_MULTI_AGENT_CONTROL_MESH_REFERENCE_ARCHITECTURE.md` | Model jako autor propozycji; PDP/PEP, ograniczanie autorytetu przy spadku obserwowalności, osobny Verifier | Data wewnętrzna dokumentu; opis architektury, nie pomiar obecnego hosta |
| 18.08.2026, data zachowanego PDF | `JARZMO-MESH.pdf` | Lokalne regulatory, dynamiczne koalicje, świadectwa efektu, negative authority i testowanie kaskad samej obrony | Rozbudowany prompt projektowy; przedstawione niezmienniki to wymagania do weryfikacji |
| 03–10.10.2026, daty obserwowanych HEAD | Federacja: `sbom`, `SymulacjaKaskadySieciowej`, `ai_platform` | Rozdzielenie dokumentacji, reprezentacji, źródła autorytetu i efektu; dane związane z konkretną tożsamością źródła | Przeczytany kod i dokumentacja; nie odtworzono CI ani runtime produkcyjnego |
| 10–14.10.2026, nazwa tekstu i mtime | `LION_SEMANTIC_PRE_MODEL_FILTER_R1` w `0!n/docs/legacy-lion` | Oryginalny interpreter typowanych tez, sześć operatorów zmian, blokady data→authority i model_output→evidence, reguła złożonej trajektorii | Odczytano pełne źródła i zgodność siedmiu plików z manifestem; daty nie są podpisanymi znacznikami czasu |
| 27.11.2026, bieżące badanie | MSC, ten pakiet | Formalizacja, działający prototyp, syntetyczny benchmark, kontrprzykłady i osobne symulacje | Nowy eksperyment, nie aktualizacja wdrożenia LION |

Daty lipcowe nie są wyprowadzane wyłącznie z pamięci rozmów: odczytano treść wskazanych zachowanych plików. Ich automatyczne lub wspólne opracowanie w poprzednich sesjach nie czyni ich niezależnym źródłem naukowej walidacji. Rekordy dostępu i skróty są w `lab_evidence/evidence_index.json` oraz `github_commit_records.json`.

## 2. Obserwowane repozytoria

| Repozytorium | HEAD podczas odczytu | Tree z obiektu commitu | Co sprawdzono |
|---|---|---|---|
| DonkeyJJLove/sbom | `48aab54cc260bfbfea4881f7a6f264caef814440` | `1e8c563e51a1d55f4003acd98255b45983f98214` | dokumentacja lokalna, manifest roli i `reference/artifact_identity_adapter.py` |
| DonkeyJJLove/writeups | `6fbbb020a59b31f87543b1e995f92fc7fdc865c4` | `b406af267548973ed893d103c643475b9feccf4e` | korpus badań, historia wskazanych tekstów, manifest, architektura mesh |
| DonkeyJJLove/ai_platform | `d367e47cf4f72e450cc212908b2cdfed14ceb805` | `b92133d258b6fbf2c7f1d16d992e08d2a3609a0c` | wejście LION v1.5, właściciele semantyki, rejestr formalizacji, RAG bootstrap, wybrane kontrakty |
| DonkeyJJLove/SymulacjaKaskadySieciowej | `0a9413f36ee8cf7684bcb77f42abcaffcf59a60d` | `5d6396c52013657e36fdc296044b59cbd0d26bb1` | manifest i deterministyczny adapter fixture z jawnie syntetycznymi parametrami |

Świeżo odczytany HEAD nie oznacza świeżego wdrożenia. Zachowane projekcje architektury LION same zaznaczają ograniczenia aktualności. Historycznego v1.4 nie awansowano do właściciela bieżącej architektury v1.5. Zewnętrzny preferowany pakiet RAG R9 nie był osadzony w repozytorium; odczytane R1 było jedynie historyczną mapą nawigacyjną, a konkretne aktualne twierdzenia o kodzie oparto na wskazanym HEAD.

W kodzie `artifact_identity_adapter.py` stwierdzono walidację relacji AID, repozytorium, commitu, długości danych i SHA-256, przy braku efektu autoryzacyjnego. W `communication_envelope.py` istnieje wersjonowana koperta, przyczynowe odwołania, digest payloadu i odrzucenie prób nadania komunikacji authority/effect. `authority_source.py` definiuje kontrakt niezależnego źródła linii autoryzacji i sam wyraźnie nie implementuje backendu, weryfikacji podpisów ani wykonania. Te granice są istotną częścią materiału użytkownika.

## 3. Zgodność przedmiotowa i nieuprawnione ekstrapolacje

| Obszar | Ustalenie | Zastosowanie w MSC |
|---|---|---|
| Kryptologika | potwierdzona definicja rekonstruowania stanów i krytyki świadectw | osobny obserwator, hipotezy i UNKNOWN |
| Metapoziom SBOM | potwierdzone relacje artefakt–zdarzenie–autorytet–skutek | wspólna przestrzeń zdarzeń z widokami BOM |
| Label / Identity / Decision / Execution BOM | nazwy obecne w programie lipcowym | projekcje metapoziomu; bez twierdzenia, że sam LBOM jest odrębną autorską innowacją |
| Decision/Execution Receipt | potwierdzone w IOAC i materiałach BOM | podpisywane świadectwa z rozdzielonym znaczeniem |
| Cyber-Tiger | historyczny log i rzeczywiste fixture testów wspólnych zależności oraz niezależności sygnałów | odczytano kod testów; nie uruchomiono zależnego silnika; szczegóły w LAB_MUTATORS.md |
| SPECTA / Agent-Gate | nie ustalono odrębnego odtwarzalnego komponentu w wykonanym ograniczonym poszukiwaniu | nie przypisywano im wyników generatora; brak potwierdzenia nie oznacza nieistnienia |
| LION | potwierdzony kod i rozdzielenie reprezentacji od authority | kierunek adaptera do istniejącego kontraktu, bez nowego właściciela autorytetu |
| JARZMO | potwierdzony program mesh i reguła obserwowalność→uprawnienia | readiness gate w uzupełniającym eksperymencie procesowym; główny PoC ma ograniczenie postflight |
| Odwrócona piramida | potwierdzona rama zależności fizycznych oraz postulaty lokalności/federacji | ilościowe założenia lokalnej regulacji zdefiniowano od nowa; nazwa nie ustala parametrów |
| Filtry interferencyjne | jawny program porównywania źródła, roli, mandatu i wykonania | typowane relacje i punkty sprawdzania styku |
| Semantyczne pranie autoryzacji | problem promowania treści do rangi mandatu obecny w materiałach styków i JARZMO | przypadki z niezaufanym źródłem i niedozwoloną delegacją |
| Kaskady | dostępne repozytorium symulacji; jawnie nieempiryczny fixture | nowa osobna symulacja w MSC, nie wynik istniejącego modelu kraju lub globalnej sieci |
| Mutatory semantyczne | oryginalny `mutate` LION zmienia typowany graf i nie nadaje authority/effect; 39 testów oryginalnych oraz 10 sprawdzeń adaptera PASS | osobne odtworzenie po benchmarku; jego generator perturbacji jest nowym kodem, a znaleziony LAB nie jest zestawem ofensywnych payloadów |

## 4. Pierwszeństwo i nowość

Odnalezione źródła dokumentują rozwój koncepcji użytkownika przed bieżącym promptem. Nie ustanawiają jednak pierwszeństwa wobec całej literatury. Pierwszy projekt IR8536 pochodzi z 2024 r.; wcześniejsze są też kontrola przepływu informacji, monitory referencyjne, process mining i kryptograficzne łańcuchy provenance. AuthGraph z maja 2026 r. jest bliskim porównaniem dla relacji execution provenance/authorization, a CycloneDX1.7 już obejmuje deklarowane i obserwowane workflow. Przesłanką potencjalnej nowości może być konkretny, odtwarzalny sposób integracji z obserwowalnością i stabilnością reakcji, nie sama obecność grafu albo nazwa BOM.

Nie wyprowadzamy procentowej „zgodności autorskiej” z podobieństwa słów. Relacje w tabeli oznaczają potwierdzony zakres materiału, a nie pomiar skuteczności, transfer wdrożeniowy czy aprobatę NIST.

## Odnośniki pierwotne LAB

[SBOM — artykuł i historia styczniowa](https://github.com/DonkeyJJLove/writeups/commit/d02b065c504ac4c70d097c3668577cd46219f470). [Appendix Kryptologia](https://github.com/DonkeyJJLove/sbom/blob/48aab54cc260bfbfea4881f7a6f264caef814440/docs/90_APPENDIX_KRYPTOLOGIA.md). [Właściciel architektury LION v1.5](https://github.com/DonkeyJJLove/ai_platform/blob/d367e47cf4f72e450cc212908b2cdfed14ceb805/LION/architecture/v1_5/README.md). [Kod koperty komunikacyjnej](https://github.com/DonkeyJJLove/ai_platform/blob/d367e47cf4f72e450cc212908b2cdfed14ceb805/cyber_lion/contracts/communication_envelope.py). [Kod identyfikacji artefaktów](https://github.com/DonkeyJJLove/sbom/blob/48aab54cc260bfbfea4881f7a6f264caef814440/reference/artifact_identity_adapter.py). [Model fixture kaskady](https://github.com/DonkeyJJLove/SymulacjaKaskadySieciowej/blob/0a9413f36ee8cf7684bcb77f42abcaffcf59a60d/src/abstrakcyjna_symulacja_kaskady_sieciowej/federation_fixture_provider.py).

[IOAC v1.1.1](https://chatgpt.com/library?file_id=libfile_6c8ad5d242f88191853c758aacef2342&account_id=personal). [Program badania BOM, 22 lipca](https://chatgpt.com/library?file_id=libfile_073f75622c088191891be1d665cf1efa&account_id=personal). [Kryptologika, 19 lipca](https://chatgpt.com/library?file_id=libfile_b43e9dee9e588191a782362db70ec6fe&account_id=personal). [JARZMO-MESH](https://chatgpt.com/library?file_id=libfile_7815851c48a88191a5b213431fc04871&account_id=personal). [Filtry interferencyjne, 25 czerwca](https://chatgpt.com/library?file_id=libfile_e3427f3a63cc819184e61ed102e76e49&account_id=personal). [Metapołączenie kryptologiczne, 9 lipca](https://chatgpt.com/library?file_id=libfile_06a731142a608191afaeb2912067b906&account_id=personal).
