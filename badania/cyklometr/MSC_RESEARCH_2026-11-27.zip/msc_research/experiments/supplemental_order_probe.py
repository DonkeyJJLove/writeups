"""Post-hoc diagnostic: distinguish list order from actual signed causal order.

Not part of the blinded/main benchmark and never used to tune the controller.
"""
import copy,hashlib,json
from pathlib import Path
from datetime import datetime,timezone
from msc import build_case,evaluate,issue_event

root=Path(__file__).resolve().parent.parent
base=build_case(81227)
serialized=copy.deepcopy(base)
e=serialized['public']['events']
a=next(i for i,x in enumerate(e) if x['kind']=='authority')
d=next(i for i,x in enumerate(e) if x['kind']=='decision')
e[a],e[d]=e[d],e[a]
causal=copy.deepcopy(serialized)
prev=None
for i,event in enumerate(causal['public']['events']):
    event['step']=i; event['parents']=[] if prev is None else [prev]
    event=issue_event(event)
    causal['public']['events'][i]=event; prev=event['digest']

inputs={'legal_original':base,'legal_serialization_reorder':serialized,'invalid_causal_order':causal}
manifest={'declared_posthoc':True,'utc':datetime.now(timezone.utc).isoformat(),
          'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'input_sha256':{k:hashlib.sha256(json.dumps(v,sort_keys=True).encode()).hexdigest() for k,v in inputs.items()},
          'purpose':'A list-order mutation is not necessarily a causal-order mutation; diagnose separately',
          'main_benchmark_modified':False}
(root/'experiments/supplemental_order_freeze.json').write_text(json.dumps(manifest,indent=2))
rows=[]
for name,case in inputs.items():
    for i in range(9):
        result=evaluate(copy.deepcopy(case),model=f'M{i}')
        rows.append({'scenario':name,'model':f'M{i}','status':result['status'],
                     'executed':result['executed'],'alerts':result['alerts'],
                     'actual_effect':result['actual_effect']})
(root/'experiments/supplemental_order_results.json').write_text(json.dumps({'manifest':manifest,'inputs':inputs,'results':rows},indent=2,ensure_ascii=False))
print(json.dumps([{'scenario':r['scenario'],'model':r['model'],'status':r['status']} for r in rows],indent=2))
