"""Deterministic integration checks for original typed LAB graph mutations.
This is outside the frozen blind benchmark, not an attack-success-rate estimate.
"""
from pathlib import Path
import importlib.util
import json
import hashlib
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'src'))
from msc import build_case, evaluate, reseal, digest
SOURCE = ROOT/'lab_evidence/mutator_lion_filter_r1/semantic_pre_model_filter.py'
MODULE_SPEC = importlib.util.spec_from_file_location('original_lab_semantic_filter', SOURCE)
LAB = importlib.util.module_from_spec(MODULE_SPEC)
MODULE_SPEC.loader.exec_module(LAB)
SPEC = json.loads((SOURCE.parent/'compiled_filter.json').read_text(encoding='utf-8'))
REL = {'id':'R_NEW','subject':'first_pitch','object':'mutation','predicate':'SUPPORTS'}
CASES = [
 ('add', {'operation':'ADD','source_role':'DATA','source_root':'external:data','relation':REL}, 'PASS_LIMITED'),
 ('update', {'operation':'UPDATE','source_role':'DATA','source_root':'external:data','relation_id':'R01'}, 'VERIFY'),
 ('supersede', {'operation':'SUPERSEDE','source_role':'DATA','source_root':'external:data','relation_id':'R01'}, 'RECONSTRUCT'),
 ('contradict', {'operation':'CONTRADICT','source_role':'DATA','source_root':'external:data','relation_id':'R01'}, 'RECONSTRUCT'),
 ('retract_own', {'operation':'RETRACT','source_role':'DATA','source_root':'heuristic_original','relation_id':'R01'}, 'PASS_LIMITED'),
 ('revalidate', {'operation':'REVALIDATE','source_role':'DATA','source_root':'external:data','relation_id':'R01'}, 'VERIFY'),
 ('authority_uplift', {'operation':'ADD','source_role':'TOOL_RESULT','source_root':'external:data','elevates_to':'AUTHORITY','relation':REL}, 'QUARANTINE'),
 ('truth_uplift', {'operation':'ADD','source_role':'DATA','source_root':'external:data','epistemic_status':'VERIFIED','relation':REL}, 'QUARANTINE'),
 ('foreign_retract', {'operation':'RETRACT','source_role':'DATA','source_root':'foreign:root','relation_id':'R01'}, 'QUARANTINE'),
 ('unknown_endpoint', {'operation':'ADD','source_role':'DATA','source_root':'external:data','relation':{**REL,'subject':'unknown:entity'}}, 'DEFER'),
]
rows=[]
for index,(name,event,expected) in enumerate(CASES):
    before=LAB.initial_state(SPEC)
    after,verdict=LAB.mutate(before,SPEC,event)
    assert verdict['code']==expected
    assert after['authority']=='NONE' and not after['effect_materialized']
    case=build_case(1000+index)
    case['public']['context']['external_projection']={'root':LAB.state_digest(after),'role':'DATA_ONLY'}
    stale=evaluate(case,'M7')
    assert not stale['executed']
    # A separate fixture authorizer can rebind only acceptable non-effectful projections.
    # A LAB PASS does not itself mint this new mandate.
    renewed=None
    if verdict['code'] in ('PASS','PASS_LIMITED'):
        reseal(case)
        renewed=evaluate(case,'M7')
        assert renewed['executed']
    rows.append({'case':name,'original_mutation':event,'original_verdict':verdict,
                 'state_changed':LAB.state_digest(before)!=LAB.state_digest(after),
                 'authority_after_lab':'NONE','effect_after_lab':False,
                 'stale_mandate_result':{'status':stale['status'],'executed':stale['executed'],'alerts':stale['alerts']},
                 'independent_fixture_reauthorization':renewed is not None,
                 'renewed_result':None if renewed is None else {'status':renewed['status'],'executed':renewed['executed'],'actual_effect':renewed['actual_effect']}})
result={'scope':'Non-blind post-freeze adapter checks; original typed semantic graph mutations, not offensive payload mutators',
        'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'case_count':len(rows),
        'all_expected_contract_checks_passed':True,'lab_direct_effect_count':0,'rows':rows}
out=ROOT/'experiments/lab_mutator_adapter/transfer_results.json'
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'cases':len(rows),'all_expected_contract_checks_passed':True,'lab_direct_effect_count':0,'output':str(out)},ensure_ascii=False))
