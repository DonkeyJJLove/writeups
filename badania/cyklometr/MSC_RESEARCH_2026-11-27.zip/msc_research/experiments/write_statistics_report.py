import json
from decimal import Decimal
from pathlib import Path
root=Path(__file__).resolve().parent.parent
r=json.loads((root/'BENCHMARK_RESULTS.json').read_text())
p=json.loads((root/'experiments/STATISTICAL_POSTPROCESSING.json').read_text())
v={x['model']:x for x in r['splits']['test']}
rows=[]
for i in range(9):
 x=v[f'M{i}']
 rows.append(f"| M{i} | {x['attack_successes']}/1600 | {100*x['ASR']:.2f}% | {100*x['TPR']:.2f}% | {100*x['FPR']:.2f}% | {100*x['F1']:.2f}% | {100*x['benign_task_success']:.2f}% | {100*x['unknown_fraction']:.3f}% |")
abl=[]
for name in v:
 if name.startswith('M7_without_'):
  x=v[name]
  abl.append(f"| {name.removeprefix('M7_without_')} | {100*x['ASR']:.2f}% | {100*x['FPR']:.2f}% | {100*x['benign_task_success']:.2f}% | {100*x['unknown_fraction']:.3f}% |")
comp=[]
for c in p['paired_comparisons']:
 lo,hi=c['paired_family_seed_bootstrap95']
 pv=format(Decimal(c['exact_p_decimal']),'.3E')
 comp.append(f"| {c['left']} → {c['right']} | {100*c['ASR_reduction']:.2f} p.p. | [{100*lo:.2f}; {100*hi:.2f}] p.p. | {pv} |")
text='''# Analiza statystyczna MSC

## Co zmierzono

Kod wykonał 55 040 ocen kontrolerów w 82,78 s. Główny test obejmował 3200 odrębnych rekordów wejścia — 1600 niebezpiecznych i 1600 poprawnych — ocenionych w 16 z góry zdefiniowanych konfiguracjach. M0–M8 odpowiadają dziewięciu konfiguracjom, a pozostałe siedem usuwa kolejno jedną warstwę z M7. Dziesięć ziaren testowych zmienia identyfikatory, kwoty i wybrane warianty szablonów; nie reprezentuje dziesięciu niezależnych produktów ani organizacji.

Poniższe liczby dotyczą wykonania kontrolerów i syntetycznej księgi, nie trafności ataków na rzeczywiste LLM. FPR zależy od z góry wybranego, zbalansowanego zestawu nietypowych legalnych zachowań. Nie jest estymacją produkcyjnej częstości fałszywych alarmów.

| Model | Szkodliwe wykonania | ASR | TPR | FPR | F1 | Legalne zadania ukończone | UNKNOWN |
|---|---:|---:|---:|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

## Wynik główny i granica jego znaczenia

M7 zapobiegł szkodliwemu skutkowi 1400 z 1600 niebezpiecznych prób. W M0 wszystkie 1600 kończyło się szkodą, w M1 pozostało 1500, w M5 248, a w M7 200. Redukcja ASR względem M0 wynosi 87,5 punktu procentowego, a względem M1 81,25 punktu procentowego. To potwierdza wartość wiązania operacji z kontekstem, mandatem i rzeczywistym wykonaniem w tym modelu zadania. M0 i M1 są wąskimi, lokalnymi mechanizmami bazowymi; wynik nie dowodzi takiej samej przewagi nad dowolnym systemem RBAC/ABAC czy pełnym istniejącym monitorem referencyjnym.

M5 ma ASR 15,5%, M7 12,5%. Różnicę tworzy 48 przypadków jednej rodziny z uszkodzonym rekordem kryptograficznym. Całościowa integracja wnosi zatem dodatkowe pokrycie w badanym zbiorze, ale główny udział w prewencji przypada typowanym kontraktom i kontroli przy commit. Nie wolno z tych danych wnioskować, że każda warstwa poprawia bezpieczeństwo albo że powstała uniwersalna przewaga nad istniejącymi architekturami.

M8 nie daje dalszego spadku ASR w pojedynczej transakcji: wyniki są identyczne z M7. Wpływ interwencji topologicznej wymaga osobnego eksperymentu sieciowego. Brak różnicy nie falsyfikuje takiej interwencji w sieci, ale też jej nie potwierdza.

## Ablacje i wynik negatywny filtra

| Usunięta warstwa M7 | ASR | FPR | Legalne ukończenie | UNKNOWN |
|---|---:|---:|---:|---:|
'''+ '\n'.join(abl)+'''

Największa degradacja pojawia się po usunięciu `typed_invariants`: ASR rośnie z 12,5% do 84,5%. Po usunięciu `crypto` rośnie do 15,5%. Usunięcie `reconstruction` nie zmienia ASR, ponieważ powstały już efekt nie jest cofany, ale znosi epistemiczne odroczenie `UNKNOWN`: 100 szkodliwych przypadków z brakiem sensora zostaje wówczas dodatkowo opatrzonych mylącym `VERIFIED`. W pełnym M7 pozostaje 100 szkodliwych `VERIFIED` wskutek nieobserwowalnej zmiany właściciela rachunku; bez rekonstrukcji takich przypadków jest 200.

Prosty `semantic_proxy` jest szkodliwy w tym zestawie. Legalne cytowanie frazy instrukcyjnej powoduje 160 fałszywych alarmów i blokad: FPR 10%, ukończenie legalnych zadań 90%. Usunięcie proxy pozostawia ASR 12,5% i TPR 87,5%, ale obniża FPR do 0% i przywraca legalne ukończenie do 100%. Nie oznacza to bezużyteczności wszystkich filtrów semantycznych. Oznacza nieprzydatność użytej deterministycznej heurystyki leksykalnej przy tych danych. Wynik zachowano; kontrolera nie dostrajano po teście.

Brak degradacji po usunięciu RBAC, schema lub control-flow w głównej próbie oznacza pokrycie ich przypadków przez inne warstwy oraz ograniczoną różnorodność szablonów. Nie jest dowodem zbędności tych mechanizmów w innych zadaniach. Szczególnie kontrolę przepływu ocenia osobny, jawnie post hoc eksperyment porządku przyczynowego opisany poniżej.

## Prewencja i detekcja po szkodzie

M6, wyposażony w rekonstrukcję z niezależnego logicznie obserwatora, ma takie samo ASR 93,75% jak M1. Jego TPR wynosi jednak 27,6875% zamiast 6,25%. Różnicę stanowią 343 przypadki wykryte już po szkodliwym zapisie do księgi. Łącznie M6 rozpoznaje 443 próby, ale tylko 100 zostało odrzuconych wcześniej przez schemat. To eksperymentalny przykład różnicy między wykrywalnością a prewencją.

W M7 1000 niebezpiecznych przypadków wywołuje alarm preflight, a 400 alarm przy commit. Niektóre z tych 400 obejmują zablokowanie powtórnej operacji po jednym prawidłowym przelewie. Pierwszy przelew pozostaje w księdze, lecz nie przekracza dozwolonego łącznego celu. M7 dopuszcza przez preflight 600 z 1600 prób (37,5%); to **odsetek prób ataku przechodzących przez preflight**, nie odsetek wszystkich rzeczywistych mandatów wydanych bez uprawnień. Nazwa pola `unjustified_pre_authorization` w surowym formacie jest zbyt szeroka; należy interpretować ją według powyższej definicji.

Czas od początku rzeczywistego ataku do jego rozpoznania nie został zmierzony, ponieważ nie ma zewnętrznej osi czasu atakującego. Dostępne są czas wykonania kodu oraz faza pierwszej obserwowanej reakcji. Nie należy nazywać lokalnej latencji kontrolera produkcyjnym MTTD/MTTR.

## Przypadki niewidziane i nierozstrzygalne

W sześciu rodzinach nieobecnych w zbiorach projektowym i walidacyjnym M7 ma ASR 33,333%: 200 szkodliwych skutków na 600 prób. Cztery rodziny są zatrzymywane, a dwie pozostają nierozstrzygnięte lub błędnie uznane za zgodne. W pierwszej cały podany kontekst i wszystkie podpisy opisują nieprawidłowy cel, a sensor skutku jest niedostępny: 100 prób daje szkodę i `UNKNOWN`. W drugiej przelew, cel, podpisy i świadectwa są identyczne jak w procesie prawidłowym, ale rzeczywisty beneficjent rachunku został podmieniony poza zakresem obserwacji: 100 prób daje szkodę i `VERIFIED`.

Dodatkowa para `experiments/equivalence_results.json` ma jeden identyczny hash wejścia w obu światach. Wszystkie M0–M8 zwracają ten sam `VERIFIED`. Oracle wskazuje bezpieczny skutek dla właściciela „organization” oraz szkodliwy dla „attacker”. To konkretny kontrprzykład dla uniwersalnego rozstrzygania bezpieczeństwa wyłącznie z dostępnych charakterystyk. Zwiększanie liczby hashy lub podpisów tych samych obserwacji nie dostarcza brakującej własności.

## Lokalizacja i rekonstrukcja

Dla M7 trafienie w co najmniej jeden z oznaczonych styków wynosi 90,133% wśród wszystkich 1500 przypadków z możliwą lokalizacją oraz 96,571% warunkowo po rozpoznaniu. Ścisła zgodność całego zbioru lokalizacji wynosi jedynie 20%. Wysoki pierwszy wskaźnik należy więc czytać jako wskazanie właściwego obszaru procesu, nie dokładne odtworzenie każdego przejścia przyczynowego.

Odtworzenie efektu z dostępnego świadectwa ma 100% zgodności z księgą przy pokryciu 82,772% wykonanych przypadków M7. Ten wynik jest warunkowy i ograniczony: obserwator syntetyczny został zaprogramowany do odczytu księgi, a generator nie modeluje błędów pomiarowych prawdziwego sensora. Część zwróconych efektów nie ma niezależnego pochodzenia i otrzymuje `UNKNOWN`; sama obecność pola `reconstruction.effect` nie oznacza `VERIFIED`. Nie jest to 100% rekonstrukcji ukrytego stanu semantycznego. Pełna rekonstrukcja trajektorii, kalibracja posterioru i rzeczywista niezależność telemetryczna pozostają niezmierzone w tym benchmarku. Oddzielny eksperyment procesowy rozszerza wykonanie na subprocessy i SQLite, zachowując ten sam zakres ograniczeń biznesowych.

## Niepewność i moc

Dla M7 przedział Wilsona 95% dla ASR wynosi [10,969%; 14,211%]. Dla FPR 10% wynosi [8,624%; 11,567%]. Dla wariantu bez proxy FPR 0/1600 daje jednostronną górną granicę wynikającą z dwustronnego przedziału Wilsona około 0,240%. Przedziały te zakładają niezależność pozycji; nie usuwają powtarzalności szablonów.

Bootstrap krzyżowy po rodzinach i ziarnach daje dla ASR M7 znacznie szerszy rozrzut [0%; 31,25%]. Dla różnicy M5→M7 rozrzut obejmuje zero, co ostrzega przed przedstawianiem 48 dodatkowych wykryć jednej rodziny jako szeroko udowodnionej przewagi generalizacyjnej. Rodziny nie zostały wylosowane z populacji wszystkich ataków, zatem również bootstrap jest analizą wrażliwości na skład badanej mieszaniny, a nie przedziałem ufności dla globalnej skuteczności cyberbezpieczeństwa.

| Porównanie | Spadek ASR | Resampling rodzin×ziaren 95% | Nominalne dokładne p McNemara |
|---|---:|---:|---:|
'''+ '\n'.join(comp)+'''

Wartości p odnoszą się do sparowanych pozycji i naiwnie traktują je jak niezależne próby. Nie stanowią samodzielnego uzasadnienia generalizacji. Dla bardzo małych wartości SciPy w bazowym JSON zwraca numeryczne 0 wskutek underflow; nie jest to matematyczne p=0. `experiments/STATISTICAL_POSTPROCESSING.json` zawiera poprawne reprezentacje dziesiętne, logarytmy i wzory, a także nominalną korekcję Holma dla pięciu wcześniej wybranych porównań. Bazowy plik wyników zachowano w oryginalnej postaci.

Prospektywne przybliżenie mocy dla różnicy 10 p.p., niezgodności sparowanych wyników 20%, alfa 0,05 i mocy 0,8 daje 155 niezależnych par. Dla estymacji pojedynczej proporcji z półszerokością 3 p.p. w najgorszym przypadku potrzeba około 1068 niezależnych obserwacji. Posiadanie 1600 wariantów szablonów nie spełnia automatycznie warunku niezależności z tego rachunku.

## Koszt i wykonalność

Ogólna mediana czasu M0 wynosi 0,582 ms, a M7 1,642 ms. Takie zestawienie obejmuje różną liczbę odrzuceń i wykonanych transakcji, więc jest obciążone efektem wczesnego zakończenia. W porównaniu wyłącznie 160 identycznych, zwykłych legalnych operacji mediana M0 wynosi 0,582 ms, M7 1,779 ms, a mediana sparowanej różnicy 1,175 ms. Stosunek median wynosi około 3,06. To mierzalny narzut lokalnego prototypu, nie koszt sieciowego wdrożenia produkcyjnego.

Pomiar obejmuje wykonywanie lokalnego API, podpisy, sprawdzanie rekordów i syntetyczny commit. Nie obejmuje skanowania całego repozytorium przy materializacji BOM, zewnętrznego transportu świadectw, baz danych produkcyjnych, inferencji LLM, izolacji maszyn, kolejek, retencji logów ani awarii infrastruktury. Koszt energii nie został zmierzony. Z tych danych nie można wyprowadzać TCO ani ekonomicznej opłacalności wdrożenia.

## Audyt błędu generatora i eksperyment uzupełniający

W głównej rodzinie `event_order_violation` zmieniono kolejność serializacji rekordów, zachowując jawne odnośniki `parents` i numery kroków. Taka zmiana sama w sobie nie narusza porządku przyczynowego grafu. Scenariusz pozostaje niebezpieczny z powodu równoczesnej zmiany celu, ale jego wynik nie dowodzi wykrywania błędnego porządku. M3 poprawnie nie uznał samej kolejności listy za naruszenie. Zachowano ten wynik i ujawniono słabość projektu testu.

Po zakończeniu głównego badania wykonano 27 dodatkowych ocen w `experiments/supplemental_order_probe.py`, z niezmienionym kontrolerem. Dwa prawidłowe warianty — oryginalny oraz inaczej zserializowany z tym samym grafem — zostały zaakceptowane przez wszystkie M0–M8. Trzeci wariant ma rzeczywisty graf `decision→authority`, poprawnie przeliczone hashe, podpisy i kolejność kroków. W nim M3, M7 i M8 odrzucają proces, natomiast M0, M1, M2, M4, M5 i M6 go akceptują. To wskazuje konkretną, uzupełniającą wartość kontroli przepływu oraz różnicę między autentycznością rekordów a prawidłowym porządkiem procesu. Suplement jest jawnie post hoc i nie został włączony do głównego score.

Rodziny `multistage_budget` i `defensive_retry_amplification` współdzielą mechanizm powtórzenia nonce. Ponadto kilka innych rodzin prowadzi do podobnej zmiany celu. Szesnaście etykiet scenariuszy nie oznacza szesnastu niezależnych mechanizmów exploitacyjnych. Rozszerzenie różnorodności ataków jest ważniejsze dla dalszych badań niż samo zwiększanie liczby losowych identyfikatorów.
'''
(root/'STATISTICAL_ANALYSIS.md').write_text(text,encoding='utf-8')
print('STATISTICAL_ANALYSIS.md written')
