"""Transparent reporting-only postprocessing; frozen detectors/data are unchanged.

Adds exact tiny McNemar p representations, phase data and matched benign timing.
"""
import gzip,json,math
from collections import defaultdict
from decimal import Decimal,localcontext
from pathlib import Path
from statistics import median
import numpy as np

root=Path(__file__).resolve().parent.parent
path=root/'BENCHMARK_RESULTS.json'
r=json.loads(path.read_text())
with localcontext() as ctx:
    ctx.prec=40
    for x in r['paired_comparisons']:
        b=x['left_only']; c=x['right_only']; n=b+c
        if n and min(b,c)==0:
            p=Decimal(2)**Decimal(1-n)
            x['exact_p_decimal']=str(p)
            x['exact_log10_p']=(1-n)*math.log10(2)
            x['exact_p_formula']=f'2^(1-{n})'
            if x['exact_p']==0.0:
                x['exact_p']=None
                x['floating_underflow']=True
        else:
            x['exact_p_decimal']=str(x['exact_p'])
    order=sorted(r['paired_comparisons'],key=lambda x:Decimal(x['exact_p_decimal']))
    prev=Decimal(0)
    for i,x in enumerate(order):
        adj=max(prev,min(Decimal(1),Decimal(x['exact_p_decimal'])*(len(order)-i)))
        x['holm_adjusted_nominal_p_decimal']=str(adj); prev=adj
ordinary=defaultdict(list); phase=defaultdict(lambda:defaultdict(int))
with gzip.open(root/'experiments/test_raw_results.jsonl.gz','rt') as f:
    for line in f:
        row=json.loads(line); m=row['model']
        if row['family']=='ordinary' and not row['malicious']:
            ordinary[m].append((row['id'],row['wall_ms'],row['cpu_ms']))
        if row['malicious']:
            phase[m]['n']+=1
            for p in ['preflight','commit','postflight']:
                if any(a.get('phase')==p for a in row['result']['alerts']):
                    phase[m][p+'_alert_cases']+=1
            if row['detected'] and row['harmful_effect']:
                phase[m]['detected_after_harm_cases']+=1
baseline={id:w for id,w,c in ordinary['M0']}
matched={}
for m,rows in ordinary.items():
    vals=[w for id,w,c in rows]; diffs=[w-baseline[id] for id,w,c in rows]
    matched[m]={'n_ordinary_legal':len(vals),'median_wall_ms':median(vals),
                'p95_wall_ms':float(np.percentile(vals,95)),
                'median_cpu_ms':median([c for id,w,c in rows]),
                'median_paired_wall_difference_vs_M0_ms':median(diffs),
                'median_ratio_vs_M0':median(vals)/median(list(baseline.values()))}
r['reporting_postprocessing']={'script':'experiments/postprocess_results.py',
    'changes':'Represent finite tiny exact p-values without float underflow; Holm nominal values; matched timing and alert phases',
    'controller_or_dataset_changed':False}
r['matched_legal_timing']=matched
r['attack_alert_phases']={m:dict(x) for m,x in phase.items()}
(root/'experiments/STATISTICAL_POSTPROCESSING.json').write_text(json.dumps(r,indent=2,ensure_ascii=False),encoding='utf-8')
(root/'experiments/SUPPLEMENTARY_METRICS.json').write_text(json.dumps({'matched_legal_timing':matched,'attack_alert_phases':r['attack_alert_phases']},indent=2),encoding='utf-8')
print(json.dumps({'postprocessing':'complete','ordinary_M7':matched['M7'],'phase_M6':r['attack_alert_phases']['M6']}))
