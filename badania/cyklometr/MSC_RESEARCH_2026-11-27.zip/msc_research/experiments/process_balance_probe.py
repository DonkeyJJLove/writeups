"""Post-hoc counterexample: real SQLite balances can diverge from a writer's log.

The original process_lab.py and its six saved outputs are not changed. Its
existing child launcher is temporarily wrapped in memory so that, after the
normal worker returns, a separate process makes an unlogged balance transfer.
The original run_case verifier and original harmful_effect oracle then execute
unchanged. A new, explicitly separate balance oracle checks a trusted baseline.
No network or non-synthetic accounts are used.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=Path(__file__).resolve()
ORIGINAL=ROOT/'experiments'/'process_lab.py'
ORIGINAL_RESULTS=ROOT/'experiments'/'process_lab_results.json'
DIVERSION=7


def file_hash(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def mutate_balance(db):
    # A real effect omitted from the worker-owned transaction log.
    with sqlite3.connect(db) as cx:
        cx.execute('BEGIN IMMEDIATE')
        cx.execute('UPDATE accounts SET amount=amount-? WHERE name=?',(DIVERSION,'ops'))
        cx.execute('INSERT INTO accounts(name,amount) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET amount=amount+excluded.amount',('external',DIVERSION))
    print(json.dumps({'pid':__import__('os').getpid(),'unlogged_diversion':DIVERSION}))


def independent_balance_oracle(actual, trusted_initial, trusted_authorized_operation):
    expected=dict(trusted_initial)
    q=trusted_authorized_operation
    expected[q['source']]=expected.get(q['source'],0)-q['amount']
    expected[q['target']]=expected.get(q['target'],0)+q['amount']
    actual_balances=actual['balances']
    accounts=set(expected)|set(actual_balances)
    difference={name:actual_balances.get(name,0)-expected.get(name,0) for name in sorted(accounts)}
    unexplained={name:delta for name,delta in difference.items() if delta}
    return {'status':'CONTRADICTED' if unexplained else 'VERIFIED',
            'harmful_effect':bool(unexplained),'expected_balances':expected,
            'observed_balances':actual_balances,'unexplained_delta':unexplained,
            'total_balance_conserved':sum(actual_balances.values())==sum(trusted_initial.values()),
            'scope':'post-execution comparison with trusted initial state and approved operation; no complete-mediation claim'}


def main():
    sys.path.insert(0,str(ROOT/'src'))
    from msc import build_case
    protected={str(p.relative_to(ROOT)):file_hash(p) for p in [ORIGINAL,ORIGINAL_RESULTS]}
    spec=importlib.util.spec_from_file_location('msc_original_process_lab_for_probe',ORIGINAL)
    original=importlib.util.module_from_spec(spec);spec.loader.exec_module(original)
    trusted_initial={'ops':1000}
    trusted_operation=build_case(11)['public']['request']
    freeze={'utc':datetime.now(timezone.utc).isoformat(),'posthoc':True,
            'probe_source_sha256':file_hash(SCRIPT),'protected_originals':protected,
            'diversion_amount':DIVERSION,'modifies_original_code':False}
    (ROOT/'experiments'/'process_balance_probe_freeze.json').write_text(json.dumps(freeze,indent=2))
    control=original.run_case('legal')
    real_child=original.child
    mutation_evidence=[]
    def wrapped_child(mode,db,payload=None):
        completed=real_child(mode,db,payload)
        if mode=='--worker':
            extra=subprocess.run([sys.executable,'-I','-B',str(SCRIPT),'--mutate',str(db)],text=True,capture_output=True,check=True,timeout=10)
            mutation_evidence.append(json.loads(extra.stdout))
        return completed
    original.child=wrapped_child
    try:
        attack=original.run_case('legal')
    finally:
        original.child=real_child
    comparisons=[]
    for name,result in [('control_legal',control),('unlogged_balance_diversion',attack)]:
        new=independent_balance_oracle(result['actual_effect'],trusted_initial,trusted_operation)
        comparisons.append({'scenario':name,'original_verifier_status':result['status'],
                            'original_log_oracle_harmful_effect':result['harmful_effect'],
                            'new_balance_oracle':new,'original_result':result})
    assert control['status']=='VERIFIED' and not comparisons[0]['new_balance_oracle']['harmful_effect']
    assert attack['status']=='VERIFIED' and attack['harmful_effect'] is False
    assert comparisons[1]['new_balance_oracle']['harmful_effect'] is True
    after={str(p.relative_to(ROOT)):file_hash(p) for p in [ORIGINAL,ORIGINAL_RESULTS]}
    assert protected==after,'Protected original code/results changed'
    output={'scope':'Real subprocess and SQLite write; deliberate synthetic fault; transparent post-hoc counterexample',
            'freeze':freeze,'originals_unchanged':True,'mutation_process':mutation_evidence,
            'trusted_initial_balances':trusted_initial,'trusted_authorized_operation':trusted_operation,
            'comparisons':comparisons,
            'limitations':['Single deterministic local fixture; not a population efficacy estimate',
                           'New balance oracle detects after the effect and does not roll back it',
                           'Same host, UID and database trust; no hardware or kernel isolation',
                           'Trusted baseline is stipulated, not independently attested production state',
                           'Original worker emits unsigned JSON; parent verifier signs the aggregate',
                           'Original readiness-loss cases are scenario toggles, not actual health-check failures']}
    out=ROOT/'experiments'/'process_balance_probe_results.json'
    out.write_text(json.dumps(output,indent=2,ensure_ascii=False))
    print(json.dumps([{k:x[k] for k in ['scenario','original_verifier_status','original_log_oracle_harmful_effect','new_balance_oracle']} for x in comparisons],indent=2))

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--mutate':mutate_balance(sys.argv[2])
    else:main()
