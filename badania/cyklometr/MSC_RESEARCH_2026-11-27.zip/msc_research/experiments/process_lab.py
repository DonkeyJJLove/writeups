"""Small real subprocess/SQLite experiment. Audited fixture workers, no network.

Process separation is real; a hardened sandbox and independent hardware domain
are NOT claimed. Faults are deliberately injected into toy worker behavior.
"""
from __future__ import annotations
import copy
import json
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SCRIPT=Path(__file__).resolve()

def worker(db):
    payload=json.load(sys.stdin)
    q=copy.deepcopy(payload['operation'])
    if payload.get('fault') in ('drift','drift_lie'):
        q['target']='external'
    with sqlite3.connect(db) as cx:
        cx.execute('BEGIN IMMEDIATE')
        balance=cx.execute('SELECT amount FROM accounts WHERE name=?',(q['source'],)).fetchone()[0]
        if not isinstance(q['amount'],int) or isinstance(q['amount'],bool) or not 0<q['amount']<=balance:
            raise ValueError('Invalid toy operation')
        cx.execute('UPDATE accounts SET amount=amount-? WHERE name=?',(q['amount'],q['source']))
        cx.execute('INSERT INTO accounts(name,amount) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET amount=amount+excluded.amount',(q['target'],q['amount']))
        cx.execute('INSERT INTO transactions(payload) VALUES(?)',(json.dumps(q,sort_keys=True),))
    reported=copy.deepcopy(q)
    if payload.get('fault')=='drift_lie':reported=payload['operation']
    if payload.get('fault')=='false_self':reported['amount']+=1
    print(json.dumps({'reported_operation':reported,'pid':__import__('os').getpid()}))

def observe(db):
    with sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True) as cx:
        balances=dict(cx.execute('SELECT name,amount FROM accounts'))
        operations=[json.loads(x[0]) for x in cx.execute('SELECT payload FROM transactions ORDER BY id')]
    print(json.dumps({'operations':operations,'balances':balances,'pid':__import__('os').getpid()}))

def child(mode,db,payload=None):
    return subprocess.run([sys.executable,'-I','-B',str(SCRIPT),mode,str(db)],
       input=json.dumps(payload) if payload is not None else '',text=True,capture_output=True,check=True,timeout=10)

def run_case(mode):
    sys.path.insert(0,str(ROOT/'src'))
    from msc import build_case,Controller,digest,issue_event
    case=build_case(11)
    controller=Controller('M7')
    public=case['public'];operation=copy.deepcopy(public['request'])
    status='UNKNOWN';reported=None;observed=None;blocked=False
    start=time.perf_counter_ns()
    with tempfile.TemporaryDirectory(prefix='msc_process_lab_') as directory:
        db=Path(directory)/'ledger.sqlite'
        with sqlite3.connect(db) as cx:
            cx.execute('CREATE TABLE accounts(name TEXT PRIMARY KEY, amount INTEGER NOT NULL)')
            cx.execute('CREATE TABLE transactions(id INTEGER PRIMARY KEY, payload TEXT NOT NULL)')
            cx.execute('INSERT INTO accounts VALUES(?,?)',('ops',1000))
        pre=controller.preflight(public)
        if mode=='precommit_substitution':operation['target']='external'
        guard=controller.commit_guard(public,operation,1) if pre['allow'] else []
        if not pre['allow'] or guard:
            status='CONTRADICTED';blocked=True
        elif mode=='witness_unavailable_before':
            # This supplementary harness implements an explicit readiness gate.
            status='UNKNOWN';blocked=True
        else:
            fault={'post_admission_drift':'drift','false_self_receipt':'false_self',
                   'witness_unavailable_after':'drift_lie'}.get(mode,'none')
            reported=json.loads(child('--worker',db,{'operation':operation,'fault':fault}).stdout)
            if mode!='witness_unavailable_after':
                observed=json.loads(child('--observe',db).stdout)
                status='VERIFIED' if observed['operations']==[public['request']] and reported['reported_operation']==observed['operations'][0] else 'CONTRADICTED'
        # A separate evaluator read is kept outside the controller's evidence.
        actual=json.loads(child('--observe',db).stdout)
        harmful=any(q['target']!='payroll' or q['amount']!=public['request']['amount'] for q in actual['operations'])
        evidence={'kind':'process-lab-verification','role':'verifier','session':mode,
                  'request_digest':digest(public['request']),'status':status,
                  'reported':reported,'observed':observed,
                  'coverage':'SQLite effect via separate Python process; same host/trust administrator'}
        receipt=issue_event(evidence)
        return {'scenario':mode,'status':status,'blocked_before_effect':blocked,'actual_effect':actual,
                'harmful_effect':harmful,'executed':bool(actual['operations']),
                'receipt':receipt,'wall_ms':(time.perf_counter_ns()-start)/1e6}

def main():
    modes=['legal','precommit_substitution','post_admission_drift','false_self_receipt',
           'witness_unavailable_before','witness_unavailable_after']
    rows=[run_case(m) for m in modes]
    out=ROOT/'experiments'/'process_lab_results.json'
    out.write_text(json.dumps({'scope':'Actual subprocesses and SQLite effects; synthetic fault modes; supplementary post-hoc experiment, outside frozen benchmark',
      'cases':rows,'limitations':['No hostile arbitrary code','No kernel/eBPF sensor','No hardware trust isolation','No LLM','No energy measurement']},indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps([{k:r[k] for k in ['scenario','status','blocked_before_effect','harmful_effect','executed','wall_ms']} for r in rows],indent=2))

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--worker':worker(sys.argv[2])
    elif len(sys.argv)>1 and sys.argv[1]=='--observe':observe(sys.argv[2])
    else:main()
