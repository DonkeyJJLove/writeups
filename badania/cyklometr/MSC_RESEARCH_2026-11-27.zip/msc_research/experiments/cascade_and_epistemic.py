"""Conditional numerical experiments, not telemetry of a real network/LLM.

Run from repository root: python experiments/cascade_and_epistemic.py
All gains and likelihoods are declared modeling assumptions. No network I/O.
"""
from __future__ import annotations
import csv
import json
import math
import time
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'experiments' / 'cascade_outputs'

CONFIG = {
    'seed': 20261127, 'draws': 600, 'domains': 3, 'nodes_per_domain': 6,
    'steps': 35, 'intervention_delay_steps': 2,
    'ranges': {'a': [0.35, 1.50], 'b': [0.02, 0.60], 'k': [0.05, 0.95], 'r': [0.10, 0.95]},
    'variants': {
        'classic_shared': {'within_attenuation': 0., 'cross_attenuation': 0., 'local': False, 'retry_cap': None},
        'graph_shared': {'within_attenuation': .5, 'cross_attenuation': .5, 'local': False, 'retry_cap': None},
        'federated_unbounded': {'within_attenuation': .5, 'cross_attenuation': .9, 'local': True, 'retry_cap': None},
        'federated_bounded': {'within_attenuation': .5, 'cross_attenuation': .9, 'local': True, 'retry_cap': .25},
        'shared_bounded_matched': {'within_attenuation': .5, 'cross_attenuation': .9, 'local': False, 'retry_cap': .25},
    },
    'warning': 'Synthetic parameter sweep. Fractions are sensitivity to this sampling distribution, not real-world probabilities.',
}

def graph(rng: np.random.Generator, domains: int=3, size: int=6):
    n = domains*size
    group = np.arange(n)//size
    same = group[:, None] == group[None, :]
    weights = rng.uniform(.1, 1, (n,n)) * (rng.random((n,n)) < np.where(same,.65,.09))
    np.fill_diagonal(weights, 0)
    for i in range(n):
        weights[i, (i//size)*size+(i+1)%size] += .1
    weights /= weights.sum(axis=1,keepdims=True)
    return weights, same

def matrix(w, same, a,b,k,r, variant):
    n = w.shape[0]
    attenuation = np.where(same, variant['within_attenuation'], variant['cross_attenuation'])
    aa = a*w*(1-attenuation)
    influence = same.astype(float) if variant['local'] else np.ones((n,n))
    influence /= influence.sum(axis=1,keepdims=True)
    rr = min(r, variant['retry_cap']) if variant['retry_cap'] is not None else r
    return np.block([[aa,b*influence],[k*np.eye(n),rr*np.eye(n)]])

def rho(m):
    return float(max(abs(np.linalg.eigvals(m))))

def trajectory(before, after, steps=35, delay=2):
    n=after.shape[0]//2
    state=np.zeros(2*n); state[0]=1
    states=[state.copy()]
    for t in range(steps):
        state=(before if t<delay else after)@state
        states.append(state.copy())
    return np.asarray(states)

def cascade():
    rng=np.random.default_rng(CONFIG['seed'])
    rows=[]
    for draw in range(CONFIG['draws']):
        w,same=graph(rng,CONFIG['domains'],CONFIG['nodes_per_domain'])
        params={key:float(rng.uniform(*bounds)) for key,bounds in CONFIG['ranges'].items()}
        before=matrix(w,same,**params,variant=CONFIG['variants']['classic_shared'])
        for name,variant in CONFIG['variants'].items():
            m=matrix(w,same,**params,variant=variant)
            eig=rho(m)
            tr=trajectory(before,m,CONFIG['steps'],CONFIG['intervention_delay_steps'])
            n=len(w); x=tr[:,:n]; q=tr[:,n:]
            below=np.flatnonzero(np.max(x,axis=1)<.01)
            # A threshold crossing is counted only if all remaining observations stay below.
            contained=next((int(t) for t in below if np.all(np.max(x[t:],axis=1)<.01)),None)
            rows.append({'draw':draw,'variant':name,**params,'spectral_radius':eig,'stable_frozen':eig<1,
                         'peak_total_disturbance':float(x.sum(axis=1).max()),
                         'cumulative_disturbance':float(x.sum()),'cumulative_response':float(q.sum()),
                         'nodes_ever_over_0_05':int((x.max(axis=0)>.05).sum()),
                         'containment_step':contained})
    with (OUT/'cascade_raw.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    summary={}
    for name in CONFIG['variants']:
        rr=[r for r in rows if r['variant']==name]
        summary[name]={'runs':len(rr),'stable_fraction':sum(r['stable_frozen'] for r in rr)/len(rr),
          'median_spectral_radius':float(np.median([r['spectral_radius'] for r in rr])),
          'median_cumulative_disturbance':float(np.median([r['cumulative_disturbance'] for r in rr])),
          'median_peak_total_disturbance':float(np.median([r['peak_total_disturbance'] for r in rr])),
          'mean_nodes_ever_over_0_05':float(np.mean([r['nodes_ever_over_0_05'] for r in rr])),
          'contained_by_horizon_fraction':sum(r['containment_step'] is not None for r in rr)/len(rr)}
    # Exact fixed-matrix examples deliberately distinguish attenuation from controller stability.
    examples={'baseline':[[.85,.2],[.15,.2]],
              'protection_destabilizes':[[.35,.4],[1.1,.8]],
              'bounded_local_response':[[.45,.05],[.15,.2]]}
    illustrative={name:{'matrix':m,'spectral_radius':rho(np.array(m))} for name,m in examples.items()}
    a1=np.array([[.5,1.],[0.,.5]]);a2=a1.T
    illustrative['stable_modes_unstable_switching']={'mode_radii':[rho(a1),rho(a2)],'two_step_radius':rho(a2@a1),
      'matrix1':a1.tolist(),'matrix2':a2.tolist()}
    # Marginal sensitivities are descriptive rank-free correlations under the specified joint prior.
    sensitivity={}
    for name in CONFIG['variants']:
        rr=[r for r in rows if r['variant']==name]
        sensitivity[name]={key:float(np.corrcoef([r[key] for r in rr],[r['spectral_radius'] for r in rr])[0,1]) for key in CONFIG['ranges']}
    result={'config':CONFIG,'summary':summary,'illustrative_counterexamples':illustrative,
            'parameter_correlations_with_radius':sensitivity,'units':'dimensionless and discrete model steps',
            'interpretation':'No causal or quantitative claim about production infrastructure. Matched variant separates response topology from attenuation/retry assumptions.'}
    (OUT/'cascade_summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

def update(p,observations,accuracy=.9):
    odds=p/(1-p)
    for observed in observations:
        odds *= accuracy/(1-accuracy) if observed else (1-accuracy)/accuracy
    return odds/(1+odds)

def epistemic():
    rng=np.random.default_rng(CONFIG['seed']+1)
    conf={'seed':CONFIG['seed']+1,'trajectories':150,'steps':60,'copies':5,'sensor_accuracy':.9,
          'initial_compromised_prior':.1,'safe_to_compromised':.02,'compromised_to_safe':.08}
    rows=[]
    for trial in range(conf['trajectories']):
        truth=bool(rng.random()<.1)
        naive=corrected=independent=.1
        for t in range(conf['steps']):
            if t:
                truth=bool(rng.random()<(.92 if truth else .02))
                naive=.92*naive+.02*(1-naive)
                corrected=.92*corrected+.02*(1-corrected)
                independent=.92*independent+.02*(1-independent)
            base=truth if rng.random()<.9 else not truth
            real_independent=[truth if rng.random()<.9 else not truth for _ in range(5)]
            naive=update(naive,[base]*5)
            corrected=update(corrected,[base])
            independent=update(independent,real_independent)
            rows.append({'trial':trial,'step':t,'hidden_compromised':int(truth),'copied_observation':int(base),
                         'posterior_naive_copies':naive,'posterior_dependency_aware':corrected,
                         'posterior_independent_sensors':independent})
    with (OUT/'epistemic_hmm_raw.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    summary={}
    for method in ['naive_copies','dependency_aware','independent_sensors']:
        preds=np.array([r['posterior_'+method] for r in rows]);y=np.array([r['hidden_compromised'] for r in rows])
        clipped=np.clip(preds,1e-15,1-1e-15)
        summary[method]={'brier_score':float(np.mean((preds-y)**2)),
          'log_loss':float(np.mean(-y*np.log(clipped)-(1-y)*np.log(1-clipped))),
          'wrong_extreme_confidence_fraction':float(np.mean(((preds>.99)&(y==0))|((preds<.01)&(y==1))))}
    result={'config':conf,'summary':summary,'limitation':'Known simulated transitions and calibrated likelihoods. No learned agent-state model or real sensor calibration.'}
    (OUT/'epistemic_summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter();c=cascade();e=epistemic()
    print(json.dumps({'cascade':c['summary'],'counterexamples':c['illustrative_counterexamples'],
      'epistemic':e['summary'],'wall_seconds':time.perf_counter()-start},indent=2))

if __name__=='__main__':main()
