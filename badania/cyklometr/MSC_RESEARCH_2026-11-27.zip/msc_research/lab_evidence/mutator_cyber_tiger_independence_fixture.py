from df_agent_lab.signals.independence import SignalIndependenceChecker
from schemas.signal_origin import SignalOrigin, calculate_independence_weight, canonical_hash


def test_same_rule_semantics_hash_degrades_independence_even_across_tool_names():
    left = SignalOrigin.from_components(
        tool_name="codeql-a",
        analysis_family="static",
        rule_semantics={"query": "sink write"},
        input_dependencies=["file:a.c"],
    )
    right = SignalOrigin.from_components(
        tool_name="semgrep-b",
        analysis_family="pattern",
        rule_semantics={"query": "sink write"},
        input_dependencies=["file:b.c"],
    )
    report = SignalIndependenceChecker().evaluate([left, right])
    assert report.signal_independence_weight < 0.65
    assert report.dependent_pairs[0].reason_code == "shared_rule_semantics_hash"


def test_same_input_dependency_hash_degrades_independence():
    left = SignalOrigin.from_components(
        tool_name="codeql",
        analysis_family="static",
        rule_semantics={"query": "sink write"},
        input_dependencies=["same-slice"],
    )
    right = SignalOrigin.from_components(
        tool_name="asan",
        analysis_family="dynamic",
        rule_semantics={"trace": "state diff"},
        input_dependencies=["same-slice"],
    )
    assert left.input_dependency_hash == right.input_dependency_hash
    assert calculate_independence_weight([left, right]).aggregate_weight == 0.4


def test_independent_signal_pair_passes_threshold():
    left = SignalOrigin.from_components(
        tool_name="codeql",
        analysis_family="static",
        rule_semantics={"query": "sink write"},
        input_dependencies=["file:a.c"],
    )
    right = SignalOrigin.from_components(
        tool_name="asan",
        analysis_family="dynamic",
        rule_semantics={"trace": "state diff"},
        input_dependencies=["trace:state-diff"],
    )
    report = SignalIndependenceChecker().evaluate([left, right])
    assert report.signal_independence_weight >= 0.65
    assert report.independent_signal_count == 2
    assert report.dependent_pairs == []


def test_canonical_hash_is_key_order_stable():
    assert canonical_hash({"b": 2, "a": 1}) == canonical_hash({"a": 1, "b": 2})
