# Uruchomiona kompilacja heurystyki → Semantic Pre-Model Filter

**Wykonywalny, wyłącznie nieefektowy kandydat badawczy.** Wymaga Python 3.11+ bez zależności zewnętrznych. Do folderu dołączono oryginalne bajty tekstu wejściowego wraz z CRLF i polskimi znakami. Nie dopisano wyniku do kanonicznych ownerów ai_platform.

```sh
python compile_heuristic.py
python -m unittest -v test_filter
python -I semantic_pre_model_filter.py \
  --spec compiled_filter.json \
  --source 'Wklejony tekst(20261010-180707).txt' \
  --request sample_request.json \
  --out sample_output.json \
  --out-state sample_state.json
```

`compile_heuristic.py` jest **manualnie zakodowanym kompilatorem konkretnej przekazanej heurystyki**. Sprawdza 19 literalnych fragmentów oryginału i ich zakresy bajtów, zachowuje SHA-256 oryginalnego pliku, nadaje węzłom i relacjom status epistemiczny, a wynik zapisuje w `compiled_filter.json`. Tylko część narracji została przekompilowana do minimalnej relewantnej ontologii — pozostały tekst zachowano w źródle.

`semantic_pre_model_filter.py` to reużywalny interpreter **typowanego wejścia semantycznego**. Obsługuje zmiany grafu, currentness, provenance, filtrowanie relewantne, 9 stanów decyzji, oceny trajektorii, nieefektowe context projection i sumy bajtów. Nie parsuje dowolnego polskiego tekstu na graf, nie potrafi niezależnie stwierdzić prawdziwości twierdzeń i nie nadaje uprawnień wykonawczych. Wejście `--state` w tym przykładzie jest zaufanym stanem wyłącznie w granicach izolowanego demonstratora; integracja produkcyjna wymaga właściwego persistence/binding i ochrony przed podmianą snapshotu. Pole `anchors_verified_outside_filter` jest symulowane w jednym teście, nie zaimplementowano źródła takiej autoryzacji.

Pliki:

- `compiled_filter.json` — 9 klas ontologii, 22 węzły, 15 relacji, 8 niezmienników, 19 zakresów dowodowych i routing do istniejących ownerów.
- `COMPILATION_REPORT.md` — pełne sześć warstw, stan maszynowy i klasa dowodu.
- `semantic_pre_model_filter.py` — wykonywalny interpreter filtra.
- `test_filter.py`, `test_log.txt`, `test_results.json` — 39 testów i readback.
- `sample_request.json`, `sample_output.json`, `sample_state.json` — rzeczywiste wywołanie bez efektu.
- `CHECKPOINT.json` — ukończona delta i niezależny pierwszy niezamknięty krok.
- `MANIFEST.json` — SHA-256 i rozmiary plików bez samohashowania.

Wszystkie pliki tekstowe w UTF-8; surowe źródło zachowuje CRLF. Zmiana któregokolwiek bajtu surowego źródła powoduje fail-closed podczas walidacji związania specyfikacji. Nawet `PASS` filtra oznacza tylko zaakceptowanie nieefektowej reprezentacji; prawdziwe wykonanie wymaga istniejącej ścieżki LION.
