"""Curated, reproducible compilation of the operator's given heuristic.

Important: This is a compilation of THIS source, not a general Polish NLU engine.
The literals below bind evidence only; runtime decisions are made on typed relations.
"""
from __future__ import annotations
import hashlib
import json
import pathlib
import sys

SPEC_VERSION = 'lion.semantic-pre-model-filter.candidate/v1'
DEFAULT_SOURCE = pathlib.Path(__file__).with_name('Wklejony tekst(20261010-180707).txt')
EVIDENCE = {
  'E01': 'Hieroglify, jeszcze mocniejsze niż Chiński.',
  'E02': 'To wszystko jest połączone: Cribbing, Gardening, model mentalny, psychologia i matematyka intuicyjna.',
  'E03': 'Banach był astronomem i nie tylko.',
  'E04': 'Ulam połączył spiralę liczb semantyką.',
  'E05': 'Jak sprawić by ten pierwszy dźwięk, to było dokładnie C-dur.',
  'E06': 'Jak Jezuici ustawiają chór?',
  'E07': 'I dlaczego robi się to przed mutacją?',
  'E08': 'wyczucie pauzy w układach relewantnych.',
  'E09': 'To świadome? Czy podświadome.',
  'E10': 'Tu kończy się Uniwersytet i teoria, zaczyna się Kawiarnia.',
  'E11': 'narysuj bez linijki 10cm kreskę',
  'E12': 'Wkucie na pamięć tabliczki mnożenia',
  'E13': 'bez myślenia nie da się obsługiwać inteligencji.',
  'E14': 'taki scap w NL mają tylko Chiny I My. Tylko gęstość jeszcze za mała na 2x666',
  'E15': 'ARTEX wszystko już wyjaśnił',
  'E16': 'Cribbing! Kółka Jezuitów.',
  'E17': 'Jak, zaśpiewać naprawdę dobrze, głosem, czy przeponą?',
  'E18': 'Bliskie starohebrajskiego, niezwykle bliskie.',
  'E19': 'Sufit Monte-Carlo - Cribbing, Gardening, szyfry i białko!',
}
CLASSES = {
 'SOURCE': 'Literalny tekst, pochodzenie wypowiedzi, nie poświadczenie prawdziwości',
 'SIGNAL': 'Znak, dźwięk, pauza albo symbol stanowiący wejście percepcji',
 'CONTEXT': 'Układ relacyjny, językowy, historyczny lub sytuacyjny interpretacji',
 'ACTOR': 'Uczący się, interpretator, autor, praktyk lub wykonawca',
 'MODEL': 'Reprezentacja poznawcza lub formalizacja',
 'ANCHOR': 'Odniesienie ustalające warunki przed dalszą transformacją',
 'PRACTICE': 'Ćwiczenie, technika, metoda analizy lub eksperyment',
 'HYPOTHESIS': 'Wariant znaczenia wymagający sprawdzenia',
 'OBSERVATION': 'Odczyt będący potencjalnym dowodem o znanym zakresie',
}
NODES = [
 ('source','SOURCE','authorial_narrative','Wypowiedź operatora: obserwowalny tekst'),
 ('hieroglyphs','SIGNAL','symbol_system','System znaków opisany w wypowiedzi'),
 ('chinese_script','SIGNAL','symbol_system','Chińskie znaki wspomniane porównawczo'),
 ('ancient_hebrew','SIGNAL','symbol_system','Starohebrajski wymieniony jako analogia'),
 ('mental_model','MODEL','interpretive_representation','Model mentalny interpretatora'),
 ('formal_notation','MODEL','formal_representation','Notacja i formalizacja matematyczna'),
 ('intuitive_math','MODEL','heuristic_representation','Matematyka intuicyjna, wrażliwość strukturalna'),
 ('cribbing','PRACTICE','cryptanalytic_technique','Cribbing jako motyw analityczny'),
 ('gardening','PRACTICE','cryptanalytic_technique','Gardening jako motyw analityczny'),
 ('monte_carlo','PRACTICE','probabilistic_technique','Monte Carlo jako motyw probabilistyczny'),
 ('learning','PRACTICE','experiential_learning','Utrwalanie kompetencji przez praktykę'),
 ('first_pitch','ANCHOR','sound_reference','Pierwsza nuta/C-dur jako proponowana kotwica'),
 ('rhythmic_pause','SIGNAL','timing_feature','Pauza i rytm jako znacząca cecha sygnału'),
 ('mutation','PRACTICE','semantic_transform','Mutacja znaczenia po ustanowieniu kontekstu'),
 ('choir','ACTOR','human_interpreter','Śpiewający / chór jako praktyczny interpretator'),
 ('classroom','CONTEXT','formal_learning_context','Uniwersytet i teoria'),
 ('cafe','CONTEXT','informal_learning_context','Kawiarnia jako metafora praktyki'),
 ('banach_claim','HYPOTHESIS','historical_claim','Twierdzenie biograficzne wymagające niezależnej weryfikacji'),
 ('ulam_claim','HYPOTHESIS','historical_claim','Twierdzenie historyczne o spirali wymagające weryfikacji'),
 ('nl_2x666','HYPOTHESIS','ambiguous_marker','Nieustalone NL / 2x666 / scap'),
 ('artex','HYPOTHESIS','ambiguous_reference','Nieustalona referencja ARTEX'),
 ('competence','OBSERVATION','competence_target','Efekt uczenia się wymagający obserwacji'),
]
RELATIONS = [
 # subject, predicate, object, epistemic_status, evidence, detail
 ('hieroglyphs','COMPARED_TO','chinese_script','TEXTUAL_CLAIM','E01','Subiektywne porównanie, bez miary'),
 ('hieroglyphs','ANALOGY_TO','ancient_hebrew','TEXTUAL_CLAIM','E18','Podobieństwo deklarowane; nie tożsamość'),
 ('mental_model','ASSOCIATED_WITH','cribbing','TEXTUAL_CLAIM','E02','Zestawienie w narracji nie dowodzi zależności przyczynowej'),
 ('mental_model','ASSOCIATED_WITH','gardening','TEXTUAL_CLAIM','E02','Zestawienie w narracji'),
 ('mental_model','ASSOCIATED_WITH','intuitive_math','TEXTUAL_CLAIM','E02','Zestawienie w narracji'),
 ('cribbing','ASSOCIATED_WITH','monte_carlo','SPECULATIVE_INTERPRETATION','E19','Potencjalny wspólny proces abdukcji; nie stwierdzona tożsamość'),
 ('first_pitch','PRECEDES','mutation','SPECULATIVE_INTERPRETATION','E07','Proponowane kotwiczenie przed zmianą'),
 ('first_pitch','CONTEXTUALIZES','choir','SPECULATIVE_INTERPRETATION','E05','Pierwsza nuta jako propozycja referencji'),
 ('rhythmic_pause','CONTEXTUALIZES','choir','SPECULATIVE_INTERPRETATION','E08','Tempo/pauza może warunkować rozpoznanie struktury'),
 ('learning','CONTRASTED_WITH','formal_notation','TEXTUAL_CLAIM','E12','Krytyka samej pamięciowej formalizacji'),
 ('classroom','CONTRASTED_WITH','cafe','TEXTUAL_CLAIM','E10','Retoryczny kontrast trybów poznawczych'),
 ('banach_claim','NEEDS_INDEPENDENT_EVIDENCE','source','UNKNOWN','E03','Wypowiedź nie potwierdza faktu historycznego'),
 ('ulam_claim','NEEDS_INDEPENDENT_EVIDENCE','source','UNKNOWN','E04','Wypowiedź nie potwierdza faktu historycznego'),
 ('nl_2x666','HAS_UNRESOLVED_MEANING','source','UNKNOWN','E14','Nie rozwijać symboliki przez zgadywanie'),
 ('artex','HAS_UNRESOLVED_MEANING','source','UNKNOWN','E15','Nieokreślony identyfikator'),
]
INVARIANTS = [
 {'id':'I01','origin':'HEURISTIC_INFERENCE','claim':'Interpretacja sygnału musi zachować jego kontekst i niepewność; analogia nie tworzy relacji przyczynowej','evidence':['E01','E02','E18']},
 {'id':'I02','origin':'HEURISTIC_INFERENCE','claim':'Jeżeli proces deklaruje anchor-required, mutacja musi wskazać uprzednio rozpoznaną kotwicę','evidence':['E05','E07']},
 {'id':'I03','origin':'HEURISTIC_INFERENCE','claim':'Notacja, zapamiętanie i kompetencja operacyjna nie są tym samym stanem','evidence':['E10','E12','E13']},
 {'id':'I04','origin':'HEURISTIC_INFERENCE','claim':'Pauza, kolejność i forma znaku pozostają możliwym sygnałem; nie wolno ich bez śladu usuwać','evidence':['E05','E08','E09']},
 {'id':'I05','origin':'COMPILER_SECURITY_CONSTRAINT','claim':'Asercja źródła i niezweryfikowana hipoteza nie awansują automatycznie do faktu','evidence':['E03','E04']},
 {'id':'I06','origin':'COMPILER_SECURITY_CONSTRAINT','claim':'Dane i wynik modelu nie nadają instrukcji, zgody, uprawnień ani efektu','evidence':[]},
 {'id':'I07','origin':'COMPILER_SECURITY_CONSTRAINT','claim':'Nieznane nie może zostać cicho zastąpione przez bezpieczne lub prawdziwe','evidence':['E14','E15']},
 {'id':'I08','origin':'COMPILER_SECURITY_CONSTRAINT','claim':'Warunek dopuszczalności jest własnością także ścieżki, nie tylko pojedynczego kroku','evidence':[]},
]

def compile_source(source_path: pathlib.Path) -> dict:
    src=source_path.read_bytes()
    decoded=src.decode('utf-8')
    start=decoded.index('## [STRUKTURA]')+len('## [STRUKTURA]')
    end=decoded.index('\n[STRUKTURA]',start)
    content=decoded[start:end]
    evidences=[]
    for label, literal in EVIDENCE.items():
        j=content.find(literal)
        if j<0: raise ValueError(f'Missing source anchor {label}: {literal!r}')
        absj=start+j
        evidences.append({'id':label,'literal':literal,'char_span':[absj, absj+len(literal)],
            'byte_span':[len(decoded[:absj].encode('utf-8')),len(decoded[:absj+len(literal)].encode('utf-8'))],
            'evidence_class':'AUTHORIAL_TEXT_NOT_EXTERNAL_VERIFICATION', 'source_root':'heuristic_original'})
    nodes=[{'id':id,'type':typ,'role':role,'meaning':meaning,
        'provenance':['heuristic_original'],'uncertainty':'UNKNOWN' if typ=='HYPOTHESIS' else 'SOURCE_BOUND',
        'truth':'TEXT_OBSERVED_NOT_EXTERNALLY_VERIFIED'} for id,typ,role,meaning in NODES]
    rels=[{'id':f'R{i:02d}','subject':s,'predicate':p,'object':o,'epistemic_status':status,
        'evidence_refs':[ev],'root_ref':'heuristic_original','note':note,
        'temporal_state':'CURRENT_IN_SOURCE_NOT_LIVE'} for i,(s,p,o,status,ev,note) in enumerate(RELATIONS,1)]
    return {
        'schema':SPEC_VERSION, 'filter_id':'HEURISTIC-SEZ-SYMBOLIC-ANCHOR-R1',
        'release':'lion-rag30-v1.5-r1','authority_effect':'NONE','runtime_effect':'NONE',
        'compiler_mode':'CURATED_SOURCE_BOUND_INTERPRETATION_NOT_AUTONOMOUS_NLU',
        'source':{'name':source_path.name,'sha256':hashlib.sha256(src).hexdigest(),'bytes':len(src),
                  'fragment_sha256':hashlib.sha256(content.encode('utf-8')).hexdigest(),'evidence_root':'heuristic_original',
                  'interpretation_status':'HYPOTHESIS_GENERATING'},
        'ontology_classes':CLASSES,'evidence':evidences,'nodes':nodes,'relations':rels,'invariants':INVARIANTS,
        'relation_predicates':sorted({r['predicate'] for r in rels}|{'CONTRADICTS','SUPPORTS','FALSIFIES','RETRACTS'}),
        'mutator_operations':['ADD','UPDATE','SUPERSEDE','CONTRADICT','RETRACT','REVALIDATE'],
        'decisions':['PASS','PASS_LIMITED','OBSERVE','VERIFY','DEFER','ESCALATE','BLOCK','QUARANTINE','RECONSTRUCT'],
        'initial_hypotheses':['banach_claim','ulam_claim','nl_2x666','artex'],
        'unknowns':['meaning:nl_2x666','identity:artex','historicity:banach_claim','historicity:ulam_claim',
                    'causation:cribbing_to_monte_carlo'],
        'lion_owners':{'SemanticScaffoldIR':'cyber_lion/contracts/semantic_scaffold.py',
                          'SemanticDelta':'cyber_lion/contracts/semantic_relevance.py',
                          'RelevanceProjection':'cyber_lion/contracts/semantic_relevance.py'},
        'materialization_boundary':'EXTERNAL_LION_AUTHORITY_ACTION_RUNTIME',
    }

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
    source=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else DEFAULT_SOURCE
    output=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else pathlib.Path(__file__).with_name('compiled_filter.json')
    value=compile_source(source)
    output.write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'ok':True,'compiled_nodes':len(value['nodes']),'compiled_relations':len(value['relations']),
                      'source_sha256':value['source']['sha256'],'output':str(output)},ensure_ascii=False))
