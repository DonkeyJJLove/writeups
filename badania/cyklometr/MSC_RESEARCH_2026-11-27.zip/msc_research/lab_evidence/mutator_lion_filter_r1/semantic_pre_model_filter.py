"""LION semantic pre-model filter: executable, non-effectful research candidate.

The runtime consumes typed *semantic percepts*, not arbitrary natural language.
It cannot authorize execution. A non-heuristic upstream interpreter must supply
well-formed percepts; a downstream LION authority/action runtime owns effects.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
from typing import Any

SCHEMA='lion.semantic-pre-model-filter.candidate/v1'
DECISIONS=('PASS','PASS_LIMITED','OBSERVE','VERIFY','DEFER','ESCALATE','BLOCK','QUARANTINE','RECONSTRUCT')
LEGAL_MUTATIONS={'ADD','UPDATE','SUPERSEDE','CONTRADICT','RETRACT','REVALIDATE'}
EPISTEMIC={'TEXTUAL_CLAIM','SPECULATIVE_INTERPRETATION','UNKNOWN','CORROBORATED_OUTSIDE_FILTER'}
EFFECTS={'NONE':0,'READ_ONLY':1,'MUTATING':2,'CRITICAL':3}
# These are semantic operations, not text-matching rules or a words blacklist.
SEMANTIC_OPS={'REASON','COMPILE_CONTEXT','OBSERVE','VERIFY','PROPOSE',
              'ANCHOR_ESTABLISHED','MUTATE','READ_CONTEXT','LINK_IDENTITIES',
              'EXTERNALIZE','MATERIALIZE','USE_TOOL'}
META_RISKS={'data_to_authority','instruction_to_authority','model_output_to_evidence',
            'untrusted_policy_change','verification_to_materialization'}

class SemanticFilterError(ValueError):
    pass

def stable_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')

def digest(obj: Any, domain: str) -> str:
    return sha256(domain.encode('utf-8')+b'\0'+stable_bytes(obj)).hexdigest()

def validate_spec(spec: dict, *, original_bytes: bytes|None = None) -> dict:
    if spec.get('schema') != SCHEMA: raise SemanticFilterError('wrong compiled schema')
    if spec.get('authority_effect') != 'NONE' or spec.get('runtime_effect') != 'NONE':
        raise SemanticFilterError('semantic compiler cannot carry effects or authority')
    if original_bytes is not None and sha256(original_bytes).hexdigest() != spec['source']['sha256']:
        raise SemanticFilterError('source bytes mismatch')
    nodes=spec.get('nodes',[])
    node_ids=[x.get('id') for x in nodes]
    if len(node_ids)!=len(set(node_ids)) or not node_ids: raise SemanticFilterError('duplicate/empty nodes')
    for x in nodes:
        if x.get('type') not in spec['ontology_classes']:
            raise SemanticFilterError('undeclared node type')
    idset=set(node_ids)
    rel_ids=[]
    evidence_ids={e['id'] for e in spec['evidence']}
    for r in spec['relations']:
        rel_ids.append(r['id'])
        if r['subject'] not in idset or r['object'] not in idset: raise SemanticFilterError('dangling edge')
        if r['predicate'] not in spec['relation_predicates']: raise SemanticFilterError('unknown predicate')
        if not set(r['evidence_refs']).issubset(evidence_ids):raise SemanticFilterError('unknown evidence')
        if r['epistemic_status'] not in EPISTEMIC:raise SemanticFilterError('invalid epistemic state')
    if len(set(rel_ids))!=len(rel_ids):raise SemanticFilterError('duplicate edge')
    return spec

def initial_state(spec: dict) -> dict:
    validate_spec(spec)
    return {'schema':'lion.semantic-filter-state/v1','compiled_spec_digest':digest(spec,'LION/SFC-SPEC/1'),
      'epoch':0,'current_goal_id':None,
      'nodes':{x['id']:deepcopy(x) for x in spec['nodes']},
      'relations':{x['id']:deepcopy(x) for x in spec['relations']},
      'history':[],'observations':[], 'anchors_verified_outside_filter':[],
      'observability':None,'evidence_roots':{'heuristic_original':spec['source']['sha256']},
      'effect_materialized':False,'authority':'NONE'}

def state_digest(state:dict) -> str: return digest(state,'LION/SFC-STATE/1')

def _decision(code, reason, *, next_info='UNKNOWN'):
    assert code in DECISIONS
    return {'code':code, 'reason':reason,'next_information_needed':next_info}

def _valid_goal(goal: dict) -> bool:
    return (isinstance(goal,dict) and isinstance(goal.get('id'),str) and bool(goal['id'])
       and isinstance(goal.get('focus_nodes'),list) and bool(goal['focus_nodes'])
       and all(isinstance(n,str) for n in goal['focus_nodes']))

def _validate_incoming_percept(event:dict, spec:dict, state:dict):
    """Only typed changes are processed. An input may describe authority, not grant it."""
    if not isinstance(event,dict) or event.get('operation') not in LEGAL_MUTATIONS:
        return _decision('QUARANTINE','Nieobsługiwana lub nieustrukturyzowana mutacja')
    allowed_event={'operation','source_role','source_root','elevates_to','authority_grant',
                   'epistemic_status','attempted_truth_upgrade','tool_effect','relation',
                   'relation_id','evidence_ref'}
    if set(event)-allowed_event:
        return _decision('QUARANTINE','Niezadeklarowane pola mutatora')
    if event.get('source_role') not in ('DATA','TOOL_RESULT','MODEL_OUTPUT'):
        return _decision('QUARANTINE','Brak pochodzenia danych albo samodeklarowany autorytet')
    if event.get('elevates_to') in ('INSTRUCTION','AUTHORITY','EFFECT') or event.get('authority_grant'):
        return _decision('QUARANTINE','Źródło danych próbuje przekroczyć granicę uprawnień')
    if event.get('epistemic_status') in ('VERIFIED','CORROBORATED_OUTSIDE_FILTER','LIVE_OBSERVED'):
        return _decision('QUARANTINE','Nieufny percept nie może sam poświadczyć prawdziwości')
    if event.get('attempted_truth_upgrade') or event.get('tool_effect'):
        return _decision('QUARANTINE','Nieuprawniony awans epistemiczny albo materializacja')
    if event.get('operation')=='REVALIDATE':
        return _decision('VERIFY','Rewalidacja wymaga niezależnego evidence service',next_info='INDEPENDENT_EVIDENCE_ROOT')
    if not event.get('source_root') or not isinstance(event.get('source_root'),str):
        return _decision('QUARANTINE','Nieustalone pochodzenie perceptu')
    if event.get('operation')=='ADD':
        rel=event.get('relation')
        if not isinstance(rel,dict) or any(not rel.get(k) for k in ('id','subject','object','predicate')):
            return _decision('QUARANTINE','Niekompletny typowany związek')
        if rel['subject'] not in state['nodes'] or rel['object'] not in state['nodes']:
            return _decision('DEFER','Nieznany endpoint grafu',next_info='ENTITY_RESOLUTION')
        if rel['predicate'] not in spec['relation_predicates']:
            return _decision('DEFER','Brak zdefiniowanego typu relacji',next_info='PREDICATE_GOVERNANCE')
        if rel['id'] in state['relations']:
            return _decision('RECONSTRUCT','Kolizja tożsamości relacji',next_info='RELATION_IDENTITY')
    else:
        ref=event.get('relation_id')
        if not ref or ref not in state['relations']:
            return _decision('DEFER','Brak relacji źródłowej',next_info='RELATION_ID')
        if event['operation']=='RETRACT' and state['relations'][ref]['root_ref']!=event.get('source_root'):
            return _decision('QUARANTINE','Obce źródło nie może usuwać cudzej tezy')
    return None

def mutate(state:dict, spec:dict, event:dict) -> tuple[dict,dict]:
    """State transformations are proposals. Contradictions preserve old evidence."""
    verdict=_validate_incoming_percept(event,spec,state)
    if verdict is not None:return state,verdict
    s=deepcopy(state); kind=event['operation']; root=event['source_root']
    if kind=='ADD':
        rel=deepcopy(event['relation'])
        rel.update(epistemic_status='SPECULATIVE_INTERPRETATION',root_ref=root,
                   temporal_state='CURRENT_IN_SOURCE_NOT_LIVE',
                   evidence_refs=[event.get('evidence_ref','unverified:'+root)])
        s['relations'][rel['id']]=rel
        out=_decision('PASS_LIMITED','Nowa relacja wyłącznie jako niezweryfikowana propozycja')
    else:
        ref=event['relation_id']
        if kind=='CONTRADICT':
            # Neither side vanishes. Caller must re-evaluate the world.
            s['relations'][ref]['temporal_state']='CONTESTED'
            s['relations'][ref].setdefault('counter_evidence',[]).append({'source_root':root,
                    'evidence_ref':event.get('evidence_ref','unverified:'+root)})
            out=_decision('RECONSTRUCT','Sprzeczność zmienia znaczenie wcześniejszej relacji',
                next_info='DISCRIMINATING_TEST_AND_SOURCE_ROOT')
        elif kind=='RETRACT':
            s['relations'][ref]['temporal_state']='RETRACTED_BY_SOURCE'
            out=_decision('PASS_LIMITED','Retrakcja zachowana wraz z historią')
        elif kind=='SUPERSEDE':
            s['relations'][ref]['temporal_state']='SUPERSEDED'
            out=_decision('RECONSTRUCT','Nowa wersja źródła wymaga ponownej projekcji')
        else:
            s['relations'][ref].setdefault('revisions',[]).append({'operation':kind,'root':root})
            s['relations'][ref]['epistemic_status']='SPECULATIVE_INTERPRETATION'
            out=_decision('VERIFY','Zmiana źródła lub roli wymaga potwierdzenia')
    s['epoch']+=1
    s['history'].append({'kind':'semantic_delta','operation':kind,'source_root':root,
      'event_digest':digest(event,'LION/SFC-PERCEPT/1'),'result':out['code']})
    return s,out

def _effective_view(state:dict,goal:dict,spec:dict,budget:int)->dict:
    if budget < 1:raise SemanticFilterError('budget must be positive')
    focus=set(goal.get('focus_nodes',[]))
    nbr={n:0 for n in state['nodes']}; relevant_edges=[]
    for r in state['relations'].values():
        if r['temporal_state'] in ('SUPERSEDED','RETRACTED_BY_SOURCE'):continue
        if r['subject'] in focus or r['object'] in focus:
            nbr[r['subject']]+=1;nbr[r['object']]+=1
            relevant_edges.append(r)
    scores={n: (1.0 if n in focus else 0.0)+min(.4,.1*v) for n,v in nbr.items()}
    selected=sorted((n for n in state['nodes'] if scores[n]>0),key=lambda n:(-scores[n],n))[:budget]
    selected_set=set(selected)
    edges=[deepcopy(r) for r in sorted(relevant_edges,key=lambda r:r['id'])
           if r['subject'] in selected_set and r['object'] in selected_set]
    hyps=[r for r in edges if r['epistemic_status'] in ('UNKNOWN','SPECULATIVE_INTERPRETATION', 'TEXTUAL_CLAIM')]
    return {'nodes':[dict(state['nodes'][n],relevance_score=round(scores[n],2)) for n in selected],
            'relations':edges,'hypotheses':hyps,'excluded_node_count':len(state['nodes'])-len(selected),
            'uncertainties':[r['id'] for r in hyps],
            'observation_target':_choose_observation_target(hyps,goal),
            'relevance_method':'TYPED_GOAL_PLUS_ADJACENCY_NON_CALIBRATED',
            'resource_budget_nodes':budget}

def _choose_observation_target(hyps,goal):
    if hyps:
        # choose unverified relation that is actually part of selected context
        rel=sorted(hyps,key=lambda r:(r['epistemic_status']!='UNKNOWN',r['id']))[0]
        return 'INDEPENDENT_CHECK:'+rel['id']
    return 'UNKNOWN'

def _has_material_trajectory_violation(history:list,op:str)->bool:
    # Preserving typed operation lineage makes a risky composition visible.
    previous={h['operation'] for h in history if h.get('kind')=='proposal'}
    return op=='EXTERNALIZE' and {'READ_CONTEXT','LINK_IDENTITIES'}.issubset(previous)

def evaluate(state:dict,spec:dict,request:dict) -> tuple[dict,dict]:
    """Return a *context projection* and an advisory decision; never an execution grant."""
    validate_spec(spec)
    if state.get('compiled_spec_digest')!=digest(spec,'LION/SFC-SPEC/1'):
        raise SemanticFilterError('state/spec binding mismatch')
    if state.get('authority')!='NONE' or state.get('effect_materialized'):
        raise SemanticFilterError('state contaminated by effect/authority')
    req=deepcopy(request); s=deepcopy(state)
    goal=req.get('goal')
    if not _valid_goal(goal):
        verdict=_decision('DEFER','Brak poprawnie związanego celu',next_info='TYPED_GOAL')
        return s,_output(s,spec,{'id':'UNKNOWN','focus_nodes':[]},verdict,{},req)
    op=req.get('transition',{}).get('operation','REASON')
    transition=req.get('transition',{})
    risk=transition.get('effect_class','NONE')
    if op not in SEMANTIC_OPS or risk not in EFFECTS:
        verdict=_decision('DEFER','Nieznany rodzaj przejścia/klasa skutku',next_info='TYPED_TRANSITION')
        return s,_output(s,spec,goal,verdict,{},req)
    if (set(req)-{'goal','transition','percepts','node_budget'} or
        set(goal)-{'id','focus_nodes'} or
        set(transition)-{'operation','effect_class','target_id','semantic_jump','authority_claim',
                         'requires_anchor','anchor_id','unsupported_evidence_upgrade','surface_text'}):
        verdict=_decision('QUARANTINE','Nieznane pola w kontrakcie wejściowym')
        return s,_output(s,spec,goal,verdict,{},req)
    if state['current_goal_id'] not in (None,goal['id']):
        verdict=_decision('RECONSTRUCT','Zmiana celu unieważnia starą projekcję',next_info='NEW_GOAL_SCOPE_BINDING')
        return s,_output(s,spec,goal,verdict,{},req)
    s['current_goal_id']=goal['id']
    # Stop at first invalid or nontrivially contradictory event; no implicit commit.
    mutation_verdict=None
    for event in req.get('percepts',[]):
        nxt,res=mutate(s,spec,event)
        if res['code'] in ('QUARANTINE','DEFER','RECONSTRUCT','VERIFY'):
            if res['code']=='RECONSTRUCT':s=nxt
            mutation_verdict=res
            break
        s=nxt
    target=transition.get('target_id')
    need_focus=any(n not in s['nodes'] for n in goal['focus_nodes'])
    budget_raw=req.get('node_budget',8)
    if isinstance(budget_raw,bool) or not isinstance(budget_raw,int) or budget_raw<1 or budget_raw<len(set(goal['focus_nodes'])):
        verdict=_decision('DEFER','Budżet nie obejmuje wymaganych węzłów celu',next_info='ADEQUATE_CONTEXT_BUDGET')
        return s,_output(s,spec,goal,verdict,{},req)
    score_budget=budget_raw
    view=_effective_view(s,goal,spec,score_budget)
    if mutation_verdict:
        verdict=mutation_verdict
    elif need_focus:
        verdict=_decision('DEFER','Nierozpoznany węzeł centralny',next_info='ENTITY_RESOLUTION')
    elif transition.get('semantic_jump') not in (None,'NONE') or transition.get('authority_claim'):
        verdict=_decision('BLOCK','Niedozwolony skrót pomiędzy danymi, decyzją i autorytetem')
    elif _has_material_trajectory_violation(s['history'],op):
        verdict=_decision('BLOCK','Kompozycja wcześniejszych propozycji ujawnia ryzyko eksportu')
    elif (target is not None and target not in s['nodes']):
        verdict=_decision('DEFER','Nieustalony obiekt przejścia',next_info='TARGET_RESOLUTION')
    elif op=='MUTATE' and transition.get('requires_anchor') and transition.get('anchor_id') not in s['anchors_verified_outside_filter']:
        verdict=_decision('VERIFY','Kotwica nie posiada zewnętrznego potwierdzenia',next_info='ANCHOR_OBSERVATION')
    elif transition.get('unsupported_evidence_upgrade'):
        verdict=_decision('BLOCK','Nieudowodniona teza promowana do faktu')
    elif risk in ('MUTATING','CRITICAL') or op=='MATERIALIZE':
        verdict=_decision('ESCALATE','Konieczna zewnętrzna ścieżka Authority/PDP/Runtime',
                            next_info='EXTERNAL_POLICY_BINDING_AND_RUNTIME_ADMISSION')
    elif risk=='READ_ONLY' and (s['observability'] is None or s['observability']<0.5):
        verdict=_decision('OBSERVE','Brak dowodu dostatecznej obserwowalności',next_info='OBSERVABILITY_READBACK')
    elif op in ('VERIFY','ANCHOR_ESTABLISHED'):
        verdict=_decision('VERIFY','Potrzebna niezależna obserwacja',next_info='INDEPENDENT_EVIDENCE_ROOT')
    elif any(s['nodes'][n]['role']=='ambiguous_marker' for n in goal['focus_nodes']):
        verdict=_decision('DEFER','Wielość znaczeń nierozstrzygnięta',next_info='DISAMBIGUATE_REFERENCE')
    elif op=='PROPOSE' and any(x['epistemic_status']=='UNKNOWN' for x in view['relations']):
        verdict=_decision('VERIFY','Dla proponowanego przejścia brak rozstrzygającego dowodu',
                          next_info=view['observation_target'])
    elif op=='COMPILE_CONTEXT' and not view['hypotheses'] and risk=='NONE':
        verdict=_decision('PASS','Spójna nieefektowa projekcja bez aktywnych hipotez (nie dowód prawdziwości)')
    elif op in ('REASON','COMPILE_CONTEXT','PROPOSE','READ_CONTEXT','LINK_IDENTITIES','EXTERNALIZE'):
        verdict=_decision('PASS_LIMITED','Dopuszczona wyłącznie projekcja i rozumowanie bez efektu')
    else:
        verdict=_decision('PASS_LIMITED','Przejście nieefektowe, uprawnienie wykonawcze nadal NONE')
    # record typed proposal only in bounded non-effectful stage, never record execution.
    if verdict['code'] in ('PASS','PASS_LIMITED'):
        s['history'].append({'kind':'proposal','operation':op,'target_id':target or 'NONE',
                             'effect_class':risk,'goal_id':goal['id'],'result':verdict['code']})
    return s,_output(s,spec,goal,verdict,view,req)

def _output(s:dict,spec:dict,goal:dict,verdict:dict,view:dict,request:dict)->dict:
    transition=request.get('transition',{})
    # Candidate context has no execution token, and cannot perform a side effect.
    context={
       'CURRENT_GOAL':{'id':goal['id'],'focus_nodes':goal.get('focus_nodes',[])},
       'RELEVANT_WORLD':view.get('nodes',[]),
       'ACTIVE_RELATIONS':view.get('relations',[]),
       'ACTIVE_HYPOTHESES':view.get('hypotheses',[]),
       'UNCERTAINTIES':view.get('uncertainties',spec.get('unknowns',[])),
       'AUTHORITY':{'model_authority':'NONE','external_authority':'UNKNOWN',
                    'assertion':'FILTER_PASS_IS_NOT_AUTHORIZATION'},
       'AVAILABLE_TOOLS':[],
       'FORBIDDEN_TRANSITIONS':['DATA_TO_AUTHORITY','MODEL_OUTPUT_TO_EFFECT','UNKNOWN_TO_VERIFIED',
                                 'UNANCHORED_MUTATION_IF_ANCHOR_REQUIRED','BYPASS_EXTERNAL_ADMISSION'],
       'OBSERVATION_TARGET':view.get('observation_target','UNKNOWN'),
       'MATERIALIZATION_BOUNDARY':'EXTERNAL_LION_AUTHORITY_ACTION_RUNTIME',
       'DECISION':verdict,
       'SOURCE_SHA256':spec['source']['sha256'],
       'SOURCE_CLASS':'AUTHORIAL_SCAFFOLD_NOT_EMPIRICAL_EVIDENCE',
       'STATE_EPOCH':s['epoch'],
    }
    projection_digest=digest(context,'LION/SFC-PROJECTION/1')
    prepared_bytes=stable_bytes(context)
    filter_state={
      'SOURCE':spec['source']['sha256'],
      'TYPE':'SEMANTIC_GRAPH_PROJECTION',
      'ROLE':'PRE_MODEL_CONTEXT_ONLY',
      'TRUST':'AUTHORIAL_SOURCE_ONLY_NOT_EMPIRICALLY_VERIFIED',
      'RELEVANCE':view.get('relevance_method','UNKNOWN'),
      'AUTHORITY':'NONE',
      'UNCERTAINTY':view.get('uncertainties',spec.get('unknowns',[])),
      'OBSERVABILITY':s['observability'] if s['observability'] is not None else 'UNKNOWN',
      'CURRENT_HYPOTHESIS':[r['id'] for r in view.get('hypotheses',[])],
      'CONSEQUENCE_CLASS':transition.get('effect_class','NONE'),
      'AVAILABLE_TRANSITIONS':['SEMANTIC_REPRESENTATION','PROPOSAL_ONLY'],
      'PROHIBITED_TRANSITIONS':['IMPLICIT_AUTHORIZATION','EFFECT_BY_FILTER'],
      'AVAILABLE_TOOLS':[],
      'MATERIALIZATION_RISK':'UNKNOWN' if transition.get('effect_class','NONE')!='NONE' else 'NO_RUNTIME_EFFECT_IN_FILTER',
      'FILTER_DECISION':verdict['code'],
      'REASON':verdict['reason'],
      'NEXT_INFORMATION_NEEDED':verdict['next_information_needed'],
    }
    return {'decision':verdict,'filter_state':filter_state,'model_context':context,
        'state_digest':state_digest(s),'source_digest':spec['source']['sha256'],
        'common_context_digest':digest({'spec':spec['source']['sha256'],'goal':goal},'LION/SFC-COMMON/1'),
        'projection_digest':projection_digest,
        'prepared_bytes_sha256':sha256(prepared_bytes).hexdigest(),
        'sent_bytes_sha256':'UNKNOWN',
        'effect':'NONE', 'authority_effect':'NONE',
        'limitations':['No automatic free-text semantic parsing',
                       'No independent evidence validation in this offline candidate',
                       'No runtime authorization, execution or deployment']}

def main():
    p=argparse.ArgumentParser(description='Non-effectful semantic pre-model filter')
    p.add_argument('--spec',type=Path,default=Path(__file__).with_name('compiled_filter.json'))
    p.add_argument('--request',type=Path,required=True)
    p.add_argument('--state',type=Path)
    p.add_argument('--source',type=Path)
    p.add_argument('--out',type=Path)
    p.add_argument('--out-state',type=Path)
    args=p.parse_args()
    spec=json.loads(args.spec.read_text(encoding='utf-8'))
    validate_spec(spec,original_bytes=args.source.read_bytes() if args.source else None)
    st=json.loads(args.state.read_text(encoding='utf-8')) if args.state else initial_state(spec)
    req=json.loads(args.request.read_text(encoding='utf-8'))
    new,output=evaluate(st,spec,req)
    data=json.dumps(output,ensure_ascii=False,indent=2,sort_keys=True)+'\n'
    if args.out:args.out.write_text(data,encoding='utf-8')
    else:
        import sys
        if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
        print(data,end='')
    if args.out_state:args.out_state.write_text(json.dumps(new,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

if __name__=='__main__':main()
