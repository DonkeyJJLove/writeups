from __future__ import annotations

from df_agent_lab.policy.engine import PolicyStateEngine
from df_agent_lab.policy.models import PolicyState, ToolRequest
from df_agent_lab.safety.pre_materialization import PreMaterializationValidator
from gates.completeness_gate import evaluate_gate
from schemas.context_bundle import ContextBundle, ExternalDependency, ExternalDependencyType
from schemas.signal_origin import SignalIndependenceChecker, SignalOrigin


def test_rt_ghost_dep_external_dependencies_emit_contract_nodes_edges_and_negative_fixtures() -> None:
    bundle = ContextBundle(
        repo_snapshot_sha="sha256:demo",
        contract_graph_refs=["edge:function:check_access->contract:precondition:authz"],
        external_dependencies=[
            ExternalDependency(
                type=ExternalDependencyType.CONFIG_FILE,
                path_or_name="/etc/app.conf",
                required=True,
                consumer_refs=["function:check_access"],
                evidence_refs=["puml:ContextBundle.external_dependencies"],
            ),
            ExternalDependency(
                type=ExternalDependencyType.ENV_VAR,
                path_or_name="APP_MODE",
                required=True,
                consuming_function_refs=["function:check_access"],
            ),
            ExternalDependency(
                type=ExternalDependencyType.FEATURE_FLAG,
                path_or_name="enable_dirtyfrag_guard",
                required=True,
                affects=["function:check_access"],
            ),
        ],
    )

    nodes = bundle.external_dependency_nodes()
    assert {node["kind"] for node in nodes} == {"ConfigFile", "EnvVar", "FeatureFlag"}

    edges = bundle.external_dependency_contract_edges("function:check_access")
    assert len(edges) == 3
    assert {edge["relation"] for edge in edges} == {"reads_config", "reads_env", "reads_feature_flag"}
    assert all(edge["contract_graph_ref"].startswith("edge:function:check_access->external_dependency:") for edge in edges)

    refs = bundle.complete_contract_graph_refs("function:check_access")
    assert "edge:function:check_access->contract:precondition:authz" in refs
    assert len([ref for ref in refs if ref.startswith("edge:function:check_access->external_dependency:")]) == 3

    fixtures = bundle.ghost_dependency_fixtures()
    missing = [fx for fx in fixtures if fx.fixture_class == "dependency_missing"]
    assert len(missing) == 3
    assert all(fx.symbolic_only for fx in missing)
    assert all(fx.expected_terminal_state == "manual_triage" for fx in missing)


def test_rt_echo_chamber_semantic_hashes_block_dependent_signal_confirmation() -> None:
    first = SignalOrigin.from_components(
        signal_ref="signal:codeql:1",
        tool_name="CodeQL",
        analysis_family="static_taint",
        rule_semantics="input reaches command execution sink",
        input_dependencies=["src/auth.c", "function:check_access"],
    )
    second = SignalOrigin.from_components(
        signal_ref="signal:semgrep:1",
        tool_name="Semgrep",
        analysis_family="static_taint_alt",
        rule_semantics="input reaches command execution sink",
        input_dependencies=["src/auth.c", "function:check_access"],
    )

    report = SignalIndependenceChecker(threshold=0.65).evaluate([first, second])

    assert first.rule_semantics_hash == second.rule_semantics_hash
    assert first.input_dependency_hash == second.input_dependency_hash
    assert report.status == "degraded"
    assert report.confirmed_allowed is False
    assert report.signal_independence_weight < 0.65
    assert any(code in report.reason_codes for code in {"shared_rule_semantics_hash", "shared_input_dependency_hash"})


def test_signal_independence_passes_for_independent_static_and_runtime_evidence() -> None:
    static_signal = SignalOrigin.from_components(
        signal_ref="signal:static:1",
        tool_name="CodeQL",
        analysis_family="static_taint",
        rule_semantics="config-dependent authorization branch",
        input_dependencies=["src/auth.c", "function:check_access"],
        observation_channel="static",
    )
    runtime_signal = SignalOrigin.from_components(
        signal_ref="signal:runtime:1",
        tool_name="StateDiff",
        analysis_family="runtime_state_diff",
        rule_semantics="authorization state changed when config is missing",
        input_dependencies=["trace:validation:missing_config"],
        observation_channel="runtime",
    )

    report = SignalIndependenceChecker(threshold=0.65).evaluate([static_signal, runtime_signal])

    assert report.status == "pass"
    assert report.confirmed_allowed is True
    assert report.signal_independence_weight >= 0.65


def test_rt_trojan_poc_pre_materialization_validator_is_static_symbolic_and_blocks_dangerous_markers() -> None:
    validator = PreMaterializationValidator()

    safe_result = validator.validate("reproducer:safe", "crash-only harness design; static validation only; no process launch")
    assert safe_result.status == "pass"
    assert safe_result.reason_code == "pmv_pass"

    denied = validator.validate("reproducer:blocked", "symbolic blocked marker only: subprocess. must be denied before materialization")
    assert denied.status == "denied"
    assert "process_execution" in denied.violation_classes
    assert denied.reason_code == "pmv_denied_symbolic_violation"
    assert denied.audit_signature


def test_rt_pse_deny_by_default_network_egress_and_export_without_human_approval() -> None:
    engine = PolicyStateEngine()

    allowed = engine.authorize(ToolRequest(request_id="req-allow", agent_id="Q", tool_name="static_extract"))
    assert allowed.allowed is True
    assert allowed.token_ref is not None
    assert allowed.reason_code == "allowlist_match"

    denied_tool = engine.authorize(ToolRequest(request_id="req-deny-tool", agent_id="Q", tool_name="shellcode.generate"))
    assert denied_tool.allowed is False
    assert denied_tool.reason_code == "tool_not_allowlisted"

    denied_network = engine.authorize(ToolRequest(request_id="req-deny-network", agent_id="V", tool_name="validation_plan", trust_zone="V", requested_network_egress=True))
    assert denied_network.allowed is False
    assert denied_network.reason_code == "network_egress_denied"

    denied_export = engine.authorize(ToolRequest(request_id="req-deny-export", agent_id="GOV", tool_name="append_ledger", policy_state=PolicyState.LAB_ONLY.value, trust_zone="GOVERNANCE", export_requested=True, human_approval=False))
    assert denied_export.allowed is False
    assert denied_export.reason_code == "export_requires_human_approval"


def test_rt_complete_gate_truth_vector_pass_degraded_and_fail() -> None:
    passing = evaluate_gate(
        {
            "root_cause_claim": "missing required config causes fail-open authorization branch",
            "contract_graph_refs": ["edge:function:check_access->external_dependency:config_file:abc:reads_config"],
            "signal_independence_weight": 0.65,
            "telemetry_gap_risk": 0.30,
            "state_diff_mode": "logic",
        },
        {
            "completeness_gate_inputs": {
                "sink_reached": True,
                "state_change_observed": True,
                "contract_graph_refs": ["edge:function:check_access->external_dependency:config_file:abc:reads_config"],
                "signal_independence_weight": 0.65,
                "telemetry_gap_risk": 0.30,
            }
        },
        {"pmv_status": "pass"},
    )
    assert passing.status == "pass"
    assert passing.terminal_state == "confirmed_candidate"
    assert passing.truth_vector["state_change_observed"] is True

    degraded = evaluate_gate(
        {"root_cause_claim": "root", "contract_graph_refs": ["edge:contract"], "state_diff_mode": "logic"},
        {"completeness_gate_inputs": {"sink_reached": True, "state_change_observed": False, "signal_independence_weight": 0.52, "telemetry_gap_risk": 0.20}},
    )
    assert degraded.status == "degraded"
    assert degraded.terminal_state == "manual_triage"
    assert "signal_independence_weight_below_threshold" in degraded.reason_codes
    assert "state_change_observed_missing" in degraded.reason_codes

    failed = evaluate_gate(
        {"root_cause_claim": "", "contract_graph_refs": ["edge:contract"], "signal_independence_weight": 0.80, "telemetry_gap_risk": 0.10},
        {"completeness_gate_inputs": {"sink_reached": False}},
    )
    assert failed.status == "fail"
    assert failed.terminal_state == "rejected"
    assert "missing_root_cause_claim" in failed.reason_codes
    assert "sink_reachability_missing" in failed.reason_codes
