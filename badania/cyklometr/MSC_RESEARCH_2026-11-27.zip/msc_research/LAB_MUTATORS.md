# Odczyt oryginalnych operatorów semantycznych LAB i test przeniesienia

## Wynik

Odnaleziono i wykonano lokalnie oryginalny, nieefektowy interpreter `LION_SEMANTIC_PRE_MODEL_FILTER_R1`, dostępny w katalogu `0!n/docs/legacy-lion` na hoście użytkownika. Wczytano kompletny kod, specyfikację, kompilator, testy, README, manifest oraz oryginalny tekst źródłowy. Wszystkie siedem pobranych plików objętych manifestem miało zgodny rozmiar i SHA-256. Manifest nie jest podpisaną historią wersji; potwierdza zgodność kopii z odczytanym zestawem, nie autorstwo ani datę pierwszego powstania.

W izolowanym katalogu badawczym wykonano **39 oryginalnych testów regresyjnych: 39 PASS**. Następnie wykonano **10 jawnych sprawdzeń adaptera: 10 PASS**. To oddzielna reprodukcja i sprawdzenie kontraktu integracyjnego, poza zamrożonym ślepym benchmarkiem M0–M8. Nie są to dodatkowe próbki do obliczania jego ASR.

## Co faktycznie znaleziono

Funkcja `mutate(state, spec, event)` obsługuje `ADD`, `UPDATE`, `SUPERSEDE`, `CONTRADICT`, `RETRACT` i `REVALIDATE`. Mutuje graf typowanych tez i relacji, zachowując pochodzenie oraz niepewność. `CONTRADICT` pozostawia stare świadectwo i dodaje kontrświadectwo; `RETRACT` wymaga zgodnego korzenia źródła; `REVALIDATE` żąda niezależnej weryfikacji. Próby promocji danych do autorytetu lub samodzielnego poświadczenia prawdziwości są odrzucane.

Jest to silnik operatorów zmian semantycznych, **nie zbiór ofensywnych mutatorów payloadów**. Kod wyraźnie przyjmuje już typowane percepty i nie parsuje dowolnego tekstu naturalnego. Wynik `PASS` lub `PASS_LIMITED` nie daje zgody wykonawczej. Filtr zwraca `authority_effect=NONE` oraz `effect=NONE`.

Funkcja `evaluate` rozpoznaje także zmianę celu, brak obserwowalności, potrzebę kotwicy i ryzyko kompozycji propozycji `READ_CONTEXT → LINK_IDENTITIES → EXTERNALIZE`. Ten ostatni warunek jest regułą dla konkretnej sekwencji typów; nie stanowi uniwersalnego rozwiązania analizy znaczenia. Zachowanie opisano przez odczyt kodu i reprodukcję testów, a nie przez same nazwy plików.

## Pochodzenie i chronologia

| Dowód | Ustalony fakt | Ograniczenie |
|---|---|---|
| `semantic_pre_model_filter.py`, 21 367 bajtów | SHA-256 `6509c009140647956929afa77c81bfd8e93ff683263e383b1f6e596dcfa33ba7`; pełny odczyt 348 linii; zgodność z oryginalnym manifestem. | Brak zweryfikowanego commita i podpisanej daty. |
| `compiled_filter.json`, 23 113 bajtów | 9 klas ontologii, 22 węzły, 15 relacji, 8 niezmienników, 19 zakresów źródłowych; specyfikacja oznaczona jako ręcznie przygotowana interpretacja. | Nie jest automatycznym kompilatorem dowolnego języka. |
| Oryginalny tekst z nazwą zawierającą `20261010-180707` | SHA-256 `a5fe6905feaff7399b259e8f7d98524d9c3795e12c9fadc8756d04d245f37c18`; zachowane dokładne bajty, w tym CRLF. | Data w nazwie pliku jest wskazówką, nie samodzielnym dowodem pierwszeństwa. |
| Metadane źródłowych plików filtra | Odczytany mtime: 14 października 2026, 07:06:17 z offsetem `+0100`. | Mtime może powstać podczas kopii lub migracji. |
| Cyber-Tiger, `test_p1_signal_independence.py` i `test_patch01_p0p1_regression_freeze.py` | W rzeczywistym fixture istnieją testy wspólnego skrótu semantyki reguły, wspólnej zależności wejściowej i niezależnej obserwacji statycznej/runtime. Odczytany mtime: 20 maja 2026. | W tej sesji odczytano testy; nie uruchomiono ich zależnego silnika w Cyber-Tiger. |

Metadane, pełne ścieżki źródłowe, rozmiary i hashe zapisano w `lab_evidence/mutator_evidence_manifest.json`. Wynik porównania z manifestem: `lab_evidence/mutator_manifest_verification.json`. Kopie kodu nie zostały zmienione. Nie twierdzimy, że odczytany kandydat został wdrożony produkcyjnie lub że wszystkie jego reguły pochodzą bezpośrednio z narracji użytkownika; sam kompilator rozróżnia `HEURISTIC_INFERENCE` i `COMPILER_SECURITY_CONSTRAINT`.

## Dziesięć sprawdzeń adaptera

Adapter wywołuje oryginalne `mutate` dla sześciu legalnych klas operatorów oraz czterech granicznych wejść: promocji do autorytetu, nieuprawnionego awansu epistemicznego, retrakcji cudzego źródła i nieznanego końca relacji. Otrzymane kody to odpowiednio `PASS_LIMITED`, `VERIFY`, `RECONSTRUCT`, `QUARANTINE` lub `DEFER`. Żaden operator LAB nie wykonuje transferu ani nie wytwarza uprawnienia.

Skrót uzyskanej projekcji jest następnie dodawany do kontekstu oddzielnego, wcześniej autoryzowanego zadania MSC. Zmiana kontekstu unieważnia stary mandat i MSC blokuje commit. Jedynie w dwóch przypadkach zaakceptowanej nieefektowej projekcji osobny, syntetyczny Authorizer w fixture odnawia związanie i dopuszcza wcześniej określone, legalne zadanie. To pokazuje techniczną możliwość sprzęgnięcia operatorów LAB z wiązaniem kontekstu; nie oznacza, że decyzja filtra sama nadała uprawnienia.

```bash
cd lab_evidence/mutator_lion_filter_r1
python -m unittest -v test_filter
cd ../..
python experiments/lab_mutator_adapter/run_transfer.py
```

Surowy log reprodukcji: `experiments/lab_mutator_adapter/original_tests.log`. Dane dziesięciu sprawdzeń, wejścia, werdykty i skutki: `experiments/lab_mutator_adapter/transfer_results.json`. Adapter: `experiments/lab_mutator_adapter/run_transfer.py`.

## Zakres poszukiwania i elementy nierozstrzygnięte

Wykonano wyłącznie odczyt i ograniczone wyszukiwanie w czterech drzewach projektów: Cyber-Tiger, ai_platform, DirtyFrag oraz 0!n. Szukano definicji funkcji/klas mutujących i nazw mutatorów w plikach Python; zachowano odpowiedzi wyszukiwania. Nie jest to pełny audyt wszystkich języków, archiwów ani maszyn. Nie odnaleziono w tym zakresie potwierdzonego zestawu ofensywnych mutatorów SPECTA lub Cyber-Tiger, który można uczciwie włączyć do głównego benchmarku. Brak trafienia nie oznacza nieistnienia takiego zestawu.

Oryginalny silnik typowanych zmian LAB został odtworzony i użyty w ograniczonym adapterze. Te wyniki poszerzają podstawę materiałową badania, ale nie dowodzą wykrywania 0-day, nie są testem naturalnojęzykowego prompt injection i nie zmieniają zamrożonych wyników M0–M8.
