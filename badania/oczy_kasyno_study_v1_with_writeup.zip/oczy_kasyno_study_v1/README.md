# Oczy szeroko zamknięte są — kasyno wygrywa zawsze

Reprodukowalny pakiet badania formalno-obliczeniowego i ustrukturyzowanej mapy dowodów, wykonanego 6 sierpnia 2026 r.

## Werdykt

**B — warunkowa teoria formalno-obliczeniowa o ograniczonym zakresie i częściowym wsparciu empirycznym.**

Najważniejsze rozstrzygnięcie:

```text
Dodatnia przewaga operatora nie wymaga zamknięcia agenta.
Zamknięcie agenta nie gwarantuje przewagi operatora.
Jeżeli zamknięcie zwiększa ekspozycję lub opóźnia wyjście,
a operator zachowuje dodatnią przewagę warunkową,
wynik kumuluje się zgodnie z E[Σe_tμ_t].
```

Nie uzyskano podstaw dla biologicznego progu 200 ekspozycji, nieodwracalnego zamknięcia ani redukcji dopaminy do prostego przycisku nagrody.

## Zakres

- `M0`: przewaga operatora, stopping i ruina;
- `M1`: decyzja o kontynuacji i liczba ekspozycji;
- `M2`: koncentracja, regret, kalibracja i zmiana reżimu;
- `M3`: sprzężenie ekspozycji, przewagi i opóźnienia adaptacji;
- mapa 26 źródeł empirycznych i metodologicznych;
- 18/18 klas challenge set zakończonych wynikiem PASS.

Badanie nie obejmuje nowych eksperymentów na ludziach ani zwierzętach. Wyniki biologiczne mają status przeglądowy i pomostowy.

## Najważniejsze pliki

- `report.md` — kompletny raport końcowy;
- `claims/claim_registry.csv` — wieloosiowy rejestr twierdzeń;
- `literature/evidence_map.csv` — mapa źródeł;
- `literature/search_log.md` — protokół przeglądu zakresowego;
- `results/aggregated/study_summary_final.json` — wynik maszynowy;
- `results/aggregated/challenge_set_results_final.csv` — challenge set;
- `docs/ODD/` — dokumentacja modeli;
- `docs/preregistration.md` — prerejestracja.

## Uruchomienie

```bash
python -m pip install -r requirements.txt
python src/run_study.py --config configs/config.yaml
python src/adjudicate_fair_game.py
python src/run_supplemental_challenges.py
python src/finalize_package.py
pytest -q
```

Preregistracja SHA-256:

```text
5ff09e7c0cee6184dc82c65c4ea1c20ad2cf747d9b2063ae8feadaf91a88bbad
```
