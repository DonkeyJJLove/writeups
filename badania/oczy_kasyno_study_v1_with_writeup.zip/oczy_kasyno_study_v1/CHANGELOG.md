# Changelog

## 1.0.0 — 2026-08-06

- zamrożono prerejestrację;
- dodano modele M0–M3;
- dodano screening LHS, eksperymenty konfirmacyjne i challenge set;
- dodano formalny rejestr twierdzeń i raport.
