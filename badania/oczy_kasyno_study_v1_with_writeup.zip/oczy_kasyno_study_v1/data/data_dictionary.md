# Słownik danych

- `mu`: oczekiwany wynik operatora na ekspozycję w grze ±1.
- `mean_exposures`: średnia liczba rzeczywistych interakcji do horyzontu.
- `mean_operator_gain`: średni skumulowany wynik operatora.
- `loss_weight`: waga przegranej w lokalnym sygnale uczącym agenta; 1 oznacza wierne kodowanie, wartości niższe — niedoważanie strat.
- `alpha`: szybkość aktualizacji wartości kontynuacji.
- `tau`: temperatura softmax decyzji o pozostaniu.
- `exit_cost`: modelowy koszt wyjścia.
- `mean_policy_concentration`: 1 minus znormalizowana entropia binarnej polityki kontynuacji.
- `regret`: różnica między oczekiwaną nagrodą polityki oracle a wybraną akcją.
- `adaptation_delay`: liczba kroków po zmianie reżimu do osiągnięcia 80% wyborów optymalnych w oknie 20 kroków.
