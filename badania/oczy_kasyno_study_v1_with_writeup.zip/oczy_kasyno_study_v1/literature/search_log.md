# Dziennik wyszukiwania i mapa dowodów

## Status

Wykonano **ustrukturyzowany przegląd zakresowy z mapą siły dowodów**, a nie pełny przegląd systematyczny PRISMA. Celem było zakotwiczenie twierdzeń pomostowych i znalezienie wyników przeciwnych prostemu łańcuchowi `nagroda → zamknięcie → przewaga operatora`.

Data odcięcia: **2026-08-06**. Liczba zakodowanych pozycji kotwiczących: **26**.

## Źródła i ścieżki wyszukiwania

Przeszukano indeksy internetowe prowadzące do stron wydawców i rekordów bibliograficznych, w szczególności PubMed/NCBI, Nature Portfolio, Springer Nature, BMJ, JASS oraz strony DOI. Włączano prace pierwotne, klasyczne prace formalne, przeglądy integracyjne i standardy metodologiczne. Preferowano źródła pierwotne dla twierdzeń technicznych.

Przykładowe grupy zapytań:

```text
martingale strong law predictable exposure conditional drift
random walk gambler ruin finite horizon negative drift
softmax entropy derivative inverse temperature
reward prediction error dopamine causal optogenetic learning
model-based model-free human choices striatal prediction error
habit transition reversal learning outcome devaluation
confidence accuracy dissociation TMS
monetary incentive confidence calibration
near miss gambling motivation continue
partial reinforcement extinction effect schedule
mandatory play break gambling real world randomized
social media engagement reward learning experiment
recommendation ideal preferences user welfare preregistered
Facebook like-minded exposure field experiment attitudes
X algorithm chronological feed randomized political effects
ADEMP simulation studies MCSE ODD PRISMA
```

## Kryteria włączenia

Włączano źródła, które co najmniej jednoznacznie dotyczyły: formalnej przewagi i zatrzymania; ruiny i stawkowania; uczenia model-free/model-based; dopaminergicznych sygnałów predykcyjnych; nawyku, reversal learning i opóźnionych skutków; kalibracji i pewności; bodźców kontynuacyjnych; operatorów platform i zaangażowania; albo metodologii symulacji.

## Kryteria wyłączenia

Wyłączano materiały bez identyfikowalnego źródła pierwotnego, teksty publicystyczne używane jako jedyne wsparcie, niezweryfikowane twierdzenia o jednym „układzie dopaminy”, wyniki mieszające zaangażowanie z dobrostanem bez osobnej miary oraz publikacje, których nie dało się jednoznacznie przypisać do twierdzenia.

## Ograniczenia

Nie wykonano pełnego screeningu wszystkich baz, deduplikacji rekordów ani niezależnego podwójnego kodowania. Liczba pozycji nie jest liczbą wszystkich istniejących badań. Mapa służy do oceny zgodności mechanizmów i granic uogólnienia, nie do metaanalitycznego estymowania jednego efektu.
