import numpy as np
import pandas as pd

from models import (
    binary_entropy,
    fixed_stake_ruin_exact,
    make_confirmatory_exposure_parameters,
    policy_concentration_binary,
    simulate_exposure_model,
    simulate_house_edge,
    softmax_entropy_grid,
)


def test_binary_entropy_bounds_and_symmetry():
    p = np.array([0.1, 0.5, 0.9])
    h = binary_entropy(p)
    assert np.isclose(h[0], h[2])
    assert np.isclose(h[1], np.log(2.0))
    assert np.all(h >= 0)


def test_softmax_concentration_monotone():
    df = softmax_entropy_grid()
    assert np.all(np.diff(df["entropy_nats"]) <= 1e-12)
    assert np.all(np.diff(df["normalized_concentration"]) >= -1e-12)


def test_house_edge_mean_recovers_mu():
    df = simulate_house_edge([0.02], [1000], 100000, 123)
    row = df.iloc[0]
    assert abs(row["mean_gain_per_exposure"] - 0.02) < 0.002
    assert abs(row["p_operator_positive_mc"] - row["p_operator_positive_exact"]) < 0.01


def test_exact_ruin_increases_with_horizon():
    df = fixed_stake_ruin_exact(0.49, 20, [100, 500, 1000])
    assert np.all(np.diff(df["ruin_probability"]) >= -1e-14)


def test_fair_exposure_model_zero_expected_gain():
    params = make_confirmatory_exposure_parameters()
    params = params[(params.mu == 0.0) & (params.loss_weight == 0.25)].head(1)
    df = simulate_exposure_model(params, 20000, 200, 321)
    row = df.iloc[0]
    assert abs(row["mean_operator_gain"]) <= 4 * row["mcse_operator_gain"] + 0.05


def test_policy_concentration_at_half_is_zero():
    assert abs(float(policy_concentration_binary(0.5))) < 1e-10
