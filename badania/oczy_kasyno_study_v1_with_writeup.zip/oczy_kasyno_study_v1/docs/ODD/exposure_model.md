# ODD — model ekspozycji i operatora

## Overview
Agent w każdym kroku podejmuje zakład ±1 albo kończy udział. Operator ma stałą przewagę `mu`; wynik pieniężny jest zerowej sumy. Agent aktualizuje wartość kontynuacji z lokalnego, potencjalnie zniekształconego sygnału.

## Design concepts
Adaptation: delta-rule. Decision: softmax między kontynuacją a wyjściem. Learning: lokalny sygnał `+1/-loss_weight`. Observation: pełny wynik własnego zakładu; prawdziwa wartość oczekiwana nie jest jawna poza interwencją disclosure. Stochasticity: wynik zakładu i decyzja kontynuacji.

## Details
Parametry: `mu`, `loss_weight`, `alpha`, `tau`, `q0`, `exit_cost`, `T`. Wyniki: ekspozycje, wynik operatora i agenta, exit rate, koncentracja polityki, błąd aktualizacji. Operator nie personalizuje przewagi w wersji rdzeniowej.
