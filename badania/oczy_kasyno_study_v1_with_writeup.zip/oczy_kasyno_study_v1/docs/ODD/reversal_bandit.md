# ODD — dwuakcjowy bandyta z odwróceniem reżimu

## Overview
Dwie akcje Bernoulliego mają prawdopodobieństwa 0.8 i 0.2. W połowie horyzontu wartości są zamieniane.

## Design concepts
Agenci różnią się temperaturą, szybkością uczenia, wymuszoną eksploracją, dyskontowaniem historii i dostępem do jawnego kontrfaktu.

## Details
Mierzone są regret, entropia polityki, modelowy proxy pewności, Brier score oraz czas osiągnięcia co najmniej 80% wyborów optymalnych w 20-krokowym oknie.
