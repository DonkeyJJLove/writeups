# Metodologia wykonania

Badanie wykonano jako warunkową analizę formalno-obliczeniową. Część formalna obejmuje prawo wielkich liczb dla dodatniego dryfu, selekcyjną ekspozycję, ruinę gracza i koncentrację softmax. Część obliczeniowa obejmuje benchmark dokładny, Monte Carlo, bandytę z odwróceniem reżimu, screening Latin Hypercube oraz prerejestrowany plan 24 scenariuszy.

Nie wykonywano nowych eksperymentów na ludziach ani zwierzętach. Wnioski biologiczne pozostają twierdzeniami pomostowymi.

Replikacje konfirmacyjne: 8192 na scenariusz; screening: 2048 scenariusze × 128 replikacji; bandyty: 12 000 trajektorii na agenta i środowisko; gry iid: 200 000 replikacji na warunek.

## Finalizacja 1.1.0

Po pierwotnym przebiegu challenge C12 wykazał pozorną różnicę w pojedynczym ziarnie gry uczciwej. Zgodnie z zasadą nieusuwania wyniku wykonano niezależną adjudykację: 16 partii × 8192 trajektorie, czyli 131 072 replikacje na scenariusz. Wszystkie średnie i efekty parowane znalazły się w granicach 3 MCSE. Challenge set rozszerzono do 18 klas o ujemną przewagę, niezerową sumę, selektywną ekspozycję, skończony horyzont ruiny i test braku progu 200.

Mapa literatury jest ustrukturyzowanym przeglądem zakresowym, nie pełnym przeglądem systematycznym PRISMA. Twierdzenia formalne, obliczeniowe, empiryczne i pomostowe są raportowane oddzielnie.
