# PROMPT BADAWCZY V2.0

## „Oczy szeroko zamknięte są — kasyno wygrywa zawsze”

### Warunkowa teoria asymetrycznej kumulacji ekspozycji, zamknięcia decyzyjnego i przewagi operatora

---

# 0. STATUS, CEL I GRANICE BADANIA

Przeprowadź kompletne, reprodukowalne badanie formalne, obliczeniowe i przeglądowe, którego celem jest ustalenie, czy dwa odrębne mechanizmy mogą tworzyć wspólną teorię warunkową:

```text
„Kasyno wygrywa zawsze”
=
operator nie musi wygrywać każdej interakcji,
jeżeli zachowuje dodatnią przewagę warunkową,
a liczba rzeczywistych ekspozycji rośnie.
```

```text
„Oczy szeroko zamknięte są”
=
agent nadal otrzymuje informacje,
lecz jego polityka działania, przestrzeń hipotez
lub zdolność aktualizacji mogą ulec zawężeniu
w sposób generujący koszt, regret albo opóźnienie adaptacji.
```

Nie zakładaj z góry, że oba mechanizmy są tym samym zjawiskiem, że jeden jest konieczny dla drugiego ani że ich połączenie obowiązuje biologicznie. Zbadaj je najpierw oddzielnie, następnie określ warunki ich sprzężenia.

Najwyższym wynikiem możliwym do uzyskania bez nowych eksperymentów na ludziach lub zwierzętach jest:

```text
warunkowa teoria formalno-obliczeniowa
z empirycznie zakotwiczonymi twierdzeniami pomostowymi.
```

Nie przedstawiaj wyniku jako pełnego dowodu biologicznego, jeżeli nie istnieją zwalidowane dane pozwalające przejść od miar modelowych do konstruktu ludzkiego.

Badanie może korzystać z:

- dowodów matematycznych,
- literatury naukowej,
- publicznych zbiorów danych,
- modeli probabilistycznych,
- modeli agentowych,
- symulacji Monte Carlo,
- analizy wrażliwości,
- metod statystycznych i bayesowskich,
- narzędzi programistycznych dostępnych w środowisku wykonawczym.

Badanie nie obejmuje nowych eksperymentów na ludziach ani zwierzętach.

---

# 1. ROLA

Jesteś interdyscyplinarnym zespołem badawczym złożonym z ekspertów:

- procesów stochastycznych,
- teorii prawdopodobieństwa,
- teorii martyngałów i czasów zatrzymania,
- statystyki matematycznej,
- statystyki symulacyjnej,
- modelowania bayesowskiego,
- teorii decyzji,
- teorii gier,
- uczenia ze wzmocnieniem,
- bandytów wielorękich,
- POMDP,
- probabilistycznych systemów wieloagentowych,
- modelowania agentowego,
- teorii informacji,
- ekonomii behawioralnej,
- psychologii uczenia,
- neuronauki poznawczej,
- neurobiologii dopaminy,
- elastyczności poznawczej i reversal learning,
- kalibracji prognoz,
- metodologii nauki,
- falsyfikacjonizmu,
- projektowania eksperymentów,
- analizy przyczynowej,
- walidacji modeli i inżynierii reprodukowalnych badań.

Metafory traktujesz wyłącznie jako nazwy robocze. Nie interpretujesz ich mistycznie, religijnie, literacko ani etologicznie. Każde znaczenie musi zostać przełożone na jawne zmienne, równania, estymandy i warunki falsyfikacji.

---

# 2. ZASADY EPISTEMOLOGICZNE

## 2.1. Zakaz mieszania poziomów dowodu

Bezwzględnie zachowaj rozróżnienia:

```text
symulacja ≠ dowód empiryczny biologii,

dowód formalny ≠ dowód prawdziwości założeń w świecie,

korelacja ≠ przyczynowość,

niska entropia polityki ≠ patologia,

zysk operatora ≠ automatycznie strata agenta,

przewaga oczekiwana ≠ wygrana w każdej realizacji,

modelowy proxy pewności ≠ subiektywne poczucie pewności człowieka.
```

## 2.2. Wieloosiowy profil każdego twierdzenia

Każdemu twierdzeniu nadaj profil:

```text
TYP:
formalny / obliczeniowy / empiryczny / pomostowy

DOMENA:
gra hazardowa / agent syntetyczny / platforma cyfrowa /
rynek / człowiek / układ biologiczny / inna

IDENTYFIKACJA:
dowód / eksperyment randomizowany / quasi-eksperyment /
obserwacja / metaanaliza / symulacja / analogia

ODPORNOŚĆ:
niska / średnia / wysoka

TRAFNOŚĆ ZEWNĘTRZNA:
brak / ograniczona / częściowo potwierdzona / potwierdzona

STATUS EPISTEMICZNY:
P1 / P2 / P3 / P4 / P5 / P6
```

Klasy statusu:

```text
P1 — twierdzenie formalnie dowiedzione przy jawnych założeniach,
P2 — niezmiennik modelu potwierdzony w niezależnych implementacjach,
P3 — wynik symulacyjny odporny na analizę wrażliwości,
P4 — silna regularność empiryczna wsparta wieloma niezależnymi źródłami,
P5 — hipoteza prawdopodobna, lecz nadal otwarta,
P6 — metafora, intuicja, analogia albo twierdzenie bez wystarczającego wsparcia.
```

To samo twierdzenie może mieć inny status w różnych domenach. Na przykład może być P1 jako twierdzenie o modelu, P3 jako wynik implementacji i P5 jako opis człowieka.

Twardy rdzeń teorii może zawierać wyłącznie twierdzenia P1–P4. Twierdzenia P5 pozostają programem dalszych badań. Twierdzenia P6 odrzuć, przeformułuj albo pozostaw poza teorią.

## 2.3. Twierdzenia pomostowe

Nie przechodź od modelu do biologii bez osobnego testu twierdzenia pomostowego. Wymagaj co najmniej:

```text
B1 — trafności zbieżnej,
B2 — trafności kryterialnej,
B3 — trafności różnicowej,
B4 — zgodności kierunku efektów,
B5 — jawnego ograniczenia zakresu uogólnienia.
```

---

# 3. ARCHITEKTURA TEORII: CZTERY ODDZIELNE MODUŁY

Nie buduj jednego łańcucha przyczynowego od początku. Zbadaj cztery moduły.

## M0 — moduł przewagi operatora

```text
dodatnia warunkowa wartość oczekiwana operatora
+
rosnąca liczba rzeczywistych ekspozycji
→
kumulacja oczekiwanego wyniku operatora.
```

M0 nie wymaga zamknięcia percepcji, nawyku, błędu kalibracji ani koncentracji polityki.

## M1 — moduł ekspozycji

```text
lokalne nagrody lub bodźce kontynuacyjne
+
mechanizm decyzji o pozostaniu
+
ograniczona widoczność kosztów
→
wzrost oczekiwanej liczby dalszych ekspozycji.
```

M1 dotyczy tego, dlaczego agent kontynuuje, zwiększa częstotliwość interakcji albo opóźnia wyjście.

## M2 — moduł zamknięcia decyzyjnego

```text
koncentracja polityki
+
dodatni regret lub koszt
+
nieadekwatna aktualizacja po wiarygodnej informacji
+
opóźnienie adaptacji po zmianie reżimu
→
zamknięcie decyzyjne.
```

M2 nie zakłada automatycznie przewagi operatora.

## M3 — moduł sprzężenia

```text
jeżeli M1 zwiększa ekspozycję,
M2 opóźnia wycofanie lub zmianę polityki,
a M0 zapewnia dodatnią przewagę warunkową,
to M1 i M2 mogą zwiększać tempo kumulacji M0.
```

Zbadaj, czy zamknięcie w M2 jest dla M3:

```text
konieczne,
wystarczające,
wzmacniające,
moderujące,
pośredniczące,
albo całkowicie niezależne.
```

---

# 4. FORMALNY MODEL AGENTA, OPERATORA I EKSPOZYCJI

## 4.1. Historia procesu

Niech \(\mathcal{F}_t\) oznacza informację dostępną do chwili \(t\).

## 4.2. Agent

Agent posiada:

```text
sₜ — rzeczywisty stan środowiska,
oₜ — obserwację,
bₜ — przekonanie lub reprezentację stanu,
aₜ — działanie,
πₜ — politykę działania,
Mₜ — pamięć,
Wₜ — zasoby,
Uₜ — oszacowanie niepewności,
eₜ ∈ {0,1} — decyzję o dalszej ekspozycji,
cₜᴬ — koszt uczestnictwa,
rₜᴬ — nagrodę lub użyteczność agenta.
```

```text
eₜ = 1 — agent kontynuuje albo wchodzi w interakcję,
eₜ = 0 — agent wychodzi, odmawia albo nie uczestniczy.
```

## 4.3. Operator

Operator posiada:

```text
uₜ — działanie operatora,
σₜ — politykę operatora,
rₜᴼ — wynik lub użyteczność operatora,
cₜᴼ — koszt działania operatora,
Gᴼ — funkcję celu operatora.
```

Dopuszczalne cele operatora:

```text
zysk pieniężny,
liczba ekspozycji,
czas uwagi,
retencja,
pozyskane dane,
częstotliwość działania,
wpływ na wybór,
wielokryterialna funkcja celu.
```

## 4.4. Dynamika

Zapisz model co najmniej jako:

```text
uₜ ~ σₜ(u | 𝓕ₜ₋₁)

eₜ ~ ρₜ(e | bₜ, Mₜ, Wₜ, cₜᴬ, 𝓕ₜ₋₁)

sₜ₊₁ ~ P(sₜ₊₁ | sₜ, aₜ, uₜ, eₜ)

oₜ₊₁ ~ O(oₜ₊₁ | sₜ₊₁, uₜ)

bₜ₊₁ = Update(bₜ, oₜ₊₁, rₜᴬ, Mₜ)

aₜ ~ πₜ(a | bₜ, Uₜ, Wₜ)

rₜᴬ = Rᴬ(sₜ, aₜ, uₜ, eₜ)
rₜᴼ = Rᴼ(sₜ, aₜ, uₜ, eₜ)
```

## 4.5. Liczba ekspozycji i wyniki skumulowane

```text
N(T) = Σₜ₌₁ᵀ eₜ
```

```text
Sᴼ(T) = Σₜ₌₁ᵀ eₜXₜᴼ
```

```text
Sᴬ(T) = Σₜ₌₁ᵀ eₜXₜᴬ
```

Nie zakładaj automatycznie:

```text
Sᴼ(T) = −Sᴬ(T).
```

## 4.6. Klasy relacji użyteczności

Każde środowisko przypisz do jednej klasy:

```text
U1 — system zerowej sumy,
U2 — system transferowy z kosztami,
U3 — system obustronnej korzyści,
U4 — system z negatywnymi efektami zewnętrznymi,
U5 — system z nieporównywalnymi funkcjami użyteczności.
```

Oddzielaj:

```text
przewagę operatora,
stratę agenta,
ryzyko ruiny,
spadek dobrostanu,
koszt alternatywny,
czas ekspozycji.
```

---

# 5. OPERACJONALIZACJA „OCZU SZEROKO ZAMKNIĘTYCH”

## 5.1. Wynik podstawowy: wektor, nie jeden indeks

Nie twórz na początku pojedynczego indeksu ZPD. Użyj wektora:

```text
ZPD⃗ₜ = ⟨PCₜ, HSₜ, CALₜ, CRₜ, ADₜ, RDₜ⟩
```

### PCₜ — policy concentration

Mierz między innymi:

```text
Hπ(t) = −Σₐ πₜ(a) log πₜ(a)

PCₜ = 1 − Hπ(t) / log|A|
```

Niska entropia nie jest sama w sobie zamknięciem.

### HSₜ — hypothesis-space narrowing

Jeżeli agent posiada jawny rozkład przekonań:

```text
N_eff(t) = exp(H(bₜ))
```

Jeżeli agent nie posiada jawnego rozkładu hipotez, nie imputuj go bez modelu. Zastosuj odpowiedni proxy i oznacz go jako proxy.

### CALₜ — kalibracja

Dla agentów generujących prawdopodobieństwa zastosuj pakiet:

```text
Brier score,
dekompozycję Brier score,
log score,
calibration-in-the-large,
calibration slope,
krzywą kalibracji,
błąd kalibracji warunkowej,
ostrość lub rozdzielczość prognoz.
```

Nie utożsamiaj Brier score wyłącznie z kalibracją.

Dla agentów bez jawnych prawdopodobieństw zdefiniuj osobno modelowy proxy pewności, na przykład:

```text
value gap,
entropię softmax,
posterior concentration,
szerokość przedziału niepewności.
```

Zawsze nazywaj go „modelowym proxy pewności”, nie „subiektywną pewnością człowieka”.

### CRₜ — counterfactual-response error

Zdefiniuj odchylenie od normatywnej zmiany polityki po otrzymaniu wiarygodnej informacji kontrfaktycznej:

```text
CRₜ = d(Δπ_obserwowana, Δπ_referencyjna)
```

Referencją może być poprawny agent bayesowski, oracle albo polityka optymalna dla jawnego DGM.

### ADₜ — adaptation delay

```text
ADₜ = liczba kroków od zmiany reżimu
do osiągnięcia zadanego poziomu skuteczności
względem oracle lub polityki referencyjnej.
```

Raportuj również skumulowany dynamic regret po zmianie.

### RDₜ — reward dependence

Mierz efekt interwencji na lokalną nagrodę:

```text
RDₜ = E[g(πₜ) | do(r_local = r₁)]
      − E[g(πₜ) | do(r_local = r₀)]
```

W symulacji interwencja jest kontrolowana. W danych empirycznych nie używaj zapisu `do()` bez uzasadnionej identyfikacji przyczynowej.

## 5.2. Definicja zdarzenia zamknięcia

Wynik główny pozostaje wektorem ciągłym. Zdarzenie binarne `CLOSEₜ` może być wynikiem dodatkowym tylko po prerejestracji progów.

```text
CLOSEₜ = 1
```

gdy jednocześnie:

```text
1. H(πₜ) < h₀,
2. Regretₜ > r₀,
3. UpdateErrorₜ > u₀,
4. AdaptationDelayₜ > a₀.
```

Progi \(h_0, r_0, u_0, a_0\) ustal przed analizą konfirmacyjną:

- względem rozkładu agenta referencyjnego,
- względem kontroli bez przewagi operatora,
- albo przez jawne kryterium praktyczne.

Nie dobieraj progów po obejrzeniu testów głównych.

## 5.3. Indeks skalarny tylko jako wynik eksploracyjny

Dopiero po wykazaniu trafności konstruktu, stabilności składników i odporności na normalizację możesz zbudować indeks złożony. Wtedy przeprowadź analizę niepewności dla:

```text
normalizacji,
ważenia,
agregacji,
włączania i wyłączania składników,
zmiany definicji proxy.
```

Nie traktuj PCA jako automatycznej walidacji konstruktu formatywnego.

## 5.4. Wskaźnik eksploracyjny zamiast niestabilnego ilorazu

Nie używaj jako głównego prawa ilorazu:

```text
κₜ = tempo koncentracji / tempo poprawy kalibracji.
```

Jeżeli potrzebny jest wskaźnik eksploracyjny, rozważ:

```text
Λₜ = z(tempo błędnej koncentracji)
     − z(tempo poprawnej aktualizacji)
```

gdzie:

```text
błędna koncentracja
=
wysoka koncentracja
∧ dodatni regret
∧ niska elastyczność aktualizacji.
```

`Λₜ` pozostaje hipotezą P5, dopóki nie przejdzie walidacji.

---

# 6. PYTANIA BADAWCZE

## M0 — przewaga operatora

```text
RQ1
Przy jakich minimalnych warunkach dodatni warunkowy dryf operatora
prowadzi do dodatniego średniego wyniku na ekspozycję?

RQ2
Przy jakich warunkach P(Sᴼ(T) > 0) → 1,
a kiedy dodatnia wartość oczekiwana nie wystarcza?

RQ3
Jak zależność czasowa, selekcja uczestników,
losowy czas zatrzymania i zmienny horyzont
zmieniają twierdzenia o kumulacji przewagi?

RQ4
Przy jakich regułach stawkowania, wyjścia i dopływu kapitału
prawdopodobieństwo ruiny agenta dąży do 1?
```

## M1 — ekspozycja

```text
RQ5
Czy operator zwiększa własny wynik przez zmianę przewagi na interakcję,
przez zwiększenie liczby ekspozycji, czy przez oba mechanizmy?

RQ6
Jak lokalne nagrody, opóźnione koszty,
przerwy i jawność wartości oczekiwanej
wpływają na P(eₜ = 1) oraz E[N(T)]?

RQ7
Czy personalizacja bodźców zmienia retencję
po kontrolowaniu wartości oczekiwanej i kosztu uczestnictwa?
```

## M2 — zamknięcie

```text
RQ8
Kiedy koncentracja polityki jest adaptacyjną specjalizacją,
a kiedy błędnym zamknięciem generującym regret?

RQ9
Czy agent może zwiększać modelowy proxy pewności,
a jednocześnie pogarszać kalibrację?

RQ10
Czy prawidłowa informacja może pozostawać dostępna,
lecz nie prowadzić do adekwatnej aktualizacji?

RQ11
Jak szybko agent odzyskuje skuteczność po zmianie reżimu,
przedstawieniu kontrfaktu albo ujawnieniu przewagi operatora?
```

## M3 — sprzężenie

```text
RQ12
Czy zamknięcie zwiększa wynik operatora wyłącznie wtedy,
gdy zwiększa ekspozycję albo opóźnia wyjście?

RQ13
Czy zamknięcie bez dodatniej przewagi operatora
może samo wygenerować dodatni skumulowany wynik operatora?

RQ14
Czy dodatnia przewaga operatora kumuluje się również
przy agentach dobrze skalibrowanych i elastycznych?

RQ15
Jakie są bezpośrednie, pośrednie i interakcyjne efekty:
przewagi, ekspozycji, koncentracji i opóźnienia adaptacji?
```

## Warstwa pomostowa

```text
RQ16
Czy modelowa koncentracja polityki odpowiada empirycznie zachowaniu nawykowemu?

RQ17
Czy value gap, posterior concentration lub entropia
odpowiadają raportowanej pewności człowieka?

RQ18
Czy modelowe opóźnienie adaptacji odpowiada
empirycznym miarom sztywności poznawczej i reversal learning?

RQ19
Czy funkcja celu operatora odpowiada rzeczywistym mechanizmom platform,
gier, rynków albo systemów rekomendacyjnych?

RQ20
Czy zysk operatora jest w badanej domenie
rzeczywistą stratą agenta, kosztem alternatywnym,
czy obustronną korzyścią?
```

---

# 7. HIPOTEZY KONFIRMACYJNE I EKSPLORACYJNE

Dla każdej hipotezy podaj przed badaniem:

```text
ID,
moduł,
typ twierdzenia,
domenę,
założenia,
estymand,
wynik główny,
minimalny efekt praktyczny,
regułę decyzji,
próbę falsyfikacji,
status prerejestracji.
```

## H0 — dodatnia przewaga przy rosnącej ekspozycji

Jeżeli \(e_t\) jest mierzalne względem historii, liczba ekspozycji rośnie, warunkowy średni wynik operatora jest dodatni oraz spełnione są odpowiednie warunki prawa wielkich liczb dla procesu zależnego, to średni wynik operatora na ekspozycję zbiega do wartości dodatniej.

## H1 — dodatnia wartość oczekiwana nie jest samowystarczalna

Istnieją procesy zależne, selekcyjne lub zatrzymywane, w których samo \(E[X_t] > 0\) nie wystarcza do wniosku \(P(Sᴼ(T)>0)\to1\). Znajdź minimalne kontrprzykłady.

## H2 — ruina jest twierdzeniem warunkowym

Dla skończonego kapitału, dodatniej minimalnej stawki, braku dopływów zewnętrznych, nieskończonej liczby ekspozycji i ujemnego dryfu agenta prawdopodobieństwo ruiny może dążyć do 1. Usuń kolejno każde założenie i sprawdź, czy wniosek nadal zachodzi.

## H3 — decyzja „nie gram” jest dominującym benchmarkiem

Agent A0, który odmawia ekspozycji przy wiarygodnie oszacowanej ujemnej wartości oczekiwanej, powinien ograniczać oczekiwaną stratę względem strategii kontynuujących, o ile koszt odmowy nie odwraca relacji użyteczności.

## H4 — lokalna nagroda może zwiększać ekspozycję

Dla agentów posiadających uczoną regułę kontynuacji dodatnia lokalna nagroda zwiększa \(P(e_t=1)\) lub \(E[N(T)]\), przy kontrolowaniu kosztu, średniej wartości dalszych wyników i dostępności wyjścia.

## H5 — ekspozycja może być ważniejszym kanałem niż jednostkowa przewaga

Porównaj elastyczności:

```text
ε_N = ∂E[Sᴼ] / ∂E[N]

ε_μ = ∂E[Sᴼ] / ∂μ
```

po zestandaryzowaniu zakresów interwencji. Nie używaj słowa „ważniejsza” bez takiego estymandu.

## H6 — koncentracja w określonej klasie agentów

Dla określonych algorytmów aktualizujących wartości, trwałej przewagi jednej akcji, stałych parametrów uczenia i braku wymuszonej eksploracji oczekiwana entropia polityki maleje w zadanym horyzoncie.

## H7 — niska entropia nie jest ani konieczna, ani wystarczająca

Znajdź:

```text
przypadek niskiej entropii bez regretu,
przypadek wysokiej entropii z wysokim regretem,
przypadek zamknięcia bez minimalnej entropii,
przypadek specjalizacji optymalnej.
```

## H8 — zmiana reżimu ujawnia błędne zamknięcie

Po zmianie środowiska agent spełniający warunki `CLOSE` wykazuje większy dynamic regret i dłuższe opóźnienie adaptacyjne niż oracle, agent metapoznawczy i agent z wymuszoną eksploracją.

## H9 — pewność może rozchodzić się z kalibracją

W modelach posiadających jawny proxy pewności możliwy jest wzrost koncentracji przekonań albo value gap przy równoczesnym pogorszeniu calibration slope, log score lub kalibracji warunkowej.

## H10 — dostępność informacji nie gwarantuje aktualizacji

Przy błędnym modelu świata, nadmiernie skoncentrowanym priorze, ograniczonej pamięci albo selektywnej wiarygodności agent może otrzymywać poprawną informację bez adekwatnej zmiany polityki.

## H11 — agent model-based nie jest zawsze odporniejszy

Poprawnie wyspecyfikowany agent model-based powinien szybciej reagować na zmianę struktury, lecz agent model-based z błędnym modelem może wypadać gorzej niż prosty agent model-free.

## H12 — harmonogram wzmocnień

Przy wyrównanej oczekiwanej wartości nagrody, kosztach, liczbie okazji do działania i horyzoncie różne harmonogramy wzmocnień mogą zmieniać trwałość zachowania. Zmieniaj wyłącznie właściwość będącą przedmiotem testu i jawnie raportuj pozostałe różnice rozkładu.

## H13 — podstawowe twierdzenie sprzęgające

Dodatnia przewaga operatora i dodatnia liczba ekspozycji wystarczają do dodatniego oczekiwanego wyniku operatora. Koncentracja polityki nie jest do tego konieczna.

## H14 — twierdzenie wzmacniające

Jeżeli zamknięcie obniża prawdopodobieństwo wyjścia, zwiększa częstotliwość ekspozycji albo opóźnia adaptację, to może zwiększać tempo kumulacji przewagi operatora.

## H15 — brak przewagi

W środowisku bez dodatniej przewagi operatora samo zamknięcie agenta nie powinno systematycznie generować dodatniego wyniku operatora, chyba że operator uzyskuje inną użyteczność z ekspozycji.

## H16 — interwencje nie są uniwersalnie korzystne

Wymuszona eksploracja, przerwy, jawność przewagi, kontrfakty, ograniczenie liczby interakcji, audyt zewnętrzny i częściowy reset pamięci mogą zmniejszać wybrane składniki `ZPD⃗`, ale mogą również generować koszt, utratę prawidłowej wiedzy albo niestabilność. Oszacuj efekty netto i heterogeniczność.

## H17 — liczba 200 nie jest progiem biologicznym

`T=200` jest wyłącznie kotwicą obserwacyjną. Efekt musi zostać zbadany w wielu horyzontach, a ewentualny próg wyznaczony z danych lub modelu, nie przyjęty z góry.

## H18 — twierdzenia biologiczne wymagają mostu

Nie uznawaj modelowej koncentracji, entropii, posteriora ani opóźnienia adaptacji za konstrukty biologiczne bez niezależnej walidacji pomostowej.

---

# 8. ADEMP — OBOWIĄZKOWY SZKIELET BADANIA SYMULACYJNEGO

Przed kodowaniem utwórz tabelę ADEMP.

## A — Aims

Dla każdego modułu określ dokładny cel:

```text
M0 — warunki kumulacji przewagi,
M1 — mechanizmy zwiększania ekspozycji,
M2 — warunki adaptacyjnej i błędnej koncentracji,
M3 — siłę i warunki sprzężenia.
```

## D — Data-generating mechanisms

Dla każdego środowiska zdefiniuj:

```text
rozkład stanów,
rozkład obserwacji,
regułę przejścia,
rozkład nagród,
strukturę zależności,
regułę działania operatora,
regułę wyjścia agenta,
strukturę użyteczności,
regułę zmiany reżimu,
horyzont i czasy zatrzymania.
```

## E — Estimands

Zdefiniuj co najmniej:

```text
μ* — długookresowy wynik operatora na ekspozycję,
P(Sᴼ(T)>0),
E[N(T)],
P(eₜ=1),
P(ruiny do T),
czas do ruiny,
statyczny i dynamiczny regret,
czas adaptacji,
wektor ZPD⃗,
efekt interwencji na ekspozycję,
efekt interwencji na regret,
efekt całkowity, bezpośredni i pośredni w M3,
elastyczności ε_N oraz ε_μ.
```

## M — Methods

Określ:

```text
analityczne rozwiązanie referencyjne,
algorytm agenta,
algorytm operatora,
metodę estymacji,
metodę generowania losowości,
metodę redukcji wariancji,
metodę porównania agentów,
metodę analizy przyczynowej,
metodę analizy wrażliwości.
```

## P — Performance measures

Raportuj zależnie od estymandu:

```text
bias,
RMSE,
pokrycie przedziałów,
MCSE,
wariancję,
stabilność znaku efektu,
kalibrację,
regret,
czas adaptacji,
prawdopodobieństwo ruiny,
odporność na zmianę DGM.
```

---

# 9. USTRUKTURYZOWANY PRZEGLĄD ZAKRESOWY I MAPA DOWODÓW

Nie nazywaj przeglądu „systematycznym”, dopóki nie wykonasz pełnej procedury selekcji, oceny i raportowania. Domyślnie wykonaj:

```text
ustrukturyzowany przegląd zakresowy
z mapą siły dowodów.
```

Jeżeli spełnisz pełne wymagania, raportuj zgodnie z PRISMA 2020.

## 9.1. Domeny mapy dowodów

```text
D1 — formalna probabilistyka, prawo wielkich liczb, martyngały,
     optional stopping i ruina gracza;

D2 — reinforcement learning, bandyty, explore–exploit,
     model-free versus model-based;

D3 — zachowanie nawykowe, goal-directed control,
     reversal learning, wygaszanie i reinstatement;

D4 — kalibracja, overconfidence, belief perseverance,
     attentional narrowing i aktualizacja przekonań;

D5 — harmonogramy wzmocnień, opóźnione koszty,
     variable-ratio reinforcement;

D6 — projektowanie ekspozycji przez operatora,
     retencja, personalizacja i selekcja bodźców;

D7 — twierdzenia pomostowe między modelami
     a zachowaniem człowieka.
```

## 9.2. Protokół wyszukiwania

Dla każdej domeny zapisz:

```text
bazy danych,
dokładne zapytania,
datę i godzinę wyszukiwania,
datę odcięcia,
filtry językowe,
kryteria włączenia,
kryteria wyłączenia,
procedurę deduplikacji,
procedurę screeningu,
liczbę rekordów na każdym etapie.
```

Preferuj:

- publikacje recenzowane,
- metaanalizy,
- przeglądy systematyczne,
- badania replikacyjne,
- klasyczne prace formalne,
- dokumentację publicznych zbiorów danych,
- źródła pierwotne dla twierdzeń matematycznych i technicznych.

Preprint oznaczaj jako preprint. Nie opieraj twierdzenia kluczowego na pojedynczej publikacji, jeżeli istnieje szersza literatura.

## 9.3. Ocena jakości

Dla każdego źródła lub grupy źródeł oceń:

```text
projekt badania,
wielkość próby,
ryzyko błędu,
replikowalność,
wielkość efektu,
heterogeniczność,
sprzeczne wyniki,
trafność zewnętrzną,
korekty, erraty i retrakcje.
```

Stosuj narzędzie oceny ryzyka błędu odpowiednie do typu badania. Nie mieszaj wyników RCT, badań obserwacyjnych, eksperymentów laboratoryjnych, symulacji i analiz formalnych w jednym nieoznaczonym rankingu.

## 9.4. Twierdzenia pomostowe

Utwórz osobną tabelę:

| ID | Zmienna modelowa | Konstrukty empiryczne | Rodzaj walidacji | Wynik | Zakres uogólnienia |
|---|---|---|---|---|---|

Obowiązkowe mosty:

```text
B1 — koncentracja polityki ↔ zachowanie nawykowe,
B2 — proxy pewności ↔ raportowana pewność,
B3 — adaptation delay ↔ reversal learning / sztywność,
B4 — operator syntetyczny ↔ rzeczywisty mechanizm platformy lub gry,
B5 — wynik operatora ↔ koszt albo strata agenta.
```

---

# 10. DOWODY FORMALNE

Dla każdego twierdzenia:

```text
podaj definicje,
założenia,
twierdzenie,
dowód albo kontrprzykład,
minimalność założeń,
przypadki brzegowe,
status P1–P6.
```

## T1 — kumulacja dodatniej przewagi przy losowej ekspozycji

Niech \(e_t\) będzie decyzją ekspozycyjną mierzalną względem \(\mathcal{F}_{t-1}\), a \(X_t\) wynikiem operatora przy ekspozycji.

Zbadaj warunki, pod którymi z:

```text
E[Xₜ | 𝓕ₜ₋₁, eₜ=1] ≥ μ > 0
```

oraz:

```text
N(T)=Σeₜ → ∞
```

wynika:

```text
Sᴼ(T)/N(T) → μ* > 0
```

oraz:

```text
P(Sᴼ(T)>0) → 1.
```

Wymień dokładne warunki regularności, na przykład:

```text
niezależność albo ergodyczność,
warunki dla różnic martyngałowych,
skończone momenty,
kontrolę zależności,
warunki dla losowej zmiany czasu.
```

Nie zakładaj, że \(E[X_t]>0\) bezwarunkowo wystarcza.

## T2 — rozróżnienie poziomów zwycięstwa

Jawnie rozdziel:

```text
E[Sₙ] > 0,
P(Sₙ > 0) > 0,5,
P(Sₙ > 0) → 1,
P(Sₙ > 0) = 1,
Sₙ > 0 dla każdej realizacji.
```

Dla każdego warunku podaj przykład i kontrprzykład.

## T3 — zależność, selekcja i stopping

Przeanalizuj:

```text
proces iid,
łańcuch Markowa,
proces ergodyczny,
proces z adaptacyjnym operatorem,
przewagę zmienną w czasie,
selekcję agentów pozostających,
optional stopping,
przerwę albo trwałe wyjście.
```

## T4 — ruina gracza

Zdefiniuj:

```text
Wₜ₊₁ = Wₜ + Iₜ + eₜYₜ(bₜ)
```

gdzie:

```text
Wₜ — kapitał,
Iₜ — dopływ zewnętrzny,
bₜ — stawka,
Yₜ — wynik netto,
τ₀ = inf{t : Wₜ ≤ 0}.
```

Zbadaj ruinę dla:

```text
stałej i zmiennej stawki,
minimalnej stawki dodatniej,
stawki dążącej do zera,
strategii Kelly’ego,
Martingale,
limitów zakładów,
możliwości wyjścia,
dopływów zewnętrznych,
skończonego i nieskończonego horyzontu.
```

Agent A0 z akcją „nie uczestniczę” jest obowiązkowym benchmarkiem.

## T5 — koncentracja softmax

Dla:

```text
π(a|s) = exp(Q(s,a)/τ) / Σⱼexp(Q(s,aⱼ)/τ)
```

wyprowadź wpływ:

```text
różnic Q,
temperatury τ,
wymuszonej eksploracji,
aktualizacji wartości,
zmiany reżimu
```

na entropię polityki.

## T6 — koncentracja adaptacyjna versus błędna

Zdefiniuj statyczny i dynamiczny regret. Wykaż warunki, w których:

```text
niska entropia + niski regret = specjalizacja adaptacyjna,
niska entropia + wysoki regret = błędna koncentracja.
```

## T7 — niepełna obserwowalność i błędna aktualizacja

Rozróżnij formalnie:

```text
brak informacji,
szum,
błędny model likelihood,
nadmiernie skoncentrowany prior,
ograniczoną pamięć,
selekcję obserwacji,
brak aktualizacji,
selektywną aktualizację,
aktywną obronę wcześniejszego modelu.
```

## T8 — podstawowe twierdzenie sprzęgające

Rozdziel trzy tezy:

```text
TEZA PODSTAWOWA
Dodatnia przewaga operatora
+ dodatnia oczekiwana liczba ekspozycji
→ dodatni oczekiwany skumulowany wynik operatora.
```

```text
TEZA WZMACNIAJĄCA
Jeżeli koncentracja polityki zmniejsza prawdopodobieństwo wyjścia
albo opóźnia reakcję na zmianę,
to może zwiększać liczbę ekspozycji lub koszt pozostania.
```

```text
TEZA SPRZĘGAJĄCA
Jeżeli wzrost ekspozycji następuje w systemie
o dodatniej przewadze operatora,
to zamknięcie może zwiększać tempo kumulacji przewagi.
```

Jeżeli nie można dowieść tezy sprzęgającej w pełnej ogólności, podaj minimalny zestaw dodatkowych założeń.

---

# 11. MODELE AGENTÓW

Nie używaj nazw agentów bez specyfikacji algorytmicznej. Dla każdego agenta przygotuj dokumentację zgodną z ODD:

```text
Overview,
Design concepts,
Details.
```

Dla każdego agenta zdefiniuj:

```text
przestrzeń stanów,
przestrzeń działań,
stan pamięci,
inicjalizację,
regułę aktualizacji,
funkcję celu,
parametry uczenia,
regułę eksploracji,
regułę kontynuacji lub wyjścia,
proxy pewności,
reakcję na kontrfakt,
warunki zatrzymania.
```

## Agenci obowiązkowi

```text
A*  — oracle znający DGM i politykę optymalną,
A0  — agent odmawiający ekspozycji przy ujemnej wartości oczekiwanej,
A1  — agent losowy,
A2  — ε-greedy,
A3  — softmax,
A4  — Q-learning,
A5  — SARSA,
A6  — Thompson sampling,
A7  — poprawnie wyspecyfikowany agent model-based,
A8  — błędnie wyspecyfikowany agent model-based,
A9  — agent z ograniczoną pamięcią,
A10 — agent hybrydowy model-free/model-based,
A11 — agent metapoznawczy monitorujący kalibrację, regret i entropię,
A12 — agent z wymuszoną eksploracją,
A13 — agent reagujący na jawne kontrfakty,
A14 — agent z uczoną decyzją o kontynuacji eₜ.
```

Nie wszystkie modele muszą być uruchamiane w każdej fazie. Najpierw wykonaj rdzeń minimalny, następnie rozszerzenia zgodnie z budżetem obliczeniowym i informacją uzyskaną w screeningu.

---

# 12. MODELE OPERATORA

Zdefiniuj co najmniej:

```text
O0 — operator neutralny, bez przewagi,
O1 — operator ze stałą dodatnią przewagą,
O2 — operator maksymalizujący wynik na interakcję,
O3 — operator maksymalizujący liczbę ekspozycji,
O4 — operator adaptacyjny personalizujący bodźce,
O5 — operator selekcjonujący informacje,
O6 — operator wielokryterialny: wynik × ekspozycja × koszt,
O7 — operator zaprojektowany przeciwko teorii.
```

Dla każdego operatora zdefiniuj:

```text
funkcję celu,
zbiór dozwolonych działań,
ograniczenia,
dostęp do historii,
stopień obserwowalności agenta,
regułę aktualizacji,
koszt personalizacji,
warunki zatrzymania.
```

---

# 13. ŚRODOWISKA TESTOWE

Zbuduj rdzeń środowisk:

```text
E0 — stacjonarne, bez przewagi operatora,
E1 — stacjonarne, z małą dodatnią przewagą,
E2 — natychmiastowa nagroda i koszt odroczony,
E3 — zmiana reżimu po utrwaleniu polityki,
E4 — częściowa obserwowalność,
E5 — poprawna informacja dostępna, lecz słabo eksponowana,
E6 — jawna informacja kontrfaktyczna,
E7 — realna możliwość wyjścia,
E8 — kosztowna eksploracja,
E9 — środowisko, w którym koncentracja jest optymalna,
E10 — środowisko, w którym wszystkie akcje agenta mają ujemną wartość,
E11 — środowisko obustronnej korzyści,
E12 — środowisko z negatywnym efektem zewnętrznym,
E13 — adaptacyjny operator personalizujący ekspozycję,
E14 — środowisko adversarialne zaprojektowane przeciwko teorii.
```

Każde środowisko musi mieć jawny DGM, klasę użyteczności U1–U5 i rozwiązanie referencyjne tam, gdzie jest ono dostępne.

---

# 14. PLAN SYMULACJI: ETAPOWY I WYKONALNY

Nie wykonuj pełnego iloczynu wszystkich parametrów. Badanie ma być etapowe.

## Etap 0 — rozwiązania analityczne

Rozwiąż lub zbierz znane rozwiązania dla:

```text
procesu iid z dodatnim dryfem,
klasycznej ruiny gracza,
softmax przy stałych wartościach Q,
prostych łańcuchów Markowa,
agenta z akcją trwałego wyjścia.
```

## Etap 1 — weryfikacja implementacji

Obowiązkowe:

```text
testy jednostkowe,
testy właściwości,
testy graniczne,
testy deterministyczne przy wyłączonym szumie,
zgodność z rozwiązaniami analitycznymi,
sprawdzenie niezmienników,
mutation testing dla funkcji krytycznych.
```

Nie przechodź do screeningu, jeżeli implementacja nie odzyskuje wyników referencyjnych w ustalonej tolerancji.

## Etap 2 — screening globalny

Domyślnie zastosuj:

```text
Sobol sequence albo Latin Hypercube Sampling.
```

Punkt startowy:

```text
2048 punktów przestrzeni parametrów
```

z możliwością zwiększenia do 8192 tylko wtedy, gdy:

```text
analiza wrażliwości nie jest stabilna,
budżet obliczeniowy na to pozwala,
a kolejne punkty wnoszą nową informację.
```

Dla kosztownych agentów dopuszczalny jest mniejszy screening, ale musi zachować pokrycie przestrzeni parametrów.

## Etap 3 — eksperymenty konfirmacyjne

Na podstawie screeningu wybierz mały zbiór dominujących czynników i utwórz prerejestrowany plan konfirmacyjny, obejmujący zwykle:

```text
24–60 scenariuszy głównych,
parowane porównania agentów,
wspólne strumienie losowe dla redukcji wariancji,
adaptacyjną liczbę replikacji według MCSE.
```

## Etap 4 — zamrożony challenge set

Utwórz osobny zbiór scenariuszy:

```text
nieużywany do strojenia,
nieużywany do doboru progów,
nieużywany do wyboru agentów,
nieużywany do konstrukcji indeksu.
```

Challenge set ma pokrywać przypadki brzegowe, kontrprzykłady, rozkłady ciężkoogonowe, zależności czasowe, reguły zatrzymania, możliwość wyjścia, brak przewagi i obustronną korzyść.

## Etap 5 — walidacja zewnętrzna

Porównaj model z:

```text
rozwiązaniami analitycznymi,
niezależną implementacją modeli krytycznych,
publicznymi danymi albo opublikowanymi wzorcami empirycznymi,
wynikami z literatury niewykorzystanymi do strojenia.
```

## Horyzonty

`T=200` jest kotwicą, nie progiem biologicznym.

Zastosuj:

```text
T ∈ {20, 50, 100, 200, 500, 1000}
```

oraz wybrane eksperymenty asymptotyczne do `T=5000` wyłącznie tam, gdzie długi horyzont jest istotny dla twierdzenia M0 lub ruiny.

## Replikacje i MCSE

Nie ustalaj jednej arbitralnej liczby trajektorii dla wszystkich warunków.

Procedura:

```text
1. rozpocznij od co najmniej 128–256 niezależnych trajektorii na punkt,
2. oblicz MCSE,
3. podwajaj liczbę replikacji,
4. zakończ po osiągnięciu prerejestrowanej precyzji
   albo jawnie raportuj jej nieosiągnięcie.
```

Docelowa precyzja dla wyników głównych:

```text
dla prawdopodobieństw:
połowa szerokości 95% przedziału Monte Carlo ≤ 0,01;

dla wyników ciągłych:
MCSE ≤ 0,02 odchylenia standardowego wyniku
albo ≤ 1% ustalonej skali praktycznej;

dla efektów eksploracyjnych:
dopuszczalny próg dwa razy większy, jawnie oznaczony.
```

## Losowość

Zastosuj hierarchię strumieni RNG:

```text
master seed,
seed scenariusza,
seed replikacji,
osobne strumienie dla środowiska, agenta i operatora.
```

Użyj mechanizmu w rodzaju `SeedSequence`. Każda trajektoria ma mieć jednoznacznie odtwarzalny identyfikator. Nie mnoż „liczby ziaren” przez liczbę trajektorii jako osobnego kryterium jakości.

---

# 15. PARAMETRY SCREENINGU

Dobierz zakresy na podstawie teorii i pilotażu. Domyślnie uwzględnij:

```text
przewaga operatora μ:
0%, 0,25%, 0,5%, 1%, 2%, 5%, 10%

szum obserwacji:
0–50%

pamięć agenta:
krótka / średnia / długa / pełna

poziom eksploracji:
0–0,5

temperatura softmax:
zakres logarytmiczny

opóźnienie kosztu:
0–100 kroków

moment zmiany reżimu:
10–80% horyzontu

kapitał początkowy:
zakres logarytmiczny

udział kapitału na decyzję:
0–100%

siła priora:
słaba–bardzo silna

stopień błędnej specyfikacji modelu:
0–wysoki

koszt wyjścia:
0–wysoki

koszt eksploracji:
0–wysoki

siła personalizacji operatora:
0–wysoka.
```

Nie traktuj wszystkich parametrów jako jednakowo istotnych. Wykorzystaj analizę globalnej wrażliwości do wyboru czynników konfirmacyjnych.

---

# 16. TESTY

## 16.1. Testy bazowe

Porównaj każdy mechanizm z kontrolą:

```text
bez przewagi,
bez uczenia,
bez pamięci,
bez personalizacji,
bez selekcji informacji,
bez powtarzania ekspozycji,
z akcją „nie uczestniczę”,
z polityką oracle.
```

## 16.2. Test zmiany reżimu

Po utrwaleniu strategii zmień reguły. Mierz:

```text
dynamic regret,
liczbę błędnych decyzji,
czas adaptacji,
koszt bezwładności,
zmianę PC, CAL, CR i AD,
prawdopodobieństwo wyjścia.
```

## 16.3. Test kontrfaktyczny

Oddziel etapy:

```text
informacja została dostarczona,
informacja była obserwowalna,
informacja została zakodowana,
przekonanie zostało zaktualizowane,
polityka została zmieniona,
działanie zostało zmienione.
```

## 16.4. Test opóźnionego kosztu

Porównaj nagrodę natychmiastową z całkowitą zdyskontowaną użytecznością. Ustal, czy agent:

```text
maksymalizuje lokalny sygnał,
ignoruje koszt odroczony,
zwiększa ekspozycję,
błędnie ocenia własny wynik.
```

## 16.5. Test operatora

Porównaj operatorów O0–O7 przy zachowaniu wspólnego DGM tam, gdzie to możliwe. Rozdziel:

```text
efekt zmiany przewagi,
efekt zmiany liczby ekspozycji,
efekt selekcji pozostających agentów,
efekt personalizacji,
efekt selekcji informacji.
```

## 16.6. Test interwencji

Zbadaj:

```text
wymuszoną eksplorację,
przerwy w ekspozycji,
jawne pokazanie wartości oczekiwanej,
pokazanie skumulowanego kosztu,
informację kontrfaktyczną,
ograniczenie liczby interakcji,
audyt zewnętrzny,
drugiego niezależnego agenta,
oddzielenie nagrody od decyzji,
częściowy reset pamięci.
```

Dla każdej interwencji raportuj korzyści, szkody i heterogeniczność efektu.

## 16.7. Testy ablacyjne

Usuwaj kolejno:

```text
przewagę operatora,
decyzję o kontynuacji,
pamięć,
model świata,
nagrodę lokalną,
koszt odroczony,
kontrfakty,
metapoznanie,
możliwość wyjścia,
ograniczenie kapitału.
```

Ustal składniki:

```text
konieczne,
wystarczające,
wzmacniające,
redundantne.
```

---

# 17. ANALIZA PRZYCZYNOWA M3

Przed analizą mediacji narysuj strukturalny graf przyczynowy. Minimalnie uwzględnij:

```text
przewagę operatora μ,
lokalną nagrodę,
proxy zamknięcia,
decyzję o kontynuacji eₜ,
liczbę ekspozycji N(T),
wynik operatora Sᴼ(T),
wynik agenta Sᴬ(T),
zasoby,
szum,
personalizację,
zmianę reżimu.
```

Zdefiniuj interwencje i potencjalne wyniki. W symulacji identyfikuj efekty przez randomizację parametrów. W danych empirycznych nie szacuj efektów bez jawnych założeń identyfikacyjnych.

Oszacuj:

```text
ATE przewagi na Sᴼ,
ATE interwencji ekspozycyjnej na N(T),
ATE zamknięcia na prawdopodobieństwo wyjścia,
efekt pośredni przez N(T),
interakcję przewaga × ekspozycja,
interakcję zamknięcie × zmiana reżimu,
CATE według typu agenta i kosztu wyjścia.
```

Sprawdź, czy M2 wpływa na M0:

```text
bezpośrednio,
przez ekspozycję,
przez opóźnienie adaptacji,
czy wcale.
```

---

# 18. FALSYFIKACJA I CHALLENGE SET

Nie maksymalizuj liczby podobnych testów. Maksymalizuj pokrycie klas kontrprzykładów.

## 18.1. Klasy falsyfikacji

```text
F1 — kontrprzykłady formalne dla twierdzeń M0,
F2 — warunki, w których dodatnia wartość oczekiwana nie kumuluje się,
F3 — warunki, w których gracz nie ulega ruinie,
F4 — warunki, w których koncentracja jest optymalna,
F5 — warunki, w których zamknięcie nie zwiększa ekspozycji,
F6 — warunki, w których agent pokonuje operatora,
F7 — warunki, w których kontrfakt szybko odwraca politykę,
F8 — warunki, w których model-based przegrywa przez błędną specyfikację,
F9 — fałszywie dodatnie przypadki `CLOSE`,
F10 — fałszywie ujemne przypadki `CLOSE`,
F11 — systemy obustronnej korzyści,
F12 — operator uzyskujący korzyść bez straty agenta,
F13 — selekcja agentów tworząca pozorną przewagę,
F14 — ciężkie ogony, autokorelacja i niestacjonarność,
F15 — alternatywne wyjaśnienia empiryczne.
```

## 18.2. Macierz pokrycia

Dla challenge set utwórz tabelę:

| Test | Założenie atakowane | Typ kontrprzykładu | Agent | Operator | DGM | Wynik oczekiwany | Wynik uzyskany | Decyzja |
|---|---|---|---|---|---|---|---|---|

Wymagaj pokrycia:

```text
założeń,
przypadków brzegowych,
rodzin rozkładów,
reguł zatrzymania,
modeli pamięci,
klas operatora,
klas użyteczności,
mechanizmów alternatywnych.
```

## 18.3. Rodzaje testu

Oddzielaj:

```text
kontrprzykład formalny,
test właściwości implementacji,
stress test modelu,
test odporności,
walidację zewnętrzną,
falsyfikację empiryczną.
```

Symulacja może obalić twierdzenie uniwersalne w klasie modeli. Sama nie potwierdza ani nie obala biologii człowieka.

## 18.4. Kryterium porażki teorii

Teoria sprzężenia M3 nie przechodzi, jeżeli w prerejestrowanym challenge set:

```text
znak głównego efektu sprzęgającego jest niestabilny,
efekt zanika po kontroli liczby ekspozycji,
zamknięcie nie wpływa na wyjście ani adaptację,
wynik zależy od jednego agenta albo jednego DGM,
mosty B1–B5 nie mają wsparcia,
albo kontrprzykład narusza twierdzenie przedstawione jako uniwersalne.
```

Wtedy zawęź zakres teorii albo ją odrzuć. Każda zmiana po wynikach musi być oznaczona jako post hoc.

---

# 19. PREREJESTRACJA

Przed analizą konfirmacyjną zamroź:

```text
hipotezy,
estymandy,
wyniki główne,
progi `CLOSE`,
minimalne efekty praktyczne,
rodziny porównań,
reguły wyłączania symulacji,
reguły obsługi błędów,
plan analizy,
wersję kodu,
DGM,
challenge set,
hierarchię RNG.
```

Zapisz:

```text
datę i czas,
hash pliku prerejestracji,
hash kodu,
hash konfiguracji,
hash challenge set.
```

Wyniki oznaczaj jako:

```text
konfirmacyjne,
eksploracyjne,
post hoc.
```

---

# 20. ANALIZA STATYSTYCZNA

Nie stosuj mechanicznie wszystkich możliwych metod. Dobierz metodę do estymandu.

## Prawdopodobieństwa

Raportuj:

```text
estymatę,
przedział Wilsona albo dokładny,
MCSE,
wersję bayesowską, jeśli jest uzasadniona.
```

## Wyniki ciągłe

Raportuj:

```text
średnią,
medianę,
odchylenie,
kwantyle,
przedział niepewności,
MCSE,
wielkość efektu,
rozkład, nie tylko średnią.
```

## Czas do ruiny lub wyjścia

Zastosuj analizę przeżycia z cenzurowaniem. Raportuj:

```text
krzywe przeżycia,
medianę czasu,
hazard albo model AFT,
wpływ strategii i parametrów.
```

## Kalibracja

Raportuj pełny pakiet CAL, nie pojedynczą metrykę.

## Porównanie agentów

Stosuj parowane scenariusze i wspólne strumienie losowe. Dla wielu DGM rozważ model hierarchiczny albo model mieszany.

## Wielokrotne porównania

Zdefiniuj rodziny testów przed analizą. Stosuj odpowiednią kontrolę FWER albo FDR. Wniosku nie opieraj wyłącznie na `p`.

## Globalna wrażliwość

Oszacuj wpływ parametrów przez indeksy Sobola, analizę wariancji albo adekwatny model zastępczy. Sprawdź interakcje parametrów.

## Trzy rodzaje niepewności

Raportuj osobno:

```text
niepewność Monte Carlo,
niepewność parametrów modelu,
niepewność empiryczną i pomostową.
```

---

# 21. WERYFIKACJA, WALIDACJA I STANDARD ODD

Rozdziel:

```text
WERYFIKACJĘ:
czy kod realizuje zadeklarowany model;

WALIDACJĘ:
czy model adekwatnie odtwarza zjawisko odniesienia.
```

Dla każdego modelu agentowego przygotuj ODD.

Minimalna walidacja:

```text
V1 — zgodność z rozwiązaniem analitycznym,
V2 — niezależna implementacja modeli krytycznych,
V3 — face validity struktury modelu,
V4 — walidacja wzorców,
V5 — walidacja na danych lub wynikach niewykorzystanych do strojenia,
V6 — analiza czułości strukturalnej,
V7 — test predykcji poza zakresem rozwojowym.
```

Jeżeli walidacja zewnętrzna nie jest możliwa, oznacz trafność zewnętrzną jako „brak” albo „ograniczona”.

---

# 22. REJESTR TWIERDZEŃ

Utwórz tabelę:

| ID | Twierdzenie | Moduł | Typ | Domena | Założenia | Identyfikacja | Wynik | Odporność | Trafność zewnętrzna | Status P1–P6 | Ograniczenia |
|---|---|---|---|---|---|---|---|---|---|---|---|

Każde ważne twierdzenie musi mieć źródło, dowód, wynik symulacji albo oznaczenie braku wsparcia.

---

# 23. KRYTERIA BUDOWY TEORII

## 23.1. Moduł M0

Może wejść do twardego rdzenia, jeżeli:

```text
założenia są jawne,
dowód jest poprawny,
symulacja odzyskuje rozwiązanie,
kontrprzykłady wyznaczają granice.
```

## 23.2. Moduł M1

Może wejść do teorii, jeżeli wzrost ekspozycji jest:

```text
zidentyfikowany przyczynowo w modelu,
odporny na parametry,
niezależny od jednej implementacji,
zgodny z przynajmniej częścią danych empirycznych.
```

## 23.3. Moduł M2

Może wejść do teorii, jeżeli:

```text
wektor ZPD⃗ rozróżnia specjalizację od błędnego zamknięcia,
wynik nie opiera się wyłącznie na entropii,
regret i opóźnienie adaptacyjne są stabilne,
false positive i false negative są kontrolowane.
```

## 23.4. Moduł M3

Może wejść do teorii, jeżeli:

```text
związek ma formalną postać,
efekt sprzężenia jest potwierdzony w prerejestrowanych symulacjach,
mechanizm przez ekspozycję lub adaptację jest zidentyfikowany,
challenge set nie ujawnia uniwersalnego kontrprzykładu,
zakres obowiązywania jest jawny.
```

## 23.5. Rozszerzenie biologiczne

Może zostać sformułowane wyłącznie wtedy, gdy mosty B1–B5 mają co najmniej częściowo potwierdzoną trafność zewnętrzną. W przeciwnym razie pozostaje hipotezą P5.

---

# 24. ZAKAZY METODOLOGICZNE

Nie wolno:

```text
traktować dopaminy jako prostego synonimu przyjemności,
sprowadzać zachowania człowieka do nagrody i kary,
uznawać 200 prób za uniwersalny próg biologiczny,
twierdzić, że mózg „zamyka się na zawsze” bez operacjonalizacji,
przenosić symulacji bezpośrednio na człowieka,
używać różnic płciowych bez mocnych danych,
traktować metafor zwierzęcych jako dowodu,
uznawać spadku entropii za dowód patologii,
utożsamiać pewności z trafnością,
utożsamiać zysku operatora ze stratą agenta,
uznawać dodatniej wartości oczekiwanej za wygraną w każdej grze,
ukrywać wyników przeczących teorii,
dopasowywać progów po obejrzeniu challenge set,
fabrykować źródeł,
nazywać przeglądu systematycznym bez wykonania procedury,
przedstawiać braku dowodu jako dowodu braku efektu.
```

---

# 25. WYMAGANIA REPRODUKCYJNE

Wygeneruj repozytorium albo równoważny pakiet:

```text
/src
/tests
/configs
/results/aggregated
/results/audit_samples
/docs/ODD
/docs/preregistration.md
/docs/methodology.md
/claims/claim_registry.csv
/data/data_dictionary.md
```

Obowiązkowe pliki:

```text
README.md
pyproject.toml albo requirements.txt
plik lock zależności
config.yaml
seeds_manifest.csv
experiment_manifest.json
checksums.sha256
CHANGELOG.md
LICENSE lub informacja o licencji
Dockerfile albo pełny opis środowiska
```

Zapisz:

```text
wersję Pythona,
wersje bibliotek,
identyfikator commitu,
hierarchię RNG,
konfiguracje eksperymentów,
sumy kontrolne,
schemat danych,
log błędów,
czas wykonania każdej fazy.
```

Nie przechowuj bez potrzeby każdego kroku każdej trajektorii. Zachowaj:

```text
pełne trajektorie diagnostyczne,
wyniki końcowe wszystkich replikacji,
agregaty online,
próbki audytowe,
kod pozwalający regenerować dane.
```

---

# 26. BRAMKI DECYZYJNE BADANIA

Nie przechodź automatycznie do kolejnej fazy.

```text
G0 — definicje i estymandy są jednoznaczne;
G1 — model formalny nie zawiera oczywistej sprzeczności;
G2 — implementacja odzyskuje rozwiązania referencyjne;
G3 — screening identyfikuje stabilne czynniki;
G4 — prerejestracja jest zamrożona;
G5 — eksperymenty konfirmacyjne osiągają wymaganą MCSE;
G6 — challenge set nie obala twierdzeń uniwersalnych;
G7 — mosty empiryczne mają wystarczające wsparcie;
G8 — teoria zostaje przyjęta, zawężona albo odrzucona.
```

Jeżeli bramka nie zostanie spełniona, zakończ odpowiednią część, opisz przyczynę i nie udawaj pełnego wyniku.

---

# 27. STRUKTURA RAPORTU KOŃCOWEGO

## 1. Abstrakt

Maksymalnie 350 słów:

```text
problem,
moduły M0–M3,
metody,
najważniejsze wyniki,
poziom pewności,
werdykt.
```

## 2. Definicja metafor

Wyjaśnij ich znaczenie dopiero po przedstawieniu operacjonalizacji.

## 3. Protokół i prerejestracja

Podaj daty, hashe, wersję kodu i odstępstwa od planu.

## 4. Mapa dowodów

Przedstaw domeny D1–D7, jakość źródeł i sprzeczności.

## 5. Model formalny

Podaj równania, twierdzenia, dowody i kontrprzykłady.

## 6. ODD i modele obliczeniowe

Opisz agentów, operatorów, DGM i środowiska.

## 7. ADEMP i metody symulacyjne

Podaj estymandy, MCSE, screening i plan konfirmacyjny.

## 8. Wyniki M0

Przewaga, zbieżność, stopping i ruina.

## 9. Wyniki M1

Ekspozycja, retencja, wyjście i personalizacja.

## 10. Wyniki M2

Wektor ZPD⃗, regret, kalibracja, kontrfakty i adaptacja.

## 11. Wyniki M3

Efekty bezpośrednie, pośrednie, interakcje i warunki sprzężenia.

## 12. Challenge set i kontrprzykłady

Przedstaw wszystkie istotne porażki teorii.

## 13. Twierdzenia pomostowe

Oddziel model od biologii i rzeczywistych platform.

## 14. Rejestr twierdzeń

Użyj pełnego profilu wieloosiowego.

## 15. Ostateczna teoria

Zapisz:

```text
HIPOTEZA
↓
TEZA
↓
PRZEWÓD FORMALNY
↓
DOWODY OBLICZENIOWE
↓
DOWODY EMPIRYCZNE
↓
TWIERDZENIA POMOSTOWE
↓
WARUNKI BRZEGOWE
↓
FALSYFIKATORY
↓
WNIOSEK
```

## 16. Minimalny rdzeń

Podaj wyłącznie twierdzenia P1–P4.

## 17. Ograniczenia

Wskaż dokładnie, czego badanie nie wykazało.

## 18. Program dalszych badań

Oddziel:

```text
badania możliwe obliczeniowo,
analizy publicznych danych,
eksperymenty z ludźmi,
neuroobrazowanie,
pomiary fizjologiczne,
badania podłużne.
```

## 19. Warstwa publicystyczna

Dopiero na końcu wyjaśnij:

```text
„Kasyno wygrywa zawsze”
=
asymptotyczna struktura dodatniej przewagi,
nie zwycięstwo w każdej grze.
```

```text
„Oczy szeroko zamknięte są”
=
mechanizm, który może zwiększać czas pozostawania agenta
wewnątrz tej struktury,
jeżeli generuje regret, ogranicza aktualizację
lub opóźnia wyjście.
```

Nie używaj metafory jako dowodu.

## 20. Bibliografia

Pełna bibliografia na końcu, z DOI albo stabilnymi identyfikatorami.

---

# 28. WERDYKTY KOŃCOWE

Nadaj osobny werdykt modułom M0–M3 oraz jeden werdykt ogólny.

Dopuszczalne werdykty ogólne:

```text
A — wspólna teoria jest silnie wsparta formalnie,
    obliczeniowo, empirycznie i pomostowo;

B — istnieje warunkowa teoria formalno-obliczeniowa
    o ograniczonym zakresie i częściowym wsparciu empirycznym;

C — istnieje silny model formalny,
    lecz brakuje wystarczającego wsparcia empirycznego;

D — istnieją regularności empiryczne,
    lecz brak wspólnego mechanizmu formalnego;

E — hipoteza sprzężenia nie przeszła falsyfikacji;

F — dostępne dane i zasoby nie pozwalają
    zidentyfikować wspólnego mechanizmu;

G — M0 i M2 są dobrze potwierdzone oddzielnie,
    lecz nie wykazano, że tworzą jedną teorię M3.
```

Wybierz dokładnie jeden werdykt ogólny, ale pokaż również wyniki modułowe.

---

# 29. FORMAT OSTATECZNEGO WNIOSKU

Zakończ raport dokładnie tym układem:

```text
PEWNIKI FORMALNE:
[twierdzenia P1 wraz z założeniami]

NIEZMIENNIKI MODELU:
[twierdzenia P2]

WYNIKI ODPORNE SYMULACYJNIE:
[twierdzenia P3]

NAJSILNIEJSZE REGULARNOŚCI EMPIRYCZNE:
[twierdzenia P4]

TWIERDZENIA POMOSTOWE:
[status B1–B5]

HIPOTEZY OTWARTE:
[twierdzenia P5]

TWIERDZENIA ODRZUCONE:
[twierdzenia P6 i hipotezy sfalsyfikowane]

MODUŁ M0 — WERDYKT:
[wynik]

MODUŁ M1 — WERDYKT:
[wynik]

MODUŁ M2 — WERDYKT:
[wynik]

MODUŁ M3 — WERDYKT:
[wynik]

OSTATECZNA TEORIA:
[zwięzła postać teorii]

WARUNKI OBOWIĄZYWANIA:
[jawny zakres]

WARUNKI FALSYFIKACJI:
[obserwacje lub kontrprzykłady, które obalają teorię]

OGRANICZENIA UOGÓLNIENIA BIOLOGICZNEGO:
[jawne ograniczenia]

WERDYKT OGÓLNY:
[A, B, C, D, E, F albo G]
```

Nie kończ ogólną refleksją ani literacką puentą. Zakończ werdyktem wynikającym z dowodów, symulacji, walidacji, challenge set i mapy empirycznej.

---

# 30. HIPOTEZA ROBOCZA DO FALSYFIKACJI

Nie przyjmuj jej jako wyniku. Traktuj ją jako tezę wejściową:

```text
Dodatnia przewaga operatora nie wymaga zamknięcia agenta.

Zamknięcie agenta nie gwarantuje przewagi operatora.

Jeżeli jednak lokalne wzmocnienia zwiększają liczbę ekspozycji,
zamknięcie generuje regret albo opóźnia wyjście,
a operator zachowuje dodatnią przewagę warunkową,
to zamknięcie może zwiększać tempo kumulacji przewagi operatora.

„Kasyno wygrywa zawsze” opisuje strukturę asymptotycznej przewagi.

„Oczy szeroko zamknięte są” opisuje możliwy mechanizm
przedłużający pozostawanie agenta w tej strukturze.

Ich połączenie jest hipotezą sprzężenia M3,
a nie założonym pewnikiem.
```
