# Prerejestracja części konfirmacyjnej

Data zamrożenia: 2026-08-06 (Europe/Warsaw)

## Hipotezy główne

1. **H0/M0:** przy dodatniej warunkowej przewadze i rosnącej liczbie ekspozycji średni wynik operatora na ekspozycję zbiega do wartości dodatniej; nie oznacza to wygranej w każdej realizacji.
2. **H3:** agent odmawiający udziału przy znanej ujemnej wartości oczekiwanej ogranicza oczekiwaną stratę względem agentów kontynuujących, o ile odmowa nie ma większego kosztu.
3. **H7:** niska entropia polityki nie jest ani konieczna, ani wystarczająca dla błędnego zamknięcia.
4. **H8:** po odwróceniu reżimu sztywne polityki o wysokiej koncentracji mają większy dynamic regret i dłuższe opóźnienie adaptacji niż polityki dyskontujące historię lub korzystające z jawnego kontrfaktu.
5. **H13:** dodatnia przewaga i dodatnia liczba ekspozycji wystarczają do dodatniego oczekiwanego wyniku operatora; koncentracja polityki nie jest konieczna.
6. **H14/M3:** jeżeli mechanizm lokalnego wzmocnienia lub bezwładności zwiększa liczbę ekspozycji, przy stałej dodatniej przewadze operatora zwiększa oczekiwany skumulowany wynik operatora głównie przez kanał N(T).
7. **H15:** bez dodatniej przewagi samo zwiększenie ekspozycji nie generuje systematycznie dodatniego wyniku operatora w układzie zerowej sumy.
8. **H17:** T=200 jest kotwicą obserwacyjną, nie uniwersalnym progiem.

## Konfirmacyjny plan ekspozycji

Pełny iloczyn:

- przewaga operatora `mu ∈ {0, 0.02, 0.05}`,
- waga strat w sygnale lokalnym `loss_weight ∈ {1.0, 0.25}`,
- szybkość aktualizacji `alpha ∈ {0.20, 0.02}`,
- koszt wyjścia `exit_cost ∈ {0.0, 0.10}`.

Łącznie 24 scenariusze, 8192 niezależne trajektorie, T=500.

## Wyniki główne

- E[N(T)],
- E[S_O(T)],
- P(S_O(T)>0),
- E[S_A(T)],
- stopa wyjścia,
- średnia koncentracja polityki kontynuacji,
- reszta `E[S_O]-mu E[N]`.

## Reguły decyzji

- efekt sprzęgający M3 jest potwierdzony w modelu, jeżeli dla `mu>0` warunki zwiększające N(T) zwiększają E[S_O], a różnica jest zgodna z `mu*ΔE[N]` w granicach 3 MCSE;
- H15 jest wsparta, jeżeli przy `mu=0` bezwzględna wartość E[S_O] nie przekracza 3 MCSE mimo dużych zmian N(T);
- wynik po obejrzeniu danych, który zmienia definicję, próg lub hipotezę, jest oznaczany jako post hoc.
