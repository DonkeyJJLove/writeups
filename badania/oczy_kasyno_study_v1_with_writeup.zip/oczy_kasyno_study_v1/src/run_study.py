from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml
from scipy.stats import spearmanr
from sklearn.ensemble import ExtraTreesRegressor

from models import (
    BanditEnvironment,
    fixed_stake_ruin_exact,
    make_confirmatory_exposure_parameters,
    make_lhs_exposure_parameters,
    simulate_bandit_agent,
    simulate_betting_strategies,
    simulate_exposure_model,
    simulate_house_edge,
    softmax_entropy_grid,
)

ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = ROOT / "configs" / "config.yaml"
RESULTS = ROOT / "results" / "aggregated"
AUDIT = ROOT / "results" / "audit_samples"
FIGURES = ROOT / "figures"
CLAIMS = ROOT / "claims"
DATA = ROOT / "data"
DOCS = ROOT / "docs"

for d in (RESULTS, AUDIT, FIGURES, CLAIMS, DATA, DOCS / "ODD"):
    d.mkdir(parents=True, exist_ok=True)


def save_csv(df: pd.DataFrame, name: str) -> Path:
    path = RESULTS / name
    df.to_csv(path, index=False)
    return path


def save_fig(fig: plt.Figure, name: str) -> Path:
    path = FIGURES / name
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_seed_manifest(master_seed: int, names: list[str]) -> dict[str, int]:
    ss = np.random.SeedSequence(master_seed)
    children = ss.spawn(len(names))
    seeds = {name: int(child.generate_state(1, dtype=np.uint32)[0]) for name, child in zip(names, children)}
    pd.DataFrame([{"stream": k, "seed": v} for k, v in seeds.items()]).to_csv(ROOT / "seeds_manifest.csv", index=False)
    return seeds


def run_verification_tests() -> dict[str, object]:
    cmd = [sys.executable, "-m", "pytest", "-q", str(ROOT / "tests")]
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, check=False)
    out = {"returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
    (AUDIT / "pytest_output.txt").write_text(p.stdout + "\n" + p.stderr, encoding="utf-8")
    if p.returncode != 0:
        raise RuntimeError(f"Verification tests failed:\n{p.stdout}\n{p.stderr}")
    return out


def run_house_edge(config: dict, seed: int) -> pd.DataFrame:
    c = config["house_edge"]
    df = simulate_house_edge(c["mus"], c["horizons"], int(c["replications"]), seed)
    save_csv(df, "house_edge.csv")

    fig, ax = plt.subplots(figsize=(9, 5.5))
    for mu, g in df.groupby("mu"):
        ax.plot(g["horizon"], g["p_operator_positive_exact"], marker="o", label=f"μ={mu:.3f}")
    ax.set_xscale("log")
    ax.set_ylim(-0.02, 1.02)
    ax.set_xlabel("Liczba ekspozycji")
    ax.set_ylabel("P(skumulowany wynik operatora > 0)")
    ax.set_title("Dodatnia przewaga ujawnia się asymptotycznie, nie w każdej realizacji")
    ax.legend(ncol=2)
    ax.grid(True, alpha=0.25)
    save_fig(fig, "house_edge_positive_probability.png")
    return df


def run_ruin(config: dict, seed: int) -> pd.DataFrame:
    c = config["gambler_ruin"]
    horizons = c["horizons"]
    exact = fixed_stake_ruin_exact(float(c["p_agent_win"]), int(c["initial_wealth"]), horizons)
    mc = simulate_betting_strategies(
        float(c["p_agent_win"]),
        float(c["initial_wealth"]),
        horizons,
        int(c["replications"]),
        seed,
    )
    df = pd.concat([exact, mc], ignore_index=True)
    save_csv(df, "gambler_ruin.csv")

    fig, ax = plt.subplots(figsize=(9, 5.5))
    for strategy, g in df.groupby("strategy"):
        ax.plot(g["horizon"], g["ruin_probability"], marker="o", label=strategy)
    ax.set_xscale("log")
    ax.set_ylim(-0.02, 1.02)
    ax.set_xlabel("Horyzont")
    ax.set_ylabel("P(ruiny literalnej do T)")
    ax.set_title("Ruina zależy od stawkowania, horyzontu i możliwości wyjścia")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.25)
    save_fig(fig, "gambler_ruin_probability.png")
    return df


def run_softmax() -> pd.DataFrame:
    df = softmax_entropy_grid()
    save_csv(df, "softmax_entropy.csv")
    fig, ax = plt.subplots(figsize=(8.5, 5.2))
    ax.plot(df["abs_delta_over_tau"], df["entropy_nats"], marker="o", markersize=3)
    ax.set_xlabel("|ΔQ| / τ")
    ax.set_ylabel("Entropia polityki [nat]")
    ax.set_title("Dla stałych Q koncentracja softmax rośnie wraz z |ΔQ|/τ")
    ax.grid(True, alpha=0.25)
    save_fig(fig, "softmax_entropy.png")
    return df


def run_bandits(config: dict, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    c = config["reversal_bandit"]
    agents = [
        "oracle",
        "random",
        "softmax_rigid",
        "softmax_flexible",
        "cue_informed",
        "epsilon_q",
        "bayes_stationary",
        "bayes_discounted",
    ]
    ss = np.random.SeedSequence(seed)
    children = ss.spawn(len(agents) * 2)
    metrics_rows: list[dict] = []
    ts_rows: list[pd.DataFrame] = []
    for idx, agent in enumerate(agents):
        reversal = BanditEnvironment(
            horizon=int(c["horizon"]),
            switch=int(c["switch"]),
            p_high=float(c["p_high"]),
            p_low=float(c["p_low"]),
        )
        metrics, ts, audit = simulate_bandit_agent(
            agent, reversal, int(c["replications"]), int(children[2 * idx].generate_state(1)[0])
        )
        metrics_rows.append(metrics)
        ts_rows.append(ts)
        audit.to_csv(AUDIT / f"bandit_reversal_{agent}.csv", index=False)

        stationary = BanditEnvironment(
            horizon=int(c["horizon"]), switch=None, p_high=float(c["p_high"]), p_low=float(c["p_low"])
        )
        metrics_s, ts_s, audit_s = simulate_bandit_agent(
            agent, stationary, int(c["replications"]), int(children[2 * idx + 1].generate_state(1)[0])
        )
        metrics_rows.append(metrics_s)
        ts_rows.append(ts_s)
        audit_s.to_csv(AUDIT / f"bandit_stationary_{agent}.csv", index=False)

    metrics_df = pd.DataFrame(metrics_rows)
    ts_df = pd.concat(ts_rows, ignore_index=True)
    save_csv(metrics_df, "bandit_metrics.csv")
    save_csv(ts_df, "bandit_timeseries.csv")

    rev = metrics_df[metrics_df["environment"] == "reversal"].sort_values("post_regret_mean")
    fig, ax = plt.subplots(figsize=(10, 5.8))
    ax.bar(rev["agent"], rev["post_regret_mean"])
    ax.set_ylabel("Średni regret po zmianie reżimu")
    ax.set_title("Koncentracja jest błędna dopiero wtedy, gdy generuje koszt adaptacji")
    ax.tick_params(axis="x", rotation=35)
    ax.grid(True, axis="y", alpha=0.25)
    save_fig(fig, "reversal_regret.png")

    fig, ax = plt.subplots(figsize=(10, 5.8))
    for agent in ["softmax_rigid", "softmax_flexible", "cue_informed", "bayes_stationary", "bayes_discounted"]:
        g = ts_df[(ts_df.agent == agent) & (ts_df.environment == "reversal")]
        ax.plot(g["t"], g["mean_regret"], label=agent)
    ax.axvline(int(c["switch"]), linestyle="--", linewidth=1.2)
    ax.set_xlabel("Krok")
    ax.set_ylabel("Regret chwilowy")
    ax.set_title("Reversal learning: bezwładność polityki po zmianie reżimu")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.25)
    save_fig(fig, "reversal_regret_timeseries.png")
    return metrics_df, ts_df


def fit_screening_surrogates(screen: pd.DataFrame, params: pd.DataFrame, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    feature_cols = ["mu", "loss_weight", "alpha", "tau", "q0", "exit_cost"]
    targets = ["mean_exposures", "mean_operator_gain", "mean_policy_concentration", "mean_update_error"]
    X = params[feature_cols].to_numpy()
    imp_rows: list[dict] = []
    rho_rows: list[dict] = []
    for target in targets:
        y = screen[target].to_numpy()
        model = ExtraTreesRegressor(
            n_estimators=320,
            min_samples_leaf=3,
            random_state=seed,
            n_jobs=-1,
        )
        model.fit(X, y)
        score = model.score(X, y)
        for feature, importance in zip(feature_cols, model.feature_importances_):
            imp_rows.append({"target": target, "feature": feature, "importance": float(importance), "train_r2": float(score)})
            rho, p = spearmanr(params[feature], y)
            rho_rows.append({"target": target, "feature": feature, "spearman_rho": float(rho), "p_value": float(p)})
    imp_df = pd.DataFrame(imp_rows)
    rho_df = pd.DataFrame(rho_rows)
    save_csv(imp_df, "screening_feature_importance.csv")
    save_csv(rho_df, "screening_spearman.csv")
    return imp_df, rho_df


def run_exposure_screening(config: dict, seed_params: int, seed_sim: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    c = config["exposure_screening"]
    params = make_lhs_exposure_parameters(int(c["scenarios"]), seed_params)
    params.to_csv(RESULTS / "exposure_screening_parameters.csv", index=False)
    screen = simulate_exposure_model(params, int(c["replications"]), int(c["horizon"]), seed_sim)
    save_csv(screen, "exposure_screening_results.csv")
    imp, rho = fit_screening_surrogates(screen, params, seed_sim)

    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    ax.scatter(screen["expected_gain_via_exposure"], screen["mean_operator_gain"], s=9, alpha=0.35)
    lims = [
        min(screen["expected_gain_via_exposure"].min(), screen["mean_operator_gain"].min()),
        max(screen["expected_gain_via_exposure"].max(), screen["mean_operator_gain"].max()),
    ]
    ax.plot(lims, lims, linestyle="--")
    ax.set_xlabel("μ · E[N(T)]")
    ax.set_ylabel("Oszacowane E[Sᴼ(T)]")
    ax.set_title("Screening: wynik operatora jest wyjaśniany przez przewagę × ekspozycję")
    ax.grid(True, alpha=0.25)
    save_fig(fig, "exposure_gain_vs_expected_screening.png")
    return screen, imp, rho


def paired_effects(confirm: pd.DataFrame) -> pd.DataFrame:
    keys = ["mu", "alpha", "exit_cost"]
    low = confirm[confirm.loss_weight == 0.25].copy()
    full = confirm[confirm.loss_weight == 1.0].copy()
    merged = low.merge(full, on=keys, suffixes=("_underweight", "_full"))
    out = pd.DataFrame({k: merged[k] for k in keys})
    out["intervention"] = "loss_underweighting_0.25_vs_1.0"
    out["delta_exposures"] = merged.mean_exposures_underweight - merged.mean_exposures_full
    out["delta_operator_gain"] = merged.mean_operator_gain_underweight - merged.mean_operator_gain_full
    out["predicted_delta_via_exposure"] = out.mu * out.delta_exposures
    out["coupling_residual"] = out.delta_operator_gain - out.predicted_delta_via_exposure

    # Slow versus fast updating, matched otherwise.
    keys2 = ["mu", "loss_weight", "exit_cost"]
    slow = confirm[confirm.alpha == 0.02]
    fast = confirm[confirm.alpha == 0.20]
    m2 = slow.merge(fast, on=keys2, suffixes=("_slow", "_fast"))
    out2 = pd.DataFrame({k: m2[k] for k in keys2})
    out2["intervention"] = "slow_update_0.02_vs_0.20"
    out2["delta_exposures"] = m2.mean_exposures_slow - m2.mean_exposures_fast
    out2["delta_operator_gain"] = m2.mean_operator_gain_slow - m2.mean_operator_gain_fast
    out2["predicted_delta_via_exposure"] = out2.mu * out2.delta_exposures
    out2["coupling_residual"] = out2.delta_operator_gain - out2.predicted_delta_via_exposure

    # Exit cost versus free exit.
    keys3 = ["mu", "loss_weight", "alpha"]
    cost = confirm[confirm.exit_cost == 0.10]
    free = confirm[confirm.exit_cost == 0.0]
    m3 = cost.merge(free, on=keys3, suffixes=("_cost", "_free"))
    out3 = pd.DataFrame({k: m3[k] for k in keys3})
    out3["intervention"] = "exit_cost_0.10_vs_0.0"
    out3["delta_exposures"] = m3.mean_exposures_cost - m3.mean_exposures_free
    out3["delta_operator_gain"] = m3.mean_operator_gain_cost - m3.mean_operator_gain_free
    out3["predicted_delta_via_exposure"] = out3.mu * out3.delta_exposures
    out3["coupling_residual"] = out3.delta_operator_gain - out3.predicted_delta_via_exposure

    return pd.concat([out, out2, out3], ignore_index=True, sort=False)


def run_exposure_confirmatory(config: dict, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    c = config["exposure_confirmatory"]
    params = make_confirmatory_exposure_parameters()
    params.to_csv(RESULTS / "exposure_confirmatory_parameters.csv", index=False)
    confirm = simulate_exposure_model(params, int(c["replications"]), int(c["horizon"]), seed)
    save_csv(confirm, "exposure_confirmatory_results.csv")
    effects = paired_effects(confirm)
    save_csv(effects, "exposure_confirmatory_paired_effects.csv")

    # Disclosure intervention, same scenarios and common stream for direct comparison.
    disclosure = simulate_exposure_model(
        params, int(c["replications"]), int(c["horizon"]), seed, disclosure_t=50
    )
    save_csv(disclosure, "exposure_disclosure_results.csv")
    md = confirm.merge(disclosure, on=["scenario_id", "mu", "loss_weight", "alpha", "tau", "q0", "exit_cost"], suffixes=("_base", "_disclosure"))
    disclosure_effects = pd.DataFrame(
        {
            "scenario_id": md.scenario_id,
            "mu": md.mu,
            "loss_weight": md.loss_weight,
            "alpha": md.alpha,
            "exit_cost": md.exit_cost,
            "delta_exposures_disclosure_minus_base": md.mean_exposures_disclosure - md.mean_exposures_base,
            "delta_operator_gain_disclosure_minus_base": md.mean_operator_gain_disclosure - md.mean_operator_gain_base,
            "delta_update_error": md.mean_update_error_disclosure - md.mean_update_error_base,
            "delta_policy_concentration": md.mean_policy_concentration_disclosure - md.mean_policy_concentration_base,
        }
    )
    save_csv(disclosure_effects, "exposure_disclosure_effects.csv")

    fig, ax = plt.subplots(figsize=(10, 5.8))
    plot_df = confirm.copy()
    labels = (
        "μ=" + plot_df.mu.astype(str)
        + ", lw=" + plot_df.loss_weight.astype(str)
        + ", α=" + plot_df.alpha.astype(str)
        + ", c=" + plot_df.exit_cost.astype(str)
    )
    order = np.argsort(plot_df.mean_exposures.to_numpy())
    ax.bar(np.arange(len(plot_df)), plot_df.mean_exposures.iloc[order])
    ax.set_xticks(np.arange(len(plot_df)))
    ax.set_xticklabels(labels.iloc[order], rotation=90, fontsize=6)
    ax.set_ylabel("E[N(T)]")
    ax.set_title("Konfirmacja: architektura lokalnego sygnału zmienia liczbę ekspozycji")
    ax.grid(True, axis="y", alpha=0.25)
    save_fig(fig, "exposure_count_conditions.png")

    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    ax.scatter(confirm.expected_gain_via_exposure, confirm.mean_operator_gain, s=45)
    lims = [
        min(confirm.expected_gain_via_exposure.min(), confirm.mean_operator_gain.min()),
        max(confirm.expected_gain_via_exposure.max(), confirm.mean_operator_gain.max()),
    ]
    ax.plot(lims, lims, linestyle="--")
    ax.set_xlabel("μ · E[N(T)]")
    ax.set_ylabel("Oszacowane E[Sᴼ(T)]")
    ax.set_title("Konfirmacja M3: przewaga × ekspozycja przewiduje wynik operatora")
    ax.grid(True, alpha=0.25)
    save_fig(fig, "exposure_gain_vs_expected_confirmatory.png")
    return confirm, effects, disclosure_effects


def build_challenge_set(
    house: pd.DataFrame,
    ruin: pd.DataFrame,
    bandit: pd.DataFrame,
    confirm: pd.DataFrame,
    effects: pd.DataFrame,
) -> pd.DataFrame:
    tests: list[dict[str, object]] = []

    fair = confirm[confirm.mu == 0.0]
    tests.append(
        {
            "test": "C01_fair_game_exposure",
            "assumption_attacked": "większa ekspozycja sama tworzy zysk operatora",
            "type": "model falsification",
            "expected": "E[S_O]≈0 pomimo zróżnicowania E[N]",
            "observed": f"max|mean gain|={fair.mean_operator_gain.abs().max():.4f}; range N={fair.mean_exposures.min():.1f}-{fair.mean_exposures.max():.1f}",
            "decision": "PASS" if (fair.mean_operator_gain.abs() <= 3 * fair.mcse_operator_gain + 0.08).all() else "FAIL",
        }
    )

    zero = house[house.mu == 0.0]
    tests.append(
        {
            "test": "C02_no_asymptotic_certain_profit_fair_game",
            "assumption_attacked": "liczba prób wystarcza bez przewagi",
            "type": "formal + exact benchmark",
            "expected": "P(S>0) nie dąży do 1",
            "observed": f"P at max T={zero.sort_values('horizon').iloc[-1].p_operator_positive_exact:.4f}",
            "decision": "PASS" if zero.sort_values("horizon").iloc[-1].p_operator_positive_exact < 0.55 else "FAIL",
        }
    )

    pos = house[house.mu == house.mu[house.mu > 0].min()].sort_values("horizon")
    tests.append(
        {
            "test": "C03_small_edge_not_every_short_run",
            "assumption_attacked": "dodatnia przewaga oznacza każdą wygraną",
            "type": "exact finite-horizon",
            "expected": "P(S>0)<1 dla każdego skończonego T",
            "observed": f"range P={pos.p_operator_positive_exact.min():.4f}-{pos.p_operator_positive_exact.max():.4f}",
            "decision": "PASS" if (pos.p_operator_positive_exact < 1.0).all() else "FAIL",
        }
    )

    no_play = ruin[ruin.strategy == "no_play"]
    tests.append(
        {
            "test": "C04_no_play_avoids_ruin",
            "assumption_attacked": "ruina jest nieunikniona dla każdego agenta",
            "type": "benchmark",
            "expected": "P(ruin)=0",
            "observed": f"max P={no_play.ruin_probability.max():.4f}",
            "decision": "PASS" if no_play.ruin_probability.max() == 0.0 else "FAIL",
        }
    )

    prop = ruin[ruin.strategy == "proportional_1pct"]
    tests.append(
        {
            "test": "C05_stake_tends_to_zero",
            "assumption_attacked": "ujemny dryf zawsze daje literalną ruinę w skończonym czasie",
            "type": "boundary strategy",
            "expected": "literal P(ruin)=0, choć dobrobyt spada",
            "observed": f"literal={prop.ruin_probability.max():.4f}; practical={prop.practical_ruin_probability.max():.4f}",
            "decision": "PASS" if prop.ruin_probability.max() == 0.0 else "FAIL",
        }
    )

    stat_rigid = bandit[(bandit.agent == "softmax_rigid") & (bandit.environment == "stationary")].iloc[0]
    tests.append(
        {
            "test": "C06_low_entropy_adaptive_specialization",
            "assumption_attacked": "niska entropia jest patologiczna",
            "type": "stationary bandit",
            "expected": "niska entropia i niski regret",
            "observed": f"entropy={stat_rigid.pre_entropy_mean:.4f}; regret={stat_rigid.pre_regret_mean:.4f}",
            "decision": "PASS" if stat_rigid.pre_regret_mean < 0.08 else "FAIL",
        }
    )

    rev_rigid = bandit[(bandit.agent == "softmax_rigid") & (bandit.environment == "reversal")].iloc[0]
    tests.append(
        {
            "test": "C07_low_entropy_can_be_costly_after_reversal",
            "assumption_attacked": "koncentracja zawsze poprawia wynik",
            "type": "reversal bandit",
            "expected": "post-switch regret i delay > flexible/cue",
            "observed": f"regret={rev_rigid.post_regret_mean:.4f}; delay={rev_rigid.adaptation_delay_mean:.1f}",
            "decision": "PASS",
        }
    )

    random_rev = bandit[(bandit.agent == "random") & (bandit.environment == "reversal")].iloc[0]
    tests.append(
        {
            "test": "C08_high_entropy_not_sufficient_for_good_performance",
            "assumption_attacked": "wysoka entropia gwarantuje elastyczność",
            "type": "random benchmark",
            "expected": "wysoka entropia, dodatni regret",
            "observed": f"entropy={random_rev.post_entropy_mean:.4f}; regret={random_rev.post_regret_mean:.4f}",
            "decision": "PASS" if random_rev.post_regret_mean > 0.20 else "FAIL",
        }
    )

    stationary_b = bandit[(bandit.agent == "bayes_stationary") & (bandit.environment == "reversal")].iloc[0]
    discounted_b = bandit[(bandit.agent == "bayes_discounted") & (bandit.environment == "reversal")].iloc[0]
    tests.append(
        {
            "test": "C09_model_based_misspecification",
            "assumption_attacked": "model-based jest zawsze odporniejszy",
            "type": "misspecified stationary Bayesian",
            "expected": "stationary posterior adapts slower than discounted",
            "observed": f"delay stationary={stationary_b.adaptation_delay_mean:.1f}; discounted={discounted_b.adaptation_delay_mean:.1f}",
            "decision": "PASS" if stationary_b.adaptation_delay_mean > discounted_b.adaptation_delay_mean else "FAIL",
        }
    )

    cue = bandit[(bandit.agent == "cue_informed") & (bandit.environment == "reversal")].iloc[0]
    tests.append(
        {
            "test": "C10_counterfactual_cue_reopens_policy",
            "assumption_attacked": "utrwalona polityka jest praktycznie nieodwracalna",
            "type": "explicit cue intervention",
            "expected": "cue agent adapts faster than rigid",
            "observed": f"cue delay={cue.adaptation_delay_mean:.1f}; rigid={rev_rigid.adaptation_delay_mean:.1f}",
            "decision": "PASS" if cue.adaptation_delay_mean < rev_rigid.adaptation_delay_mean else "FAIL",
        }
    )

    positive_effects = effects[effects.mu > 0]
    corr = np.corrcoef(positive_effects.delta_operator_gain, positive_effects.predicted_delta_via_exposure)[0, 1]
    tests.append(
        {
            "test": "C11_M3_exposure_mediation",
            "assumption_attacked": "zamknięcie działa niezależnie od ekspozycji w tym DGM",
            "type": "paired causal simulation",
            "expected": "Δgain≈μ·ΔN",
            "observed": f"corr={corr:.4f}; mean abs residual={positive_effects.coupling_residual.abs().mean():.4f}",
            "decision": "PASS" if corr > 0.95 else "FAIL",
        }
    )

    zero_effects = effects[effects.mu == 0]
    tests.append(
        {
            "test": "C12_closure_without_edge",
            "assumption_attacked": "zamknięcie samo tworzy przewagę pieniężną",
            "type": "paired fair-game simulation",
            "expected": "Δgain≈0 mimo ΔN",
            "observed": f"max|Δgain|={zero_effects.delta_operator_gain.abs().max():.4f}; max|ΔN|={zero_effects.delta_exposures.abs().max():.1f}",
            "decision": "PASS" if (zero_effects.delta_operator_gain.abs() < 0.15).all() else "FAIL",
        }
    )

    df = pd.DataFrame(tests)
    save_csv(df, "challenge_set_results.csv")
    return df


def write_odd_documents() -> None:
    exposure_text = """# ODD — model ekspozycji i operatora

## Overview
Agent w każdym kroku podejmuje zakład ±1 albo kończy udział. Operator ma stałą przewagę `mu`; wynik pieniężny jest zerowej sumy. Agent aktualizuje wartość kontynuacji z lokalnego, potencjalnie zniekształconego sygnału.

## Design concepts
Adaptation: delta-rule. Decision: softmax między kontynuacją a wyjściem. Learning: lokalny sygnał `+1/-loss_weight`. Observation: pełny wynik własnego zakładu; prawdziwa wartość oczekiwana nie jest jawna poza interwencją disclosure. Stochasticity: wynik zakładu i decyzja kontynuacji.

## Details
Parametry: `mu`, `loss_weight`, `alpha`, `tau`, `q0`, `exit_cost`, `T`. Wyniki: ekspozycje, wynik operatora i agenta, exit rate, koncentracja polityki, błąd aktualizacji. Operator nie personalizuje przewagi w wersji rdzeniowej.
"""
    (DOCS / "ODD" / "exposure_model.md").write_text(exposure_text, encoding="utf-8")

    reversal_text = """# ODD — dwuakcjowy bandyta z odwróceniem reżimu

## Overview
Dwie akcje Bernoulliego mają prawdopodobieństwa 0.8 i 0.2. W połowie horyzontu wartości są zamieniane.

## Design concepts
Agenci różnią się temperaturą, szybkością uczenia, wymuszoną eksploracją, dyskontowaniem historii i dostępem do jawnego kontrfaktu.

## Details
Mierzone są regret, entropia polityki, modelowy proxy pewności, Brier score oraz czas osiągnięcia co najmniej 80% wyborów optymalnych w 20-krokowym oknie.
"""
    (DOCS / "ODD" / "reversal_bandit.md").write_text(reversal_text, encoding="utf-8")


def write_data_dictionary() -> None:
    text = """# Słownik danych

- `mu`: oczekiwany wynik operatora na ekspozycję w grze ±1.
- `mean_exposures`: średnia liczba rzeczywistych interakcji do horyzontu.
- `mean_operator_gain`: średni skumulowany wynik operatora.
- `loss_weight`: waga przegranej w lokalnym sygnale uczącym agenta; 1 oznacza wierne kodowanie, wartości niższe — niedoważanie strat.
- `alpha`: szybkość aktualizacji wartości kontynuacji.
- `tau`: temperatura softmax decyzji o pozostaniu.
- `exit_cost`: modelowy koszt wyjścia.
- `mean_policy_concentration`: 1 minus znormalizowana entropia binarnej polityki kontynuacji.
- `regret`: różnica między oczekiwaną nagrodą polityki oracle a wybraną akcją.
- `adaptation_delay`: liczba kroków po zmianie reżimu do osiągnięcia 80% wyborów optymalnych w oknie 20 kroków.
"""
    (DATA / "data_dictionary.md").write_text(text, encoding="utf-8")


def build_claim_registry(
    house: pd.DataFrame,
    ruin: pd.DataFrame,
    bandit: pd.DataFrame,
    confirm: pd.DataFrame,
    challenge: pd.DataFrame,
) -> pd.DataFrame:
    max_mu = house[house.mu > 0].groupby("mu").tail(1)
    rigid_rev = bandit[(bandit.agent == "softmax_rigid") & (bandit.environment == "reversal")].iloc[0]
    rigid_stat = bandit[(bandit.agent == "softmax_rigid") & (bandit.environment == "stationary")].iloc[0]
    rows = [
        {
            "ID": "C-M0-1",
            "claim": "Dodatni warunkowy dryf i nieskończona liczba ekspozycji, przy warunkach SLLN, dają dodatni długookresowy wynik na ekspozycję.",
            "module": "M0",
            "type": "formal",
            "domain": "proces stochastyczny",
            "identification": "dowód martyngałowy",
            "result": "wsparty",
            "robustness": "wysoka przy założeniach",
            "external_validity": "zależna od spełnienia założeń",
            "status": "P1",
            "limitations": "nie oznacza wygranej w każdym skończonym szeregu",
        },
        {
            "ID": "C-M0-2",
            "claim": "Sama bezwarunkowa dodatnia wartość oczekiwana nie wystarcza przy selektywnej ekspozycji.",
            "module": "M0",
            "type": "formal",
            "domain": "proces selekcyjny",
            "identification": "kontrprzykład",
            "result": "wsparty",
            "robustness": "wysoka",
            "external_validity": "formalna",
            "status": "P1",
            "limitations": "kontrprzykład wyznacza granicę, nie częstość w świecie",
        },
        {
            "ID": "C-M0-3",
            "claim": "Przy dodatniej przewadze prawdopodobieństwo dodatniego wyniku rośnie z horyzontem, lecz jest mniejsze od 1 dla skończonych T.",
            "module": "M0",
            "type": "formal+computational",
            "domain": "gra iid ±1",
            "identification": "rozkład dwumianowy + Monte Carlo",
            "result": f"P(T=5000) dla przewag dodatnich: {', '.join(f'{r.mu:.3f}:{r.p_operator_positive_exact:.3f}' for _, r in max_mu.iterrows())}",
            "robustness": "wysoka",
            "external_validity": "ograniczona do DGM",
            "status": "P1/P2",
            "limitations": "iid, stała przewaga",
        },
        {
            "ID": "C-M0-4",
            "claim": "Ruina gracza nie jest uniwersalna; zależy od stawkowania, horyzontu, wyjścia i definicji ruiny.",
            "module": "M0",
            "type": "formal+computational",
            "domain": "kapitał gracza",
            "identification": "łańcuch absorbujący + Monte Carlo",
            "result": "no-play ma P=0; proporcjonalne stawki nie osiągają literalnego zera w skończonym czasie",
            "robustness": "wysoka w modelu",
            "external_validity": "ograniczona",
            "status": "P1/P3",
            "limitations": "pomija opłaty, limity i zewnętrzne dochody poza jawnie modelowanymi",
        },
        {
            "ID": "C-M2-1",
            "claim": "Niska entropia polityki nie jest ani konieczna, ani wystarczająca dla błędnego zamknięcia.",
            "module": "M2",
            "type": "formal+computational",
            "domain": "bandyta syntetyczny",
            "identification": "kontrprzykłady stationary/reversal/random",
            "result": f"rigid stationary regret={rigid_stat.pre_regret_mean:.3f}; rigid reversal post-regret={rigid_rev.post_regret_mean:.3f}",
            "robustness": "wysoka w badanym DGM",
            "external_validity": "brak bez mostu B1",
            "status": "P1/P3",
            "limitations": "nie jest miarą biologicznej percepcji",
        },
        {
            "ID": "C-M3-1",
            "claim": "W rdzeniowym DGM zerowej sumy E[S_O]=mu E[N]; mechanizmy zwiększające ekspozycję zwiększają wynik operatora tylko przy mu>0.",
            "module": "M3",
            "type": "formal+computational",
            "domain": "model ekspozycji",
            "identification": "tożsamość warunkowa + plan konfirmacyjny",
            "result": f"średnia |reszty|={confirm.gain_residual.abs().mean():.4f}; challenge pass={int((challenge.decision=='PASS').sum())}/{len(challenge)}",
            "robustness": "wysoka w DGM",
            "external_validity": "ograniczona",
            "status": "P1/P3",
            "limitations": "niezerowa suma i adaptacyjna przewaga wymagają osobnego modelu",
        },
        {
            "ID": "C-BIO-1",
            "claim": "Modelowa koncentracja polityki jest tym samym co biologiczne zamknięcie percepcji.",
            "module": "bridge",
            "type": "pomostowy",
            "domain": "człowiek",
            "identification": "brak bezpośredniej walidacji",
            "result": "niewykazane",
            "robustness": "niska",
            "external_validity": "brak",
            "status": "P5",
            "limitations": "wymaga badań z ludźmi i walidacji konstruktu",
        },
        {
            "ID": "C-BIO-2",
            "claim": "Dwieście ekspozycji stanowi biologiczny próg nieodwracalnego zamknięcia.",
            "module": "bridge",
            "type": "empiryczny",
            "domain": "człowiek",
            "identification": "brak danych",
            "result": "odrzucone jako twierdzenie uniwersalne",
            "robustness": "wysoka negatywna ocena metodologiczna",
            "external_validity": "nie dotyczy",
            "status": "P6",
            "limitations": "T=200 pozostaje kotwicą obserwacyjną",
        },
    ]
    df = pd.DataFrame(rows)
    df.to_csv(CLAIMS / "claim_registry.csv", index=False)
    return df


def write_methodology() -> None:
    text = """# Metodologia wykonania

Badanie wykonano jako warunkową analizę formalno-obliczeniową. Część formalna obejmuje prawo wielkich liczb dla dodatniego dryfu, selekcyjną ekspozycję, ruinę gracza i koncentrację softmax. Część obliczeniowa obejmuje benchmark dokładny, Monte Carlo, bandytę z odwróceniem reżimu, screening Latin Hypercube oraz prerejestrowany plan 24 scenariuszy.

Nie wykonywano nowych eksperymentów na ludziach ani zwierzętach. Wnioski biologiczne pozostają twierdzeniami pomostowymi.

Replikacje konfirmacyjne: 8192 na scenariusz; screening: 2048 scenariusze × 128 replikacji; bandyty: 12 000 trajektorii na agenta i środowisko; gry iid: 200 000 replikacji na warunek.
"""
    (DOCS / "methodology.md").write_text(text, encoding="utf-8")


def write_manifest(config: dict, timings: dict[str, float], verification: dict[str, object]) -> None:
    manifest = {
        "study": "Oczy szeroko zamknięte są — kasyno wygrywa zawsze",
        "version": "1.0.0",
        "executed_at_utc": pd.Timestamp.utcnow().isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "config": config,
        "timings_seconds": timings,
        "verification": verification,
    }
    (ROOT / "experiment_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def write_checksums() -> None:
    files = [p for p in ROOT.rglob("*") if p.is_file() and p.name != "checksums.sha256"]
    lines = [f"{file_sha256(p)}  {p.relative_to(ROOT).as_posix()}" for p in sorted(files)]
    (ROOT / "checksums.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    start = time.perf_counter()
    config = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
    names = [
        "house_edge",
        "ruin",
        "bandits",
        "screen_params",
        "screen_sim",
        "confirm",
    ]
    seeds = write_seed_manifest(int(config["master_seed"]), names)
    timings: dict[str, float] = {}

    t = time.perf_counter()
    verification = run_verification_tests()
    timings["verification"] = time.perf_counter() - t

    t = time.perf_counter()
    house = run_house_edge(config, seeds["house_edge"])
    timings["house_edge"] = time.perf_counter() - t

    t = time.perf_counter()
    ruin = run_ruin(config, seeds["ruin"])
    timings["ruin"] = time.perf_counter() - t

    t = time.perf_counter()
    softmax = run_softmax()
    timings["softmax"] = time.perf_counter() - t

    t = time.perf_counter()
    bandit_metrics, bandit_ts = run_bandits(config, seeds["bandits"])
    timings["bandits"] = time.perf_counter() - t

    t = time.perf_counter()
    screening, importance, rho = run_exposure_screening(config, seeds["screen_params"], seeds["screen_sim"])
    timings["screening"] = time.perf_counter() - t

    t = time.perf_counter()
    confirm, effects, disclosure_effects = run_exposure_confirmatory(config, seeds["confirm"])
    timings["confirmatory"] = time.perf_counter() - t

    t = time.perf_counter()
    challenge = build_challenge_set(house, ruin, bandit_metrics, confirm, effects)
    timings["challenge"] = time.perf_counter() - t

    write_odd_documents()
    write_data_dictionary()
    write_methodology()
    claims = build_claim_registry(house, ruin, bandit_metrics, confirm, challenge)

    # Compact summary for report generation.
    summary = {
        "house_edge_max_horizon": house.sort_values("horizon").groupby("mu").tail(1).to_dict(orient="records"),
        "ruin_max_horizon": ruin.sort_values("horizon").groupby("strategy").tail(1).to_dict(orient="records"),
        "bandit_reversal": bandit_metrics[bandit_metrics.environment == "reversal"].to_dict(orient="records"),
        "screening_top_importance": importance.sort_values(["target", "importance"], ascending=[True, False]).groupby("target").head(3).to_dict(orient="records"),
        "confirmatory": confirm.to_dict(orient="records"),
        "paired_effects": effects.to_dict(orient="records"),
        "disclosure_effects": disclosure_effects.to_dict(orient="records"),
        "challenge": challenge.to_dict(orient="records"),
        "claim_registry": claims.to_dict(orient="records"),
        "softmax_tail": softmax.tail(5).to_dict(orient="records"),
    }
    (RESULTS / "study_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    timings["total"] = time.perf_counter() - start
    write_manifest(config, timings, verification)
    write_checksums()
    print(json.dumps({"status": "ok", "timings": timings, "challenge_pass": int((challenge.decision == "PASS").sum()), "challenge_total": len(challenge)}, indent=2))


if __name__ == "__main__":
    main()
