from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from models import simulate_exposure_model

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results' / 'aggregated'

# Eight matched negative-edge scenarios: the operator loses 2% per exposure in expectation.
rows = []
sid = 1000
for loss_weight in (1.0, 0.25):
    for alpha in (0.20, 0.02):
        for exit_cost in (0.0, 0.10):
            rows.append({
                'scenario_id': sid,
                'mu': -0.02,
                'loss_weight': loss_weight,
                'alpha': alpha,
                'tau': 0.05,
                'q0': 0.30,
                'exit_cost': exit_cost,
            })
            sid += 1
params = pd.DataFrame(rows)
neg = simulate_exposure_model(params, n_rep=32768, horizon=500, seed=2026080602)
neg.to_csv(RESULTS / 'negative_edge_challenge.csv', index=False)

# Utility-class counterexamples based on observed fair-game exposure counts.
fair = pd.read_csv(RESULTS / 'fair_game_adjudication_scenarios.csv')
utility_rows = []
for _, r in fair.iterrows():
    n = float(r.mean_exposures)
    utility_rows.extend([
        {
            'scenario_id': int(r.scenario_id),
            'class': 'U3_mutual_benefit',
            'mean_exposures': n,
            'operator_money_expectation': 0.0,
            'agent_money_expectation': 0.0,
            'operator_nonmonetary_value_per_exposure': 0.01,
            'agent_nonmonetary_value_per_exposure': 0.02,
            'operator_total_utility': 0.01 * n,
            'agent_total_utility': 0.02 * n,
            'interpretation': 'obie strony uzyskują dodatnią użyteczność mimo braku transferu pieniężnego',
        },
        {
            'scenario_id': int(r.scenario_id),
            'class': 'U5_operator_attention_value',
            'mean_exposures': n,
            'operator_money_expectation': 0.0,
            'agent_money_expectation': 0.0,
            'operator_nonmonetary_value_per_exposure': 0.01,
            'agent_nonmonetary_value_per_exposure': 0.0,
            'operator_total_utility': 0.01 * n,
            'agent_total_utility': 0.0,
            'interpretation': 'operator może zyskiwać uwagę bez wykazanej straty agenta',
        },
    ])
utility = pd.DataFrame(utility_rows)
utility.to_csv(RESULTS / 'utility_class_counterexamples.csv', index=False)

summary = {
    'negative_edge_all_mean_operator_gain_negative': bool((neg.mean_operator_gain < 0).all()),
    'negative_edge_min_exposures': float(neg.mean_exposures.min()),
    'negative_edge_max_exposures': float(neg.mean_exposures.max()),
    'negative_edge_min_operator_gain': float(neg.mean_operator_gain.min()),
    'negative_edge_max_operator_gain': float(neg.mean_operator_gain.max()),
    'negative_edge_mean_abs_identity_residual': float(neg.gain_residual.abs().mean()),
    'mutual_benefit_all_both_positive': bool(((utility[utility['class']=='U3_mutual_benefit'].operator_total_utility > 0) & (utility[utility['class']=='U3_mutual_benefit'].agent_total_utility > 0)).all()),
}
(RESULTS / 'supplemental_challenge_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
