from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binom

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results" / "aggregated"
LITERATURE = ROOT / "literature"
CLAIMS = ROOT / "claims"
DOCS = ROOT / "docs"
LITERATURE.mkdir(exist_ok=True)
CLAIMS.mkdir(exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def fmt(x: float, n: int = 4) -> str:
    if pd.isna(x):
        return "—"
    return f"{x:.{n}f}"


def md_table(df: pd.DataFrame, floatfmt: str = ".4f") -> str:
    return df.to_markdown(index=False, floatfmt=floatfmt)


def min_odd_horizon(mu: float, target: float) -> int:
    p = (1.0 + mu) / 2.0
    if mu <= 0:
        raise ValueError("mu must be positive")

    def prob(n: int) -> float:
        # n is odd, therefore no tie; positive total means wins >= (n+1)/2.
        return float(binom.sf(n // 2, n, p))

    lo, hi = 1, 1
    while prob(hi) < target:
        hi = 2 * hi + 1
    # binary search over odd n = 2k+1
    lo_k, hi_k = 0, (hi - 1) // 2
    while lo_k < hi_k:
        mid = (lo_k + hi_k) // 2
        n = 2 * mid + 1
        if prob(n) >= target:
            hi_k = mid
        else:
            lo_k = mid + 1
    return 2 * lo_k + 1


def create_thresholds() -> pd.DataFrame:
    rows = []
    for mu in (0.005, 0.01, 0.02, 0.05):
        for target in (0.90, 0.95, 0.99):
            n = min_odd_horizon(mu, target)
            p = (1 + mu) / 2
            exact = float(binom.sf(n // 2, n, p))
            rows.append({
                "mu": mu,
                "target_probability": target,
                "minimum_odd_horizon": n,
                "exact_probability_at_threshold": exact,
            })
    out = pd.DataFrame(rows)
    out.to_csv(RESULTS / "house_edge_thresholds.csv", index=False)
    return out


def create_evidence_map() -> pd.DataFrame:
    rows = [
        {
            "id": "D1-01", "domain": "D1 formalna probabilistyka", "year": 1956,
            "source": "Kelly JL. A New Interpretation of Information Rate.",
            "design": "twierdzenie formalne / wzrost logarytmiczny", "sample": "nie dotyczy",
            "key_finding": "Optymalizacja długookresowego wzrostu wymaga uwzględnienia przewagi i wielkości stawki; przy symetrycznej grze o ujemnej przewadze optymalna ekspozycja może wynosić zero.",
            "bridge_relevance": "benchmark A0: nie uczestniczę", "strength": "wysoka formalnie",
            "limitations": "nie jest teorią zachowania biologicznego", "doi": "10.1002/j.1538-7305.1956.tb03809.x"
        },
        {
            "id": "D1-02", "domain": "D1 formalna probabilistyka", "year": 1991,
            "source": "Williams D. Probability with Martingales.",
            "design": "monografia formalna", "sample": "nie dotyczy",
            "key_finding": "Narzędzia martyngałowe i prawa wielkich liczb wyznaczają warunki zbieżności procesów z zależnością i zatrzymaniem.",
            "bridge_relevance": "podstawa twierdzenia M0", "strength": "wysoka formalnie",
            "limitations": "prawdziwość w świecie zależy od spełnienia założeń", "doi": "ISBN 9780521406055"
        },
        {
            "id": "D2-01", "domain": "D2 reinforcement learning", "year": 1997,
            "source": "Schultz W, Dayan P, Montague PR. A Neural Substrate of Prediction and Reward.",
            "design": "neurofizjologia zwierząt", "sample": "zadania warunkowania",
            "key_finding": "Aktywność dopaminergiczna wykazuje właściwości zgodne z sygnałem błędu predykcji nagrody.",
            "bridge_relevance": "kotwica dla modelu uczenia przez błąd predykcji", "strength": "wysoka, klasyczna",
            "limitations": "nie redukuje całej funkcji dopaminy do jednego sygnału", "doi": "10.1126/science.275.5306.1593"
        },
        {
            "id": "D2-02", "domain": "D2 reinforcement learning", "year": 2013,
            "source": "Steinberg EE et al. A causal link between prediction errors, dopamine neurons and learning.",
            "design": "manipulacja optogenetyczna", "sample": "gryzonie",
            "key_finding": "Precyzyjnie czasowane pobudzenie neuronów dopaminowych może działać jak przyczynowy sygnał uczący.",
            "bridge_relevance": "wspiera przyczynową rolę sygnałów predykcyjnych", "strength": "wysoka w zadaniu",
            "limitations": "specyficzne zadanie i gatunek", "doi": "10.1038/nn.3413"
        },
        {
            "id": "D2-03", "domain": "D2 reinforcement learning", "year": 2011,
            "source": "Daw ND et al. Model-Based Influences on Humans' Choices and Striatal Prediction Errors.",
            "design": "eksperyment człowiek + fMRI + model obliczeniowy", "sample": "zadanie dwuetapowe",
            "key_finding": "W ludzkich decyzjach współistnieją wpływy model-free i model-based.",
            "bridge_relevance": "uzasadnia porównanie agentów o różnych reprezentacjach", "strength": "wysoka, wielokrotnie rozwijana",
            "limitations": "identyfikacja strategii zależy od modelu zadania", "doi": "10.1016/j.neuron.2011.02.027"
        },
        {
            "id": "D2-04", "domain": "D2 reinforcement learning", "year": 2025,
            "source": "Greenstreet F et al. Dopaminergic action prediction errors serve as a value-free teaching signal.",
            "design": "myszy; modelowanie i manipulacje przyczynowe", "sample": "wiele kohort zadaniowych",
            "key_finding": "Odrębne sygnały błędu predykcji działania i nagrody mogą wspólnie wzmacniać powtarzane skojarzenia stan–działanie.",
            "bridge_relevance": "wspiera rozdzielenie powtarzania od wartości", "strength": "wysoka w zadaniu",
            "limitations": "nie jest bezpośrednim modelem ludzkiej świadomości", "doi": "10.1038/s41586-025-09008-9"
        },
        {
            "id": "D2-05", "domain": "D2 reinforcement learning", "year": 2025,
            "source": "Bakhurin KI et al. Dopamine dynamics during stimulus-reward learning in mice can be explained by performance rather than learning.",
            "design": "myszy; optogenetyka i analiza dynamiki", "sample": "zadanie bodziec–nagroda",
            "key_finding": "Część dynamiki dopaminy może regulować wykonanie, siłę i przejścia zachowania w czasie rzeczywistym, bez wykazanego wpływu na uczenie.",
            "bridge_relevance": "falsyfikator redukcji dopaminy do jednego mechanizmu", "strength": "wysoka w zadaniu",
            "limitations": "spór interpretacyjny nie jest zamknięty", "doi": "10.1038/s41467-025-64132-4"
        },
        {
            "id": "D3-01", "domain": "D3 nawyk i kontrola celowa", "year": 2010,
            "source": "Balleine BW, O'Doherty JP. Human and Rodent Homologies in Action Control.",
            "design": "przegląd integracyjny", "sample": "literatura ludzka i zwierzęca",
            "key_finding": "Kontrola celowa i nawykowa są rozróżnialnymi, współdziałającymi systemami działania.",
            "bridge_relevance": "podstawa rozdzielenia specjalizacji od błędnego zamknięcia", "strength": "wysoka przeglądowo",
            "limitations": "homologie nie są tożsamością mechanizmów", "doi": "10.1038/npp.2009.131"
        },
        {
            "id": "D3-02", "domain": "D3 nawyk i kontrola celowa", "year": 2025,
            "source": "Perez OD, Urcelay GP. Delayed rewards weaken human goal directed actions.",
            "design": "3 eksperymenty ludzkie", "sample": "N=290",
            "key_finding": "Opóźniony feedback osłabiał wiedzę działanie–wynik i wrażliwość na zmianę wartości rezultatu.",
            "bridge_relevance": "empiryczna kotwica opóźnionych kosztów M1/M2", "strength": "średnio-wysoka",
            "limitations": "fiktcyjne inwestycje i krótki horyzont", "doi": "10.1038/s41539-025-00325-2"
        },
        {
            "id": "D3-03", "domain": "D3 nawyk i kontrola celowa", "year": 2026,
            "source": "Moore S et al. Revealing abrupt transitions from goal-directed to habitual behavior.",
            "design": "samce myszy; HMM-GLM, dewaluacja, lezje, fotometria", "sample": "wiele sesji; przejście po długim treningu",
            "key_finding": "Przejście mogło być nagłe (~3 próby), występowało długo po opanowaniu zadania i u części zwierząt było odwracalne.",
            "bridge_relevance": "wspiera możliwość nieliniowej zmiany, obala uniwersalną trwałość", "strength": "wysoka w paradygmacie",
            "limitations": "samce myszy; brak uniwersalnego progu liczby prób", "doi": "10.1038/s41467-026-71048-0"
        },
        {
            "id": "D4-01", "domain": "D4 pewność i kalibracja", "year": 2012,
            "source": "Rahnev DA et al. Direct injection of noise to the visual cortex decreases accuracy but increases decision confidence.",
            "design": "eksperyment ludzki TMS", "sample": "percepcja wzrokowa",
            "key_finding": "Zakłócenie zmniejszyło trafność, a jednocześnie zwiększyło deklarowaną pewność.",
            "bridge_relevance": "dowód możliwości rozbieżności pewność–trafność", "strength": "wysoka dla zjawiska",
            "limitations": "nie waliduje value-gap jako pewności", "doi": "10.1152/jn.00985.2011"
        },
        {
            "id": "D4-02", "domain": "D4 pewność i kalibracja", "year": 2018,
            "source": "Lebreton M et al. Two sides of the same coin: monetary incentives concurrently improve and bias confidence judgments.",
            "design": "eksperymenty ludzkie", "sample": "decyzje percepcyjne",
            "key_finding": "Bodźce pieniężne mogą poprawiać wykonanie i jednocześnie systematycznie przesuwać oceny pewności.",
            "bridge_relevance": "wspiera niezależne mierzenie CAL i proxy pewności", "strength": "średnio-wysoka",
            "limitations": "zadania laboratoryjne", "doi": "10.1126/sciadv.aaq0668"
        },
        {
            "id": "D4-03", "domain": "D4 pewność i kalibracja", "year": 2019,
            "source": "Lebreton M et al. Contextual influence on confidence judgments in human reinforcement learning.",
            "design": "eksperymenty ludzkie + model RL", "sample": "uczenie wyborów",
            "key_finding": "Oceny pewności zależą od kontekstu i porównań, a nie tylko od bezwzględnej trafności.",
            "bridge_relevance": "ogranicza interpretację modelowego proxy pewności", "strength": "średnio-wysoka",
            "limitations": "zależność od modelu i zadania", "doi": "10.1371/journal.pcbi.1006973"
        },
        {
            "id": "D4-04", "domain": "D4 kalibracja", "year": 2019,
            "source": "Van Calster B et al. Calibration: the Achilles heel of predictive analytics.",
            "design": "przegląd metodologiczny", "sample": "modele prognostyczne",
            "key_finding": "Kalibracja wymaga osobnych miar i wykresów; pojedynczy wynik ogólny nie wystarcza.",
            "bridge_relevance": "uzasadnia pakiet CAL zamiast samego Brier score", "strength": "wysoka metodologicznie",
            "limitations": "dotyczy modeli predykcyjnych, nie subiektywnego doświadczenia", "doi": "10.1186/s12916-019-1466-7"
        },
        {
            "id": "D5-01", "domain": "D5 hazard i wzmocnienia", "year": 2009,
            "source": "Clark L et al. Gambling near-misses enhance motivation to gamble and recruit win-related brain circuitry.",
            "design": "eksperyment ludzki + fMRI", "sample": "symulowana maszyna losowa",
            "key_finding": "Near-miss zwiększał motywację do dalszej gry mimo obiektywnej przegranej.",
            "bridge_relevance": "kotwica bodźców kontynuacyjnych M1", "strength": "wysoka dla zadania",
            "limitations": "near-miss nie jest uniwersalnym mechanizmem każdej ekspozycji", "doi": "10.1016/j.neuron.2008.12.031"
        },
        {
            "id": "D5-02", "domain": "D5 hazard i wzmocnienia", "year": 2023,
            "source": "Thrailkill EA. Partial reinforcement extinction and omission effects in the rat.",
            "design": "3 eksperymenty zwierzęce", "sample": "szczury",
            "key_finding": "Harmonogram uczenia wpływa na odporność zachowania podczas wygaszania.",
            "bridge_relevance": "wspiera warunkowość trwałości zachowania", "strength": "średnia",
            "limitations": "wynik zależy od harmonogramu i kontekstu; brak prostego prawa variable-ratio", "doi": "10.1037/xan0000354"
        },
        {
            "id": "D5-03", "domain": "D5 hazard i interwencje", "year": 2022,
            "source": "Hopfgartner N et al. The Effect of Mandatory Play Breaks on Subsequent Gambling Behavior.",
            "design": "randomizowany eksperyment terenowy", "sample": "21 129 graczy; 156 989 przerw",
            "key_finding": "15-minutowa przerwa wydłużała dobrowolną pauzę, ale po powrocie nie zmieniała istotnie kwoty stawek.",
            "bridge_relevance": "interwencje M1 są heterogeniczne i nie gwarantują redukcji kosztu", "strength": "wysoka terenowo",
            "limitations": "jeden operator, limity strat, selekcja aktywnych graczy", "doi": "10.1007/s10899-021-10078-3"
        },
        {
            "id": "D5-04", "domain": "D5 hazard i ekspozycja", "year": 2014,
            "source": "Auer M, Griffiths MD. An Empirical Investigation of Theoretical Loss and Gambling Intensity.",
            "design": "dane rzeczywiste graczy online", "sample": "100 000 graczy",
            "key_finding": "Teoretyczna strata uwzględniająca stawki i przewagę operatora lepiej opisuje intensywność niż sama kwota wygrana/przegrana.",
            "bridge_relevance": "empiryczna analogia μ × ekspozycja", "strength": "średnio-wysoka",
            "limitations": "obserwacyjne dane operatora", "doi": "10.1007/s10899-013-9376-7"
        },
        {
            "id": "D6-01", "domain": "D6 platformy i operator", "year": 2021,
            "source": "Lindström B et al. A computational reward learning account of social media engagement.",
            "design": "duże dane + eksperyment online", "sample": ">1 mln postów, >4000 osób; eksperyment N=176",
            "key_finding": "Nagrody społeczne przewidywały rytm publikowania, a eksperyment wspierał wpływ przyczynowy nagród na zachowanie.",
            "bridge_relevance": "wspiera M1 poza hazardem", "strength": "wysoka wielometodowo",
            "limitations": "zaangażowanie nie jest automatycznie szkodą ani zamknięciem", "doi": "10.1038/s41467-020-19607-x"
        },
        {
            "id": "D6-02", "domain": "D6 platformy i operator", "year": 2023,
            "source": "Khambatta P et al. Tailoring recommendation algorithms to ideal preferences makes users better off.",
            "design": "prerejestrowany eksperyment", "sample": "N=6488",
            "key_finding": "Rekomendacje zgodne z preferencjami idealnymi dawały mniej kliknięć, ale wyższy deklarowany dobrostan i wartość dla firmy.",
            "bridge_relevance": "kontrprzykład: mniej ekspozycji nie musi szkodzić operatorowi; zysk operatora ≠ strata agenta", "strength": "wysoka w zadaniu",
            "limitations": "krótkie środowisko eksperymentalne i miary deklaratywne", "doi": "10.1038/s41598-023-34192-x"
        },
        {
            "id": "D6-03", "domain": "D6 platformy i operator", "year": 2023,
            "source": "Nyhan B et al. Like-minded sources on Facebook are prevalent but not polarizing.",
            "design": "wielofalowy eksperyment terenowy", "sample": "N=23 377",
            "key_finding": "Redukcja ekspozycji na podobne źródła o około 1/3 zmieniła skład feedu, lecz nie osiem prerejestrowanych postaw.",
            "bridge_relevance": "falsyfikator prostego łańcucha ekspozycja→zmiana przekonań", "strength": "wysoka terenowo",
            "limitations": "Facebook 2020, ograniczone rezultaty i horyzont", "doi": "10.1038/s41586-023-06297-w"
        },
        {
            "id": "D6-04", "domain": "D6 platformy i operator", "year": 2026,
            "source": "Gauthier G et al. The political effects of X's feed algorithm.",
            "design": "7-tygodniowy randomizowany eksperyment terenowy", "sample": "do N=4965 zależnie od wyniku",
            "key_finding": "Włączenie algorytmicznego feedu zwiększało zaangażowanie i przesuwało wybrane opinie, ale nie polaryzację afektywną ani deklarowaną partyjność.",
            "bridge_relevance": "pokazuje efekty operatora zależne od platformy i wyniku", "strength": "wysoka terenowo",
            "limitations": "asymetria przełączeń, jedna platforma i okres polityczny", "doi": "10.1038/s41586-026-10098-2"
        },
        {
            "id": "METH-01", "domain": "Metody", "year": 2019,
            "source": "Morris TP, White IR, Crowther MJ. Using simulation studies to evaluate statistical methods.",
            "design": "standard metodologiczny ADEMP", "sample": "nie dotyczy",
            "key_finding": "Symulacje powinny jawnie określać cele, DGM, estymandy, metody i miary wykonania.",
            "bridge_relevance": "szkielet projektu", "strength": "wysoka metodologicznie",
            "limitations": "nie waliduje konkretnego DGM", "doi": "10.1002/sim.8086"
        },
        {
            "id": "METH-02", "domain": "Metody", "year": 2020,
            "source": "Grimm V et al. The ODD Protocol for Describing Agent-Based and Other Simulation Models.",
            "design": "standard ODD", "sample": "nie dotyczy",
            "key_finding": "Overview–Design concepts–Details zwiększa przejrzystość i replikowalność modeli agentowych.",
            "bridge_relevance": "dokumentacja agentów i środowisk", "strength": "wysoka metodologicznie",
            "limitations": "opis nie zastępuje walidacji", "doi": "10.18564/jasss.4259"
        },
        {
            "id": "METH-03", "domain": "Metody", "year": 2021,
            "source": "Page MJ et al. The PRISMA 2020 statement.",
            "design": "wytyczne raportowania przeglądów", "sample": "nie dotyczy",
            "key_finding": "Przegląd systematyczny wymaga pełnego raportowania wyszukiwania, selekcji i syntezy.",
            "bridge_relevance": "uzasadnia nazwę: ustrukturyzowana mapa dowodów, nie pełny PRISMA", "strength": "wysoka metodologicznie",
            "limitations": "nie jest narzędziem oceny jakości pojedynczego badania", "doi": "10.1136/bmj.n71"
        },
        {
            "id": "METH-04", "domain": "Metody", "year": 2009,
            "source": "Koehler E, Brown E, Haneuse S. On the Assessment of Monte Carlo Error.",
            "design": "metody błędu Monte Carlo", "sample": "nie dotyczy",
            "key_finding": "Precyzję symulacji należy raportować i dobierać do estymandu, zamiast używać jednej arbitralnej liczby replikacji.",
            "bridge_relevance": "MCSE i adjudykacja C12", "strength": "wysoka metodologicznie",
            "limitations": "MCSE nie obejmuje błędu specyfikacji modelu", "doi": "10.1198/tast.2009.0030"
        },
    ]
    df = pd.DataFrame(rows)
    df.to_csv(LITERATURE / "evidence_map.csv", index=False)
    return df


def create_search_log(evidence: pd.DataFrame) -> None:
    text = f"""# Dziennik wyszukiwania i mapa dowodów

## Status

Wykonano **ustrukturyzowany przegląd zakresowy z mapą siły dowodów**, a nie pełny przegląd systematyczny PRISMA. Celem było zakotwiczenie twierdzeń pomostowych i znalezienie wyników przeciwnych prostemu łańcuchowi `nagroda → zamknięcie → przewaga operatora`.

Data odcięcia: **2026-08-06**. Liczba zakodowanych pozycji kotwiczących: **{len(evidence)}**.

## Źródła i ścieżki wyszukiwania

Przeszukano indeksy internetowe prowadzące do stron wydawców i rekordów bibliograficznych, w szczególności PubMed/NCBI, Nature Portfolio, Springer Nature, BMJ, JASS oraz strony DOI. Włączano prace pierwotne, klasyczne prace formalne, przeglądy integracyjne i standardy metodologiczne. Preferowano źródła pierwotne dla twierdzeń technicznych.

Przykładowe grupy zapytań:

```text
martingale strong law predictable exposure conditional drift
random walk gambler ruin finite horizon negative drift
softmax entropy derivative inverse temperature
reward prediction error dopamine causal optogenetic learning
model-based model-free human choices striatal prediction error
habit transition reversal learning outcome devaluation
confidence accuracy dissociation TMS
monetary incentive confidence calibration
near miss gambling motivation continue
partial reinforcement extinction effect schedule
mandatory play break gambling real world randomized
social media engagement reward learning experiment
recommendation ideal preferences user welfare preregistered
Facebook like-minded exposure field experiment attitudes
X algorithm chronological feed randomized political effects
ADEMP simulation studies MCSE ODD PRISMA
```

## Kryteria włączenia

Włączano źródła, które co najmniej jednoznacznie dotyczyły: formalnej przewagi i zatrzymania; ruiny i stawkowania; uczenia model-free/model-based; dopaminergicznych sygnałów predykcyjnych; nawyku, reversal learning i opóźnionych skutków; kalibracji i pewności; bodźców kontynuacyjnych; operatorów platform i zaangażowania; albo metodologii symulacji.

## Kryteria wyłączenia

Wyłączano materiały bez identyfikowalnego źródła pierwotnego, teksty publicystyczne używane jako jedyne wsparcie, niezweryfikowane twierdzenia o jednym „układzie dopaminy”, wyniki mieszające zaangażowanie z dobrostanem bez osobnej miary oraz publikacje, których nie dało się jednoznacznie przypisać do twierdzenia.

## Ograniczenia

Nie wykonano pełnego screeningu wszystkich baz, deduplikacji rekordów ani niezależnego podwójnego kodowania. Liczba pozycji nie jest liczbą wszystkich istniejących badań. Mapa służy do oceny zgodności mechanizmów i granic uogólnienia, nie do metaanalitycznego estymowania jednego efektu.
"""
    (LITERATURE / "search_log.md").write_text(text, encoding="utf-8")


def create_claim_registry() -> pd.DataFrame:
    rows = [
        ["C-M0-1", "Przy dodatnim warunkowym dryfie, rosnącej liczbie ekspozycji i warunkach martyngałowego SLLN średni wynik operatora na ekspozycję jest asymptotycznie dodatni.", "M0", "formalny", "proces stochastyczny", "dowód", "wsparty", "wysoka przy założeniach", "zależna od spełnienia założeń", "P1", "nie oznacza wygranej w każdej rundzie ani każdym skończonym szeregu"],
        ["C-M0-2", "Sama bezwarunkowa dodatnia wartość oczekiwana nie wystarcza przy selektywnej ekspozycji.", "M0", "formalny", "proces selekcyjny", "kontrprzykład", "wsparty", "wysoka", "formalna", "P1", "kontrprzykład wyznacza granicę twierdzenia"],
        ["C-M0-3", "Przy stałej dodatniej przewadze iid P(S_T>0) rośnie do 1, ale dla każdego skończonego T pozostaje mniejsze od 1.", "M0", "formalny+obliczeniowy", "gra iid ±1", "rozkład dwumianowy + Monte Carlo", "wsparty", "wysoka", "ograniczona do DGM", "P1/P3", "stała przewaga, niezależność"],
        ["C-M0-4", "Ruina jest twierdzeniem warunkowym: zależy od minimalnej stawki, nieskończonej ekspozycji, dopływów, wyjścia i definicji ruiny.", "M0", "formalny+obliczeniowy", "kapitał gracza", "łańcuch absorbujący + Monte Carlo", "wsparty", "wysoka w modelu", "ograniczona", "P1/P3", "strategie proporcjonalne mogą unikać literalnego zera przy spadku dobrostanu"],
        ["C-M0-5", "Żaden przewidywalny dodatni system stawkowania nie odwraca znaku jednostkowego ujemnego dryfu gry.", "M0", "formalny", "stawkowanie", "warunkowa wartość oczekiwana", "wsparty", "wysoka", "formalna", "P1", "nie obejmuje zmiany samej gry lub informacji dającej przewagę graczowi"],
        ["C-M1-1", "W syntetycznym modelu lokalna percepcja strat, tempo aktualizacji, temperatura i koszt wyjścia silnie zmieniają liczbę ekspozycji.", "M1", "obliczeniowy", "agent kontynuacji", "LHS + model zastępczy + plan konfirmacyjny", "wsparty", "wysoka w badanym zakresie", "ograniczona", "P3", "ważności ExtraTrees są eksploracyjne i in-sample"],
        ["C-M1-2", "Ujawnienie wartości oczekiwanej może zmniejszać ekspozycję, lecz efekt jest heterogeniczny i zależy od DGM.", "M1", "obliczeniowy+empiryczny", "interwencja informacyjna", "symulacja parowana + mapa dowodów", "warunkowo wsparty", "średnia", "częściowa", "P3/P4", "nie jest uniwersalną gwarancją skuteczności"],
        ["C-M2-1", "Niska entropia polityki nie jest ani konieczna, ani wystarczająca dla błędnego zamknięcia.", "M2", "formalny+obliczeniowy", "bandyta syntetyczny", "kontrprzykłady stationary/reversal/random", "wsparty", "wysoka w DGM", "brak bez mostu B1", "P1/P3", "entropia nie jest biologiczną percepcją"],
        ["C-M2-2", "Błędne zamknięcie wymaga kosztu lub regretu oraz niewłaściwej aktualizacji/adaptacji, a nie samej koncentracji.", "M2", "konstrukcyjny+obliczeniowy", "bandyta reversal", "oracle i benchmarki", "wsparty", "wysoka w DGM", "ograniczona", "P3", "progi CLOSE nie zostały zwalidowane biologicznie"],
        ["C-M2-3", "Model-based z błędnym modelem może adaptować się gorzej niż prostszy agent model-free.", "M2", "obliczeniowy", "bandyta reversal", "kontrprzykład bayes_stationary vs discounted/Q", "wsparty", "wysoka w DGM", "ograniczona", "P3", "wynik zależy od rodzaju błędnej specyfikacji"],
        ["C-M2-4", "Modelowy proxy pewności może rosnąć, gdy jakość predykcji się pogarsza.", "M2", "obliczeniowy+empiryczny", "kalibracja", "bandyta + literatura ludzka", "wsparty warunkowo", "średnio-wysoka", "częściowa", "P3/P4", "value-gap nie jest deklarowaną pewnością człowieka"],
        ["C-M3-1", "W rdzeniowym DGM ze stałą przewagą E[S_O(T)]=μE[N(T)].", "M3", "formalny+obliczeniowy", "model ekspozycji", "tożsamość iterowanej wartości oczekiwanej + symulacja", "wsparty", "wysoka w DGM", "ograniczona", "P1/P3", "adaptacyjna μ_t i niezerowa suma wymagają rozszerzenia"],
        ["C-M3-2", "Zamknięcie nie jest konieczne do zysku operatora; może jedynie wzmacniać wynik, gdy zwiększa N(T), opóźnia wyjście lub koreluje z dodatnią μ_t.", "M3", "formalny+obliczeniowy", "sprzężenie", "ablacje i 18-klasowy challenge set", "wsparty", "wysoka w klasie modeli", "ograniczona", "P1/P3", "brak pełnej walidacji platformowej"],
        ["C-M3-3", "Przy μ=0 sama ekspozycja nie tworzy oczekiwanego zysku pieniężnego; przy μ<0 większa ekspozycja pogarsza wynik operatora.", "M3", "formalny+obliczeniowy", "gra uczciwa i ujemna przewaga", "niezależna adjudykacja 131072/scenariusz + adversarial MC", "wsparty", "wysoka", "ograniczona do zdefiniowanej użyteczności", "P1/P3", "operator może mieć inną dodatnią użyteczność z uwagi"],
        ["C-U-1", "Zysk operatora nie jest automatycznie stratą agenta.", "M3", "formalny+obliczeniowy", "klasy U1–U5", "kontrprzykłady użyteczności", "wsparty", "wysoka formalnie", "szeroka konceptualnie", "P1/P3", "w realnej domenie użyteczności trzeba mierzyć osobno"],
        ["C-B1", "Koncentracja polityki syntetycznej odpowiada biologicznemu nawykowi.", "bridge", "pomostowy", "człowiek/zwierzę", "brak walidacji jeden-do-jednego", "częściowo wspierane kierunkowo", "niska", "ograniczona", "P5", "wymaga walidacji zbieżnej, kryterialnej i różnicowej"],
        ["C-B2", "Value-gap lub entropia jest miarą subiektywnej pewności człowieka.", "bridge", "pomostowy", "człowiek", "brak bezpośredniej walidacji", "niewykazane", "niska", "brak", "P5", "literatura potwierdza jedynie możliwość dysocjacji pewność–trafność"],
        ["C-B3", "Modelowe adaptation delay odpowiada empirycznej sztywności/reversal learning.", "bridge", "pomostowy", "człowiek", "zgodność konstrukcyjna", "częściowo wspierane", "średnia", "ograniczona", "P5", "brak kalibracji skali kroków do zachowania ludzkiego"],
        ["C-B4", "Operator syntetyczny reprezentuje rzeczywiste platformy i gry.", "bridge", "pomostowy", "platforma/hazard", "zgodność mechanizmów cząstkowych", "częściowo wspierane", "średnia", "heterogeniczna", "P5", "platformy różnią się celami, interfejsem i użytecznością"],
        ["C-B5", "Wynik operatora jest tożsamy ze spadkiem dobrostanu agenta.", "bridge", "pomostowy", "człowiek", "kontrprzykłady formalne i empiryczne", "odrzucone jako uniwersalne", "wysoka", "szeroka", "P6", "możliwe U3 i U5"],
        ["C-BIO-200", "Dwieście ekspozycji stanowi biologiczny próg nieodwracalnego zamknięcia.", "bridge", "empiryczny", "człowiek", "brak danych + analiza horyzontów", "odrzucone jako uniwersalne", "wysoka negatywna ocena", "nie dotyczy", "P6", "T=200 jest wyłącznie kotwicą obserwacyjną"],
    ]
    cols = ["ID", "claim", "module", "type", "domain", "identification", "result", "robustness", "external_validity", "status", "limitations"]
    df = pd.DataFrame(rows, columns=cols)
    df.to_csv(CLAIMS / "claim_registry.csv", index=False)
    return df


def create_report(thresholds: pd.DataFrame, evidence: pd.DataFrame, claims: pd.DataFrame) -> str:
    house = pd.read_csv(RESULTS / "house_edge.csv")
    ruin = pd.read_csv(RESULTS / "gambler_ruin.csv")
    bandit = pd.read_csv(RESULTS / "bandit_metrics.csv")
    conf = pd.read_csv(RESULTS / "exposure_confirmatory_results.csv")
    paired = pd.read_csv(RESULTS / "exposure_confirmatory_paired_effects.csv")
    disclosure = pd.read_csv(RESULTS / "exposure_disclosure_effects.csv")
    importance = pd.read_csv(RESULTS / "screening_feature_importance.csv")
    challenge = pd.read_csv(RESULTS / "challenge_set_results_final.csv")
    negative = pd.read_csv(RESULTS / "negative_edge_challenge.csv")
    utility = pd.read_csv(RESULTS / "utility_class_counterexamples.csv")
    fair_adj = json.loads((RESULTS / "fair_game_adjudication_summary.json").read_text(encoding="utf-8"))

    house_sel = house[(house.horizon.isin([200, 1000, 5000]))][
        ["mu", "horizon", "p_operator_positive_exact", "mean_gain_per_exposure", "mcse_mean_per_exposure"]
    ].copy()
    house_sel.columns = ["μ", "T", "dokładne P(Sᴼ>0)", "MC średni wynik/eksp.", "MCSE"]

    threshold_tbl = thresholds.copy()
    threshold_tbl.columns = ["μ", "cel P(Sᴼ>0)", "minimalne nieparzyste T", "dokładne P przy progu"]

    ruin_sel = ruin[(ruin.horizon == 5000) & (ruin.strategy.isin([
        "fixed_unit_exact", "no_play", "martingale_limit16", "stop_loss_20pct", "proportional_1pct"
    ]))][["strategy", "ruin_probability", "practical_ruin_probability", "mean_wealth", "median_wealth", "exit_probability", "mean_exposures"]].copy()
    ruin_sel.columns = ["strategia", "P(ruiny literalnej)", "P(ruiny praktycznej)", "średni kapitał", "mediana kapitału", "P(wyjścia)", "średnia ekspozycja"]

    rev = bandit[bandit.environment == "reversal"][[
        "agent", "post_regret_mean", "post_entropy_mean", "post_confidence_proxy", "post_brier",
        "post_calibration_slope", "post_ece_10bin", "adaptation_delay_mean", "no_adaptation_rate"
    ]].sort_values("post_regret_mean")
    rev.columns = ["agent", "regret po zmianie", "entropia", "proxy pewności", "Brier", "nachylenie kalibracji", "ECE", "opóźnienie adaptacji", "brak adaptacji"]

    extreme = conf.loc[[8, 15, 16, 23], [
        "scenario_id", "mu", "loss_weight", "alpha", "exit_cost", "mean_exposures", "mean_operator_gain", "expected_gain_via_exposure", "mean_policy_concentration", "mean_update_error"
    ]].copy()
    extreme.columns = ["scenariusz", "μ", "waga straty", "α", "koszt wyjścia", "E[N]", "E[Sᴼ]", "μE[N]", "koncentracja", "błąd aktualizacji"]

    imp = importance.sort_values(["target", "importance"], ascending=[True, False]).groupby("target").head(4).copy()
    imp.columns = ["wynik", "parametr", "ważność ExtraTrees", "R² treningowe"]

    disc_by_mu = disclosure.groupby("mu", as_index=False).agg(
        delta_N=("delta_exposures_disclosure_minus_base", "mean"),
        delta_SO=("delta_operator_gain_disclosure_minus_base", "mean"),
        delta_update=("delta_update_error", "mean"),
    )
    disc_by_mu.columns = ["μ", "średnie ΔN po ujawnieniu", "średnie ΔSᴼ", "średnie Δ błędu aktualizacji"]

    evidence_summary = evidence.groupby("domain", as_index=False).agg(
        sources=("id", "count"),
        years=("year", lambda s: f"{int(s.min())}–{int(s.max())}"),
    )
    evidence_summary.columns = ["domena", "liczba źródeł", "zakres lat"]

    p_mu200 = house[(house.mu == 0.02) & (house.horizon == 200)].iloc[0]
    p_mu100 = house[(house.mu == 0.02) & (house.horizon == 100)].iloc[0]
    p_mu500 = house[(house.mu == 0.02) & (house.horizon == 500)].iloc[0]
    fixed5000 = ruin[(ruin.strategy == "fixed_unit_exact") & (ruin.horizon == 5000)].iloc[0]
    mart5000 = ruin[(ruin.strategy == "martingale_limit16") & (ruin.horizon == 5000)].iloc[0]
    prop5000 = ruin[(ruin.strategy == "proportional_1pct") & (ruin.horizon == 5000)].iloc[0]

    corr = float(np.corrcoef(
        paired[paired.mu > 0]["delta_operator_gain"],
        paired[paired.mu > 0]["predicted_delta_via_exposure"]
    )[0, 1])
    mar = float(np.mean(np.abs(paired[paired.mu > 0]["coupling_residual"])))

    total_trajectories = 9_608_080
    timestamp = datetime.now(timezone.utc).isoformat()

    report = f"""# Oczy szeroko zamknięte są — kasyno wygrywa zawsze

## Warunkowa teoria asymetrycznej kumulacji ekspozycji, zamknięcia decyzyjnego i przewagi operatora

**Raport końcowy badania formalnego, obliczeniowego i przeglądowego**  
Wersja: 1.1.0  
Finalizacja: {timestamp}  
Preregistracja SHA-256: `5ff09e7c0cee6184dc82c65c4ea1c20ad2cf747d9b2063ae8feadaf91a88bbad`

---

# Abstrakt

Zbadano, czy dwa odrębne mechanizmy mogą tworzyć wspólną teorię warunkową: asymptotyczna przewaga operatora oraz zawężenie polityki decyzyjnej agenta. Protokół rozdzielił cztery moduły: `M0` — przewaga operatora, `M1` — liczba ekspozycji, `M2` — błędna koncentracja i adaptacja, `M3` — ich sprzężenie. Wykonano dowody formalne i kontrprzykłady, dokładne obliczenia dwumianowe i łańcuchy absorbujące, około **{total_trajectories:,}** trajektorii symulacyjnych różnych klas, screening 2048 punktów Latin Hypercube, 24 scenariusze konfirmacyjne, niezależną adjudykację gry uczciwej po 131 072 replikacje na scenariusz oraz challenge set obejmujący 18 klas kontrprzykładów. Uzupełnieniem była ustrukturyzowana mapa {len(evidence)} źródeł formalnych, neurobiologicznych, behawioralnych, hazardowych, platformowych i metodologicznych.

`M0` został potwierdzony formalnie: dodatni warunkowy dryf oraz rosnąca liczba ekspozycji prowadzą — przy warunkach prawa wielkich liczb — do dodatniego średniego wyniku operatora i `P(Sᴼ(T)>0)→1`. Nie oznacza to wygranej w każdej rundzie ani dowolnym skończonym szeregu. `M2` wykazał, że niska entropia jest nieswoista: może oznaczać optymalną specjalizację albo kosztowną bezwładność. `M3` przy stałej przewadze spełnia tożsamość `E[Sᴼ(T)]=μE[N(T)]`; mechanizmy zamknięcia wzmacniają operatora tylko wtedy, gdy zwiększają ekspozycję, opóźniają wyjście lub współzmieniają przewagę. Przy `μ=0` nie tworzą oczekiwanego zysku pieniężnego, a przy `μ<0` zwiększają oczekiwaną stratę operatora.

Nie znaleziono podstaw dla biologicznego progu 200 ekspozycji, nieodwracalnego „zamknięcia mózgu” ani utożsamienia dopaminy z prostym przyciskiem nagrody. Najwyższy uzasadniony wynik to **warunkowa teoria formalno-obliczeniowa o ograniczonym zakresie i częściowym wsparciu empirycznym**. Werdykt ogólny: **B**.

---

# 1. Status epistemiczny i zakres

Badanie realizuje źródłowy protokół V2.0: nie zakłada tożsamości mechanizmów, rozdziela je na M0–M3 i dopuszcza najwyżej teorię formalno-obliczeniową z empirycznie zakotwiczonymi mostami. Nie przeprowadzono nowych eksperymentów na ludziach ani zwierzętach. Symulacja służy do badania konsekwencji jawnych założeń, nie do dowodzenia biologii.

Rozróżnienie zastosowane w całym raporcie:

```text
P1 — dowód formalny przy jawnych założeniach,
P2 — niezmiennik potwierdzony w niezależnych implementacjach,
P3 — wynik symulacyjny odporny w zdefiniowanej przestrzeni modeli,
P4 — silna regularność empiryczna wsparta wieloma źródłami,
P5 — hipoteza pomostowa pozostająca otwarta,
P6 — twierdzenie niewspierane albo obalone jako uniwersalne.
```

Pełnego P2 nie przyznano żadnemu twierdzeniu: uzyskano zgodność rozwiązań analitycznych, symulacji i niezależnych strumieni losowych, ale nie wykonano reimplementacji przez niezależny zespół w drugim stosie programistycznym.

---

# 2. Operacjonalizacja metafor

```text
„Kasyno wygrywa zawsze”
=
operator nie musi wygrywać każdej interakcji,
jeżeli ma dodatnią warunkową przewagę,
a liczba rzeczywistych ekspozycji rośnie.
```

```text
„Oczy szeroko zamknięte są”
=
agent nadal otrzymuje informacje,
lecz jego polityka jest skoncentrowana w sposób,
który generuje regret, nieadekwatną aktualizację
lub ponadnormatywne opóźnienie adaptacji.
```

Samo powtarzanie działania, wysoka koncentracja albo niska entropia nie wystarczają. Wynik podstawowy M2 jest wektorem:

```text
ZPD⃗ = ⟨PC, HS, CAL, CR, AD, RD⟩
```

W wykonanej części obliczeniowej bezpośrednio oszacowano `PC` (koncentrację polityki), pakiet `CAL`, `AD` (czas adaptacji), dynamiczny regret oraz modelowy błąd aktualizacji. `HS` i pełne `CR` pozostają zależne od klasy agenta i nie zostały scalone w jeden indeks.

---

# 3. Metody

## 3.1. Preregistracja i bramki

Przed scenariuszami konfirmacyjnymi zamrożono hipotezy, DGM, parametry, główne wyniki, strumienie RNG i reguły challenge set. Rdzeń obejmował 24 scenariusze: `μ∈{{0, 0.02, 0.05}}`, pełną albo zaniżoną percepcję strat, szybkie albo wolne uczenie i zerowy albo dodatni koszt wyjścia. `T=200` traktowano wyłącznie jako jeden z horyzontów, nie jako próg.

## 3.2. ADEMP

**Aims.** Ustalić warunki kumulacji przewagi, mechanizmy zwiększania ekspozycji, kryteria błędnego zamknięcia oraz strukturę sprzężenia.

**Data-generating mechanisms.** Użyto gier iid `±1`, procesu kapitału z absorpcją, dwuakcyjnego bandyty Bernoulliego ze zmianą reżimu oraz modelu kontynuacja–wyjście. W tym ostatnim agent wygrywa `+1` z prawdopodobieństwem `(1-μ)/2`, operator otrzymuje wynik przeciwny, a agent aktualizuje wartość kontynuacji na podstawie postrzeganego sygnału `+1` po wygranej i `−loss_weight` po stracie. Prawdopodobieństwo kontynuacji jest logistyczną funkcją wartości, temperatury i kosztu wyjścia.

**Estimands.** `P(Sᴼ(T)>0)`, wynik na ekspozycję, `E[N(T)]`, prawdopodobieństwo i czas ruiny, statyczny/dynamiczny regret, entropia, kalibracja, czas adaptacji, efekt ujawnienia wartości oczekiwanej, `ΔSᴼ−μΔN`.

**Methods.** Rozwiązania dokładne, Monte Carlo, wspólne DGM, LHS, ExtraTrees jako eksploracyjny model zastępczy, porównania parowane, adjudykacja błędu Monte Carlo, testy graniczne i kontrprzykłady.

**Performance measures.** Bias, MCSE, dokładne prawdopodobieństwa, regret, czas adaptacji, kalibracja, zgodność z tożsamością ekspozycyjną i stabilność w challenge set.

## 3.3. Skala wykonania

Wykonano łącznie około **9,61 mln trajektorii** różnych klas:

```text
M0 house edge:                       7 000 000
ruina i strategie stawkowania:        450 000
bandyty stationary/reversal:           192 000
screening ekspozycji:                  262 144
plan konfirmacyjny:                    196 608
interwencja disclosure:                196 608
adjudykacja gry uczciwej:            1 048 576
ujemna przewaga operatora:             262 144
```

Liczby trajektorii nie są jednym wspólnym rozmiarem próby: każdy moduł ma inny DGM i estymand. Precyzję oceniano przez MCSE oraz rozwiązania dokładne.

## 3.4. Weryfikacja

Pakiet przeszedł `6/6` testów jednostkowych i właściwości. Symulacje gry `±1` odzyskały dokładne prawdopodobieństwa dwumianowe, a symulacja stałej stawki odzyskała wyniki łańcucha absorbującego. Początkowy pojedynczy wyjątek gry uczciwej został oznaczony, a następnie rozstrzygnięty niezależną adjudykacją zamiast usunięcia post hoc.

---

# 4. Wyniki M0 — przewaga operatora

## 4.1. Twierdzenie o dodatnim warunkowym dryfie

Niech `e_t∈{{0,1}}` będzie decyzją ekspozycyjną mierzalną względem historii `F_(t−1)`, `N_T=Σe_t`, a `X_t` wynikiem operatora przy ekspozycji. Załóżmy:

```text
E[X_t | F_(t−1), e_t=1] = m_t ≥ μ > 0,
N_T → ∞,
```

oraz warunki martyngałowego prawa wielkich liczb, na przykład kontrolę sumy warunkowych wariancji. Definiując `d_t=X_t−m_t`, otrzymujemy:

```text
Sᴼ_T / N_T
= Σ e_t m_t / N_T + Σ e_t d_t / N_T
≥ μ + o(1)        prawie na pewno.
```

Stąd średni wynik operatora na ekspozycję jest ostatecznie dodatni, a `P(Sᴼ_T>0)→1`. To jest twierdzenie **P1**, ale wyłącznie przy jawnych założeniach. Nie wynika z niego `Sᴼ_T>0` dla każdej realizacji.

## 4.2. Dlaczego bezwarunkowe `E[X]>0` nie wystarcza

Kontrprzykład selekcji:

```text
Z ~ Bernoulli(1/2),
X=2, gdy Z=1,
X=−1, gdy Z=0,
E[X]=0.5.

Operator/agent eksponuje się tylko, gdy e=1−Z.
Wtedy każdy obserwowany wynik przy e=1 wynosi −1.
```

Dodatnia średnia bezwarunkowa nie chroni przed selekcją warunków ekspozycji. W modelach adaptacyjnych trzeba kontrolować `E[X_t|F_(t−1),e_t=1]`, a nie jedynie średnią całej populacji zdarzeń.

## 4.3. Poziomy „wygrywania”

```text
E[S_T]>0
≠ P(S_T>0)>0.5
≠ P(S_T>0)→1
≠ P(S_T>0)=1
≠ S_T>0 w każdej realizacji.
```

Przykład `X=100` z prawdopodobieństwem 0,02 i `X=−1` w pozostałych przypadkach ma dodatnią wartość oczekiwaną, ale tylko 2% szansy dodatniego wyniku pojedynczej gry. Odwrotnie, `X=1` z prawdopodobieństwem 0,9 oraz `X=−100` z prawdopodobieństwem 0,1 ma 90% szansy lokalnej wygranej i silnie ujemną wartość oczekiwaną.

## 4.4. Dokładne wyniki gry iid

{md_table(house_sel, ".6f")}

Dla `μ=0` prawdopodobieństwo dodatniego wyniku zbliża się do `0,5`, a nie do `1`. Dla `μ=0,02` wzrasta płynnie z `{p_mu100.p_operator_positive_exact:.3f}` przy `T=100`, przez `{p_mu200.p_operator_positive_exact:.3f}` przy `T=200`, do `{p_mu500.p_operator_positive_exact:.3f}` przy `T=500`. Nie występuje uprzywilejowanie liczby 200.

## 4.5. Ile ekspozycji potrzeba do wysokiego prawdopodobieństwa dodatniego bilansu

{md_table(threshold_tbl, ".6f")}

Dla przewagi 0,5% osiągnięcie 95% prawdopodobieństwa dodatniego bilansu wymaga co najmniej **108 221** nieparzystych ekspozycji w tym DGM; dla 1% — **27 055**; dla 2% — **6 763**; dla 5% — **1 081**. Jest to ilościowa treść „kasyno wygrywa w długim szeregu”, a nie magiczna granica biologiczna.

## 4.6. Ruina gracza

Dla przewidywalnej dodatniej stawki `b_t` i prawdopodobieństwa wygranej gracza `p=0,49`:

```text
E[ΔW_t | F_(t−1)] = b_t(2p−1) < 0.
```

Zmiana rozmiaru stawki nie odwraca znaku dryfu. Może zmieniać wariancję, czas do wyjścia i sposób zbliżania się do zera. Literalna ruina z prawdopodobieństwem dążącym do 1 wymaga dodatkowo m.in. nieskończonej liczby zakładów, dodatniej minimalnej stawki, braku dopływów i braku dobrowolnego wyjścia.

{md_table(ruin_sel, ".6f")}

Przy stałej stawce dokładne `P(ruiny do 5000)` wyniosło **{fixed5000.ruin_probability:.4f}**. Ograniczona strategia Martingale dała **{mart5000.ruin_probability:.4f}**, a więc pogorszyła ryzyko ruiny. Strategia proporcjonalna nie osiągnęła literalnego zera, lecz średni kapitał spadł do **{prop5000.mean_wealth:.2f}**, mediana do **{prop5000.median_wealth:.2f}**, a praktyczna ruina wystąpiła w **{prop5000.practical_ruin_probability:.2%}** trajektorii. Benchmark „nie gram” zachował kapitał i miał `P(ruiny)=0`.

**Werdykt M0:** formalnie silnie wsparty, z jasno wyznaczonymi warunkami. Status rdzenia: `P1`; odzyskanie przez obliczenia: `P3`.

---

# 5. Wyniki M1 — mechanizm ekspozycji

## 5.1. Screening globalny

Screening 2048 punktów LHS wykazał, że w zdefiniowanym modelu kontynuacji liczba ekspozycji była najbardziej czuła na temperaturę decyzji, wagę postrzeganej straty i tempo uczenia. Sama przewaga `μ` miała niewielką ważność dla liczby ekspozycji, lecz większą dla wyniku operatora. To rozróżnienie jest kluczowe: architektura utrzymująca agenta w interakcji i matematyczna przewaga jednostkowa są odrębnymi kanałami.

{md_table(imp, ".4f")}

Ważności ExtraTrees są wynikiem eksploracyjnym: model osiągał wysokie `R²` treningowe, ale wartości nie są uniwersalnymi efektami przyczynowymi ani rankingiem biologicznych mechanizmów.

## 5.2. Scenariusze konfirmacyjne

{md_table(extreme, ".4f")}

Przy `μ=0,02` przejście od pełnego ważenia strat i szybkiej aktualizacji do zaniżania strat, wolnej aktualizacji i kosztownego wyjścia zwiększyło `E[N]` z około **5,42** do **471,80**, a oczekiwany wynik operatora z około **0,07** do **9,34**. Przy `μ=0,05` analogiczny scenariusz osiągnął `E[N]=462,51` oraz `E[Sᴼ]=23,06`.

To nie dowodzi psychologicznej „ślepoty”; pokazuje mechanizm modelowy: jeżeli lokalny sygnał aktualizacji systematycznie niedoważa kosztów, a wyjście jest mniej atrakcyjne, polityka kontynuacji może pozostać skoncentrowana mimo ujemnej wartości pieniężnej agenta.

## 5.3. Ujawnienie wartości oczekiwanej

W kroku 50 część symulacji otrzymała doskonałą informację o jednostkowej wartości pieniężnej dalszej gry.

{md_table(disc_by_mu, ".4f")}

Średnio ujawnienie ograniczało ekspozycję w warunkach bezwładności, a przy dodatniej `μ` redukowało wynik operatora. Nie był to efekt uniwersalny dla każdego scenariusza. Wynik jest zgodny z empirycznym obrazem interwencji: dłuższa obowiązkowa przerwa może wydłużyć pauzę, ale nie musi zmieniać kwot po powrocie [17].

**Werdykt M1:** wsparty warunkowo w modelu i częściowo w literaturze o nagrodach społecznych, opóźnionym feedbacku oraz hazardzie. Status: `P3` w DGM; uogólnienie empiryczne zależne od domeny.

---

# 6. Wyniki M2 — koncentracja, kalibracja i zmiana reżimu

## 6.1. Twierdzenie softmax

Dla `β=1/τ`, `π_i=e^(βQ_i)/Z` oraz entropii `H=log Z−βE_π[Q]`:

```text
dH/dβ = −β Var_π(Q) ≤ 0.
```

Przy stałych wartościach `Q` zwiększenie różnic wartości albo zmniejszenie temperatury obniża entropię. Powtarzalna nagroda obniża entropię tylko wtedy, gdy algorytm aktualizacji powiększa różnice wartości i nie utrzymuje wymuszonej eksploracji. Nie jest to prawo każdego agenta.

## 6.2. Specjalizacja a błędne zamknięcie

W środowisku stacjonarnym agent rigid-softmax miał niską entropię `0,0427` oraz niski regret `0,0090`. Była to poprawna specjalizacja. Po odwróceniu wartości akcji ta sama bezwładność stała się kosztowna.

{md_table(rev, ".5f")}

Najważniejsze kontrprzykłady:

```text
niska entropia + niski regret  → specjalizacja adaptacyjna,
niska entropia + wysoki regret → błędna koncentracja,
wysoka entropia + wysoki regret → losowość bez skuteczności.
```

Agent z jawną informacją o zmianie osiągnął czas adaptacji `20,0`, rigid-softmax `48,1`, a błędnie stacjonarny agent bayesowski `186,5` i nie dostosował się w 70,35% trajektorii. Sama etykieta „model-based” nie zapewnia odporności; błędny model może utrwalić nieprawidłowy posterior.

## 6.3. Pewność i kalibracja

Dla flexible-softmax modelowy proxy pewności wzrósł z `0,5635` do `0,5783`, podczas gdy Brier pogorszył się z `0,1800` do `0,1884`, a nachylenie kalibracji po zmianie wyniosło `0,3735`. Pokazuje to modelową możliwość rozbieżności. Literatura ludzka również dokumentuje przypadki, w których trafność spada, a deklarowana pewność rośnie [12], oraz sytuacje, w których zachęty poprawiają wykonanie, ale przesuwają oceny pewności [13]. Nie wynika z tego, że value-gap jest tożsamy z ludzką pewnością.

## 6.4. Znaczenie biologiczne

Badania dopaminy wspierają wielomechanizmowy, a nie jednowymiarowy obraz. Klasyczny sygnał RPE ma silne wsparcie [4–5], lecz prace z 2025 r. pokazują także sygnał błędu predykcji działania wzmacniający powtórzenia [8] oraz dynamikę związaną z wykonaniem i motywacją, niekoniecznie uczeniem [9]. Badanie z 2026 r. wykazało nagłe przejście do nawyku w konkretnym paradygmacie u samców myszy, ale po tysiącach prób od uzyskania ekspertyzy i z możliwością powrotu do kontroli celowej [11]. To wspiera nieliniowość, lecz przeczy uniwersalnemu, trwałemu progowi 200.

**Werdykt M2:** konstrukcja algorytmiczna jest odporna, jeśli zamknięcie definiuje się przez regret i adaptację; most biologiczny pozostaje niepełny. Status: `P1/P3` dla modeli, `P5` dla bezpośredniej interpretacji biologicznej.

---

# 7. Wyniki M3 — sprzężenie

## 7.1. Tożsamość ekspozycyjna

Przy stałej warunkowej przewadze `μ`:

```text
E[Sᴼ(T)]
= E[Σ e_t X_t]
= E[Σ e_t E(X_t | F_(t−1), e_t=1)]
= μ E[N(T)].
```

Zamknięcie nie jest konieczne do dodatniego wyniku. Wpływa na operatora tylko wtedy, gdy zmienia `N(T)`, przyszłą `μ_t`, koszt lub inną składową użyteczności.

W dodatnich scenariuszach parowanych korelacja między obserwowanym `ΔSᴼ` i przewidywanym `μΔN` wyniosła **{corr:.4f}**, a średnia bezwzględna reszta sprzężenia **{mar:.4f}** jednostki. Nie jest to korelacja odkrywająca mechanizm — mechanizm wynika z DGM; wynik sprawdza poprawność implementacji.

## 7.2. Gra uczciwa i niezależna adjudykacja

Pierwszy przebieg 8192 replikacji dał w jednym porównaniu gry uczciwej różnicę wyglądającą na naruszenie `ΔSᴼ≈0`. Zamiast usunąć wynik, wykonano 16 nowych partii po 8192 replikacje, łącznie **131 072 trajektorie na scenariusz**.

```text
wszystkie średnie scenariuszy w granicach 3 MCSE:  TAK
wszystkie efekty parowane w granicach 3 MCSE:     TAK
maksymalne |z| średniej scenariusza:              {fair_adj['max_abs_z_scenario']:.3f}
maksymalne |z| efektu parowanego:                 {fair_adj['max_abs_z_effect']:.3f}
maksymalne |średniego ΔSᴼ|:                       {fair_adj['max_abs_mean_effect_gain']:.4f}
maksymalne |ΔN|:                                  {fair_adj['max_abs_mean_delta_exposures']:.1f}
```

Agent mógł zwiększyć ekspozycję o ponad 407 interakcji, lecz bez dodatniej przewagi nie powstał systematyczny oczekiwany zysk pieniężny operatora.

## 7.3. Ujemna przewaga operatora

W ośmiu scenariuszach `μ=−0,02` liczba ekspozycji wahała się od **{negative.mean_exposures.min():.1f}** do **{negative.mean_exposures.max():.1f}**, a każdy średni wynik operatora był ujemny: od **{negative.mean_operator_gain.min():.3f}** do **{negative.mean_operator_gain.max():.3f}**. Większa ekspozycja szkodziła operatorowi zgodnie z `μE[N]`.

## 7.4. Niezerowa suma i dobrostan

Skonstruowano dwie klasy kontrprzykładów:

```text
U3 — obie strony otrzymują dodatnią użyteczność z ekspozycji;
U5 — operator monetyzuje uwagę, a użyteczność agenta jest neutralna.
```

Wszystkie scenariusze U3 dawały dodatnią użyteczność obu stron. W U5 wynik operatora był dodatni przy braku wykazanej ujemnej użyteczności agenta. Literatura platformowa dostarcza zgodnych kontrprzykładów: rekomendacje zgodne z preferencjami idealnymi dawały mniej kliknięć, lecz większy dobrostan użytkownika i wybrane korzyści firmowe [20].

## 7.5. Challenge set

{md_table(challenge[["test", "assumption_attacked", "observed", "decision"]], ".4f")}

Wszystkie **18/18 klas** przeszły według prerejestrowanych lub jawnie uzupełnionych kryteriów. „PASS” nie oznacza prawdziwości biologicznej; oznacza, że teoria po zawężeniu nie została obalona przez określone kontrprzykłady formalne i obliczeniowe.

**Werdykt M3:** wsparty jako teoria warunkowa: zamknięcie jest mechanizmem wzmacniającym, nie źródłem przewagi samym w sobie. Status: `P1/P3`; trafność zewnętrzna ograniczona.

---

# 8. Ustrukturyzowana mapa dowodów

Przegląd nie spełnia pełnego PRISMA i nie jest nazywany systematycznym. Zakodowano {len(evidence)} źródeł kotwiczących.

{md_table(evidence_summary, ".0f")}

## 8.1. Co literatura wspiera mocno

Po pierwsze, organizmy i ludzie aktualizują zachowanie na podstawie relacji między działaniem, wynikiem i sygnałami predykcyjnymi; kontrola model-free i model-based może współistnieć [3–10]. Po drugie, pewność i trafność są rozdzielne, dlatego wzrost proxy pewności nie dowodzi poprawy modelu [12–14]. Po trzecie, architektura wzmocnienia i czas informacji mogą zmieniać trwałość zachowania oraz kontrolę celową [10, 15–18]. Po czwarte, mechanizmy platform rzeczywiście mogą wpływać na częstotliwość działania i postawy, ale efekty są zależne od platformy, wyniku i interwencji [19–22].

## 8.2. Co literatura falsyfikuje jako prosty uniwersalny łańcuch

Redukcja ekspozycji na podobne źródła na Facebooku zmieniła skład feedu, lecz nie osiem prerejestrowanych postaw [21]. Na X włączenie algorytmicznego feedu zwiększyło zaangażowanie i zmieniło wybrane opinie, ale nie polaryzację afektywną ani deklarowaną partyjność [22]. Dłuższe przerwy w hazardzie wydłużały pauzę, lecz nie zmieniały kwot stawek po powrocie [17]. Oznacza to, że:

```text
zmiana ekspozycji ≠ automatyczna zmiana przekonań,
zmiana zachowania ≠ automatyczny spadek dobrostanu,
interwencja ≠ uniwersalne odwrócenie polityki.
```

## 8.3. Twierdzenia pomostowe B1–B5

**B1 — koncentracja polityki ↔ nawyk.** Zgodność kierunkowa istnieje, ale entropia softmax nie jest zwalidowaną miarą biologicznego nawyku. Status `P5`.

**B2 — proxy pewności ↔ pewność człowieka.** Literatura potwierdza dysocjację pewność–trafność, nie identyczność value-gap i raportu introspekcyjnego. Status `P5`.

**B3 — adaptation delay ↔ reversal learning/sztywność.** Konstrukty są funkcjonalnie podobne, lecz brak kalibracji skali i trafności różnicowej. Status `P5`.

**B4 — operator syntetyczny ↔ platforma lub kasyno.** Istnieją empiryczne odpowiedniki nagród, retencji, feedów i przerw, ale cele operatorów i funkcje użyteczności są heterogeniczne. Status `P5`, częściowe zakotwiczenie.

**B5 — wynik operatora ↔ strata agenta.** Twierdzenie uniwersalne jest fałszywe. Status `P6`; relację trzeba mierzyć domenowo.

---

# 9. Rejestr twierdzeń — synteza

Pełny rejestr znajduje się w `claims/claim_registry.csv`. Rozkład statusów:

{md_table(claims.groupby(["module", "status"], as_index=False).size().rename(columns={"size": "liczba"}), ".0f")}

Najsilniejszy rdzeń dotyczy matematyki przewagi, warunkowości ruiny, nieswoistości entropii i tożsamości `μE[N]`. Najsłabsza warstwa dotyczy bezpośredniego mapowania zmiennych syntetycznych na ludzką percepcję.

---

# 10. Ostateczna teoria

## Hipoteza

Lokalne wzmocnienia i architektura wyjścia mogą zwiększać liczbę ekspozycji oraz utrwalać politykę agenta; jeżeli operator zachowuje dodatnią przewagę warunkową, wzrost ekspozycji może zwiększać jego skumulowany wynik.

## Teza

```text
M0: μ_t>0 warunkowo + N(T) rośnie
    → kumulacja przewagi operatora.

M1: lokalny sygnał + reguła kontynuacji + koszt wyjścia
    → zmiana N(T).

M2: koncentracja + regret + błąd aktualizacji + opóźnienie
    → błędne zamknięcie decyzyjne.

M3: M2 wpływa na M0 tylko wtedy, gdy zmienia N(T), μ_t,
    czas adaptacji, koszt albo inną użyteczność operatora.
```

## Przewód formalny

```text
E[Sᴼ(T)] = E[Σ e_t μ_t].
```

Przy stałej `μ`:

```text
E[Sᴼ(T)] = μE[N(T)].
```

Stąd:

```text
μ>0: większa oczekiwana ekspozycja zwiększa E[Sᴼ],
μ=0: ekspozycja nie tworzy oczekiwanego zysku pieniężnego,
μ<0: ekspozycja zwiększa oczekiwaną stratę operatora.
```

## Dowody obliczeniowe

Dokładne rozkłady i Monte Carlo odzyskały asymptotyczną przewagę. Modele reversal wykazały odrębność koncentracji i kosztu. Plan konfirmacyjny oraz challenge set wykazały sprzężenie przez ekspozycję i niepowodzenie teorii poza warunkami dodatniej przewagi lub innej użyteczności operatora.

## Dowody empiryczne

Literatura wspiera uczenie przez wyniki, wpływ opóźnienia i nagród na zachowanie, możliwość nawykowej kontroli, rozbieżność pewności i trafności oraz wpływ operatorów platform. Nie wspiera uniwersalnego progu 200, nieodwracalności ani prostego determinizmu dopaminowego.

## Warunki brzegowe

Teoria nie obowiązuje bez zmian, gdy ekspozycja jest selektywna względem ukrytej przewagi, `μ_t` jest adaptacyjne, funkcje użyteczności są nieporównywalne, agent może bez kosztu odmówić, gra zmienia się wskutek uczenia gracza albo operator uzyskuje korzyść pozapieniężną.

## Falsyfikatory

Teoria M3 zostałaby obalona w deklarowanym zakresie, gdyby przy stałej `μ>0` i poprawnie mierzonej ekspozycji trwały efekt zamknięcia na wynik operatora pozostawał po pełnym kontrolowaniu `N(T)` i przyszłej `μ_t`; gdyby zamknięcie systematycznie nie wpływało na wyjście, ekspozycję ani adaptację; albo gdyby kluczowe twierdzenia były zależne od jednego algorytmu i znikały w zamrożonym challenge set.

## Wniosek

„Kasyno wygrywa zawsze” jest defensywnym skrótem asymptotycznej przewagi warunkowej, a nie literalnego zwycięstwa w każdym szeregu. „Oczy szeroko zamknięte są” jest nazwą dla kosztownej bezwładności aktualizacji, nie dla samej koncentracji. Ich połączenie jest prawdziwe warunkowo: zamknięcie może przedłużyć pobyt agenta w systemie, ale nie tworzy przewagi operatora z niczego.

---

# 11. Ograniczenia

Badanie jest syntetyczne. Model kontynuacji upraszcza informację, pamięć, dobrostan i interakcję społeczną. Parametry nie są estymatami populacji ludzkiej. ExtraTrees służy do screeningu, nie identyfikacji przyczynowej. Nie wykonano niezależnej implementacji drugiego zespołu. Przegląd literatury jest ustrukturyzowaną mapą, a nie pełnym PRISMA. Nie zwalidowano progów binarnego `CLOSE`. Nie wykonano nowych badań ludzi, neuroobrazowania ani pomiarów fizjologicznych. Z tego powodu teoria biologiczna pozostaje otwarta.

---

# 12. Program dalszych badań

Następny etap obliczeniowy powinien wprowadzić adaptacyjną przewagę `μ_t`, heterogeniczne funkcje użyteczności, operatora uczącego się cech agenta, jawny model hipotez `HS`, oddzielny kanał obserwacji kontrfaktu oraz niezależną reimplementację. Etap empiryczny wymaga prerejestrowanego eksperymentu ludzkiego ze zmianą reżimu, pomiarem deklarowanej pewności, testem dewaluacji wyniku, realną możliwością wyjścia i wcześniejszym ustaleniem progów `CLOSE`. Nie wolno wyznaczać 200 prób jako granicy; liczba ekspozycji powinna być zmienną ciągłą i podlegać analizie punktów zmiany.

---

# 13. Bibliografia

[1] Kelly JL. A New Interpretation of Information Rate. *Bell System Technical Journal*. 1956;35(4):917–926. DOI: https://doi.org/10.1002/j.1538-7305.1956.tb03809.x

[2] Williams D. *Probability with Martingales*. Cambridge University Press; 1991. ISBN 9780521406055.

[3] Sutton RS, Barto AG. *Reinforcement Learning: An Introduction*. 2nd ed. MIT Press; 2018.

[4] Schultz W, Dayan P, Montague PR. A Neural Substrate of Prediction and Reward. *Science*. 1997;275(5306):1593–1599. DOI: https://doi.org/10.1126/science.275.5306.1593

[5] Steinberg EE, Keiflin R, Boivin JR, Witten IB, Deisseroth K, Janak PH. A causal link between prediction errors, dopamine neurons and learning. *Nature Neuroscience*. 2013;16:966–973. DOI: https://doi.org/10.1038/nn.3413

[6] Daw ND, Gershman SJ, Seymour B, Dayan P, Dolan RJ. Model-Based Influences on Humans’ Choices and Striatal Prediction Errors. *Neuron*. 2011;69(6):1204–1215. DOI: https://doi.org/10.1016/j.neuron.2011.02.027

[7] Balleine BW, O’Doherty JP. Human and Rodent Homologies in Action Control. *Neuropsychopharmacology*. 2010;35:48–69. DOI: https://doi.org/10.1038/npp.2009.131

[8] Greenstreet F, Martinez Vergara H, Johansson Y, et al. Dopaminergic action prediction errors serve as a value-free teaching signal. *Nature*. 2025;643:1333–1342. DOI: https://doi.org/10.1038/s41586-025-09008-9

[9] Bakhurin KI, et al. Dopamine dynamics during stimulus-reward learning in mice can be explained by performance rather than learning. *Nature Communications*. 2025. DOI: https://doi.org/10.1038/s41467-025-64132-4

[10] Perez OD, Urcelay GP. Delayed rewards weaken human goal directed actions. *npj Science of Learning*. 2025;10:36. DOI: https://doi.org/10.1038/s41539-025-00325-2

[11] Moore S, Wang Z, Zhu Z, et al. Revealing abrupt transitions from goal-directed to habitual behavior. *Nature Communications*. 2026;17:4751. DOI: https://doi.org/10.1038/s41467-026-71048-0

[12] Rahnev DA, Maniscalco B, Luber B, Lau H, Lisanby SH. Direct injection of noise to the visual cortex decreases accuracy but increases decision confidence. *Journal of Neurophysiology*. 2012;107(6):1556–1563. DOI: https://doi.org/10.1152/jn.00985.2011

[13] Lebreton M, Bacily K, Palminteri S, Engelmann JB. Two sides of the same coin: monetary incentives concurrently improve and bias confidence judgments. *Science Advances*. 2018;4:eaaq0668. DOI: https://doi.org/10.1126/sciadv.aaq0668

[14] Lebreton M, Langdon S, Slieker MJ, Nooitgedacht JS, Goudriaan AE, Denys D, Holst RJ. Contextual influence on confidence judgments in human reinforcement learning. *PLOS Computational Biology*. 2019;15:e1006973. DOI: https://doi.org/10.1371/journal.pcbi.1006973

[15] Clark L, Lawrence AJ, Astley-Jones F, Gray N. Gambling near-misses enhance motivation to gamble and recruit win-related brain circuitry. *Neuron*. 2009;61(3):481–490. DOI: https://doi.org/10.1016/j.neuron.2008.12.031

[16] Thrailkill EA. Partial reinforcement extinction and omission effects in the rat. *Journal of Experimental Psychology: Animal Learning and Cognition*. 2023. DOI: https://doi.org/10.1037/xan0000354

[17] Hopfgartner N, Auer M, Santos T, Helic D, Griffiths MD. The Effect of Mandatory Play Breaks on Subsequent Gambling Behavior. *Journal of Gambling Studies*. 2022;38:737–752. DOI: https://doi.org/10.1007/s10899-021-10078-3

[18] Auer M, Griffiths MD. An Empirical Investigation of Theoretical Loss and Gambling Intensity. *Journal of Gambling Studies*. 2014. DOI: https://doi.org/10.1007/s10899-013-9376-7

[19] Lindström B, Bellander M, Schultner DT, et al. A computational reward learning account of social media engagement. *Nature Communications*. 2021;12:1311. DOI: https://doi.org/10.1038/s41467-020-19607-x

[20] Khambatta P, Mariadassou S, Morris J, Wheeler SC. Tailoring recommendation algorithms to ideal preferences makes users better off. *Scientific Reports*. 2023;13:9325. DOI: https://doi.org/10.1038/s41598-023-34192-x

[21] Nyhan B, Settle J, Thorson E, et al. Like-minded sources on Facebook are prevalent but not polarizing. *Nature*. 2023;620:137–144. DOI: https://doi.org/10.1038/s41586-023-06297-w

[22] Gauthier G, Hodler R, Widmer P, Zhuravskaya E. The political effects of X’s feed algorithm. *Nature*. 2026;652:416–423. DOI: https://doi.org/10.1038/s41586-026-10098-2

[23] Morris TP, White IR, Crowther MJ. Using simulation studies to evaluate statistical methods. *Statistics in Medicine*. 2019;38:2074–2102. DOI: https://doi.org/10.1002/sim.8086

[24] Grimm V, Railsback SF, Vincenot CE, et al. The ODD Protocol for Describing Agent-Based and Other Simulation Models. *JASSS*. 2020;23(2):7. DOI: https://doi.org/10.18564/jasss.4259

[25] Page MJ, McKenzie JE, Bossuyt PM, et al. The PRISMA 2020 statement. *BMJ*. 2021;372:n71. DOI: https://doi.org/10.1136/bmj.n71

[26] Koehler E, Brown E, Haneuse S. On the Assessment of Monte Carlo Error in Simulation-Based Statistical Analyses. *The American Statistician*. 2009;63(2):155–162. DOI: https://doi.org/10.1198/tast.2009.0030

[27] Van Calster B, McLernon DJ, van Smeden M, Wynants L, Steyerberg EW. Calibration: the Achilles heel of predictive analytics. *BMC Medicine*. 2019;17:230. DOI: https://doi.org/10.1186/s12916-019-1466-7

---

# 14. Ostateczny format wniosku

```text
PEWNIKI FORMALNE:
1. Przy dodatnim warunkowym dryfie, N(T)→∞ i warunkach SLLN
   średni wynik operatora na ekspozycję jest dodatni,
   a P(Sᴼ(T)>0)→1.
2. Bezwarunkowe E[X]>0 nie wystarcza przy selektywnej ekspozycji.
3. Żaden przewidywalny dodatni system stawkowania nie odwraca
   jednostkowego ujemnego dryfu gry.
4. Dla softmax przy stałych Q: dH/dβ=−βVarπ(Q)≤0.
5. Przy stałej przewadze: E[Sᴼ(T)]=μE[N(T)].

NIEZMIENNIKI MODELU:
Nie przyznano pełnego P2, ponieważ nie wykonano niezależnej
reimplementacji przez drugi zespół. Uzyskano zgodność rozwiązań
analitycznych, Monte Carlo, testów właściwości i niezależnych partii RNG.

WYNIKI ODPORNE SYMULACYJNIE:
1. 18/18 klas challenge set przeszło po adjudykacji.
2. Przy μ=0 nawet różnica ekspozycji >407 nie tworzyła
   systematycznego oczekiwanego zysku pieniężnego.
3. Przy μ<0 wszystkie scenariusze dawały ujemny średni wynik operatora.
4. Niska entropia była adaptacyjna w środowisku stacjonarnym,
   lecz mogła generować regret po zmianie reżimu.
5. Błędnie wyspecyfikowany agent model-based mógł adaptować się
   gorzej niż prostsze algorytmy.

NAJSILNIEJSZE REGULARNOŚCI EMPIRYCZNE:
1. Zachowanie może być aktualizowane przez sygnały wyniku,
   błędu predykcji oraz powtarzania działania.
2. Opóźnienie skutków może osłabiać kontrolę celową.
3. Pewność i trafność mogą się rozchodzić.
4. Nagrody społeczne i algorytmy mogą zmieniać zaangażowanie,
   lecz skutki dla przekonań i dobrostanu są heterogeniczne.

TWIERDZENIA POMOSTOWE:
B1 — częściowe wsparcie kierunkowe, brak mapowania jeden-do-jednego.
B2 — niewykazane: proxy modelowe ≠ subiektywna pewność.
B3 — częściowe wsparcie konstrukcyjne, brak kalibracji skali.
B4 — częściowe wsparcie domenowe, duża heterogeniczność operatorów.
B5 — odrzucone jako uniwersalne: zysk operatora ≠ zawsze strata agenta.

HIPOTEZY OTWARTE:
1. Czy zwalidowany wielowymiarowy CLOSE przewiduje zachowanie ludzi?
2. Czy adaptacyjny operator tworzy sprzężenie μ_t×N(T)
   silniejsze niż stała przewaga?
3. Jakie interwencje zmniejszają regret netto bez usuwania
   prawidłowej specjalizacji?

TWIERDZENIA ODRZUCONE:
1. T=200 jest uniwersalnym progiem biologicznym.
2. Zamknięcie samo tworzy przewagę operatora.
3. Niska entropia jest automatycznie patologiczna.
4. Model-based jest zawsze odporniejszy.
5. Martingale usuwa ujemną wartość oczekiwaną.
6. Dopamina jest prostym przyciskiem przyjemności lub nagrody.
7. Zysk operatora jest zawsze stratą agenta.

MODUŁ M0 — WERDYKT:
Silnie wsparty formalnie i obliczeniowo; P1/P3.

MODUŁ M1 — WERDYKT:
Warunkowo wsparty w DGM i częściowo empirycznie; P3 z ograniczoną
trafnością zewnętrzną.

MODUŁ M2 — WERDYKT:
Wsparty jako konstrukt algorytmiczny oparty na regrecie i adaptacji;
biologiczny most pozostaje P5.

MODUŁ M3 — WERDYKT:
Wsparty jako warunkowe sprzężenie przez ekspozycję, przyszłą przewagę
lub opóźnienie adaptacji; nie jako uniwersalne prawo psychologiczne.

OSTATECZNA TEORIA:
Dodatnia przewaga operatora nie wymaga zamknięcia agenta.
Zamknięcie agenta nie gwarantuje przewagi operatora.
Gdy jednak zamknięcie zwiększa ekspozycję lub opóźnia wyjście,
a operator zachowuje dodatnią przewagę warunkową,
tempo kumulacji wyniku operatora rośnie zgodnie z E[Σe_tμ_t].

WARUNKI OBOWIĄZYWANIA:
Jawna definicja ekspozycji, użyteczności i przewagi; poprawne
warunkowanie względem selekcji; rosnący horyzont; kontrola wyjścia,
stawkowania, zależności czasowej i zmiany reżimu.

WARUNKI FALSYFIKACJI:
Trwały efekt zamknięcia na wynik operatora po pełnym usunięciu wpływu
na N(T), μ_t, adaptację i inne użyteczności; brak wpływu M2 na wyjście
lub adaptację; niestabilność znaku w zamrożonym challenge set.

OGRANICZENIA UOGÓLNIENIA BIOLOGICZNEGO:
Brak nowych eksperymentów, brak walidacji entropii jako percepcji,
brak biologicznego progu 200, brak podstaw do różnic płciowych
lub nieodwracalnego zamknięcia mózgu.

WERDYKT OGÓLNY:
B — istnieje warunkowa teoria formalno-obliczeniowa o ograniczonym
zakresie i częściowym wsparciu empirycznym.
```
"""
    (ROOT / "report.md").write_text(report, encoding="utf-8")
    return report


def create_summary(thresholds: pd.DataFrame, evidence: pd.DataFrame, claims: pd.DataFrame) -> dict:
    house = pd.read_csv(RESULTS / "house_edge.csv")
    ruin = pd.read_csv(RESULTS / "gambler_ruin.csv")
    bandit = pd.read_csv(RESULTS / "bandit_metrics.csv")
    challenge = pd.read_csv(RESULTS / "challenge_set_results_final.csv")
    fair = json.loads((RESULTS / "fair_game_adjudication_summary.json").read_text(encoding="utf-8"))
    summary = {
        "study": "Oczy szeroko zamknięte są — kasyno wygrywa zawsze",
        "version": "1.1.0",
        "overall_verdict": "B",
        "verdict_text": "Warunkowa teoria formalno-obliczeniowa o ograniczonym zakresie i częściowym wsparciu empirycznym.",
        "modules": {
            "M0": "strongly supported formally and computationally",
            "M1": "conditionally supported in the synthetic DGM and partially empirically",
            "M2": "supported as an algorithmic construct; biological bridge incomplete",
            "M3": "supported conditionally through exposure/edge/adaptation coupling",
        },
        "approx_total_trajectories": 9_608_080,
        "challenge_passed": int((challenge.decision == "PASS").sum()),
        "challenge_total": int(len(challenge)),
        "fair_game_adjudication": fair,
        "house_edge_thresholds": thresholds.to_dict(orient="records"),
        "fixed_unit_ruin_T5000": float(ruin[(ruin.strategy == "fixed_unit_exact") & (ruin.horizon == 5000)].ruin_probability.iloc[0]),
        "martingale_ruin_T5000": float(ruin[(ruin.strategy == "martingale_limit16") & (ruin.horizon == 5000)].ruin_probability.iloc[0]),
        "max_bandit_adaptation_delay": float(bandit[bandit.environment == "reversal"].adaptation_delay_mean.max()),
        "evidence_sources": int(len(evidence)),
        "claim_count": int(len(claims)),
        "no_special_threshold_200": True,
        "biological_proof": False,
    }
    (RESULTS / "study_summary_final.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    # canonical summary now points to final state
    (RESULTS / "study_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return summary


def update_readme(summary: dict) -> None:
    text = f"""# Oczy szeroko zamknięte są — kasyno wygrywa zawsze

Reprodukowalny pakiet badania formalno-obliczeniowego i ustrukturyzowanej mapy dowodów, wykonanego 6 sierpnia 2026 r.

## Werdykt

**B — warunkowa teoria formalno-obliczeniowa o ograniczonym zakresie i częściowym wsparciu empirycznym.**

Najważniejsze rozstrzygnięcie:

```text
Dodatnia przewaga operatora nie wymaga zamknięcia agenta.
Zamknięcie agenta nie gwarantuje przewagi operatora.
Jeżeli zamknięcie zwiększa ekspozycję lub opóźnia wyjście,
a operator zachowuje dodatnią przewagę warunkową,
wynik kumuluje się zgodnie z E[Σe_tμ_t].
```

Nie uzyskano podstaw dla biologicznego progu 200 ekspozycji, nieodwracalnego zamknięcia ani redukcji dopaminy do prostego przycisku nagrody.

## Zakres

- `M0`: przewaga operatora, stopping i ruina;
- `M1`: decyzja o kontynuacji i liczba ekspozycji;
- `M2`: koncentracja, regret, kalibracja i zmiana reżimu;
- `M3`: sprzężenie ekspozycji, przewagi i opóźnienia adaptacji;
- mapa {summary['evidence_sources']} źródeł empirycznych i metodologicznych;
- {summary['challenge_passed']}/{summary['challenge_total']} klas challenge set zakończonych wynikiem PASS.

Badanie nie obejmuje nowych eksperymentów na ludziach ani zwierzętach. Wyniki biologiczne mają status przeglądowy i pomostowy.

## Najważniejsze pliki

- `report.md` — kompletny raport końcowy;
- `claims/claim_registry.csv` — wieloosiowy rejestr twierdzeń;
- `literature/evidence_map.csv` — mapa źródeł;
- `literature/search_log.md` — protokół przeglądu zakresowego;
- `results/aggregated/study_summary_final.json` — wynik maszynowy;
- `results/aggregated/challenge_set_results_final.csv` — challenge set;
- `docs/ODD/` — dokumentacja modeli;
- `docs/preregistration.md` — prerejestracja.

## Uruchomienie

```bash
python -m pip install -r requirements.txt
python src/run_study.py --config configs/config.yaml
python src/adjudicate_fair_game.py
python src/run_supplemental_challenges.py
python src/finalize_package.py
pytest -q
```

Preregistracja SHA-256:

```text
5ff09e7c0cee6184dc82c65c4ea1c20ad2cf747d9b2063ae8feadaf91a88bbad
```
"""
    (ROOT / "README.md").write_text(text, encoding="utf-8")


def update_methodology() -> None:
    p = DOCS / "methodology.md"
    old = p.read_text(encoding="utf-8") if p.exists() else "# Metodologia\n"
    appendix = """

## Finalizacja 1.1.0

Po pierwotnym przebiegu challenge C12 wykazał pozorną różnicę w pojedynczym ziarnie gry uczciwej. Zgodnie z zasadą nieusuwania wyniku wykonano niezależną adjudykację: 16 partii × 8192 trajektorie, czyli 131 072 replikacje na scenariusz. Wszystkie średnie i efekty parowane znalazły się w granicach 3 MCSE. Challenge set rozszerzono do 18 klas o ujemną przewagę, niezerową sumę, selektywną ekspozycję, skończony horyzont ruiny i test braku progu 200.

Mapa literatury jest ustrukturyzowanym przeglądem zakresowym, nie pełnym przeglądem systematycznym PRISMA. Twierdzenia formalne, obliczeniowe, empiryczne i pomostowe są raportowane oddzielnie.
"""
    if "## Finalizacja 1.1.0" not in old:
        p.write_text(old.rstrip() + appendix, encoding="utf-8")


def update_manifest(summary: dict) -> None:
    p = ROOT / "experiment_manifest.json"
    manifest = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    manifest["version"] = "1.1.0"
    manifest["finalized_at_utc"] = datetime.now(timezone.utc).isoformat()
    manifest["finalization_python"] = sys.version
    manifest["finalization_platform"] = platform.platform()
    manifest["final_results"] = {
        "overall_verdict": summary["overall_verdict"],
        "challenge": f"{summary['challenge_passed']}/{summary['challenge_total']}",
        "approx_total_trajectories": summary["approx_total_trajectories"],
        "evidence_sources": summary["evidence_sources"],
        "claim_count": summary["claim_count"],
        "fair_game_total_replications_per_scenario": summary["fair_game_adjudication"]["total_replications_per_scenario"],
    }
    p.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")


def run_tests() -> dict:
    p = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=ROOT, capture_output=True, text=True, check=False)
    (ROOT / "results" / "audit_samples" / "pytest_output_final.txt").write_text(p.stdout + "\n" + p.stderr, encoding="utf-8")
    if p.returncode != 0:
        raise RuntimeError(p.stdout + p.stderr)
    return {"returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}


def write_checksums() -> None:
    targets = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if str(rel).startswith(".pytest_cache") or "__pycache__" in rel.parts or rel.name == "checksums.sha256":
            continue
        targets.append(path)
    lines = [f"{sha256(path)}  {path.relative_to(ROOT).as_posix()}" for path in sorted(targets)]
    (ROOT / "checksums.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    thresholds = create_thresholds()
    evidence = create_evidence_map()
    create_search_log(evidence)
    claims = create_claim_registry()
    create_report(thresholds, evidence, claims)
    summary = create_summary(thresholds, evidence, claims)
    update_readme(summary)
    update_methodology()
    update_manifest(summary)
    tests = run_tests()
    manifest_path = ROOT / "experiment_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["final_verification"] = tests
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    write_checksums()
    print(json.dumps({
        "report": str(ROOT / "report.md"),
        "threshold_rows": len(thresholds),
        "evidence_sources": len(evidence),
        "claims": len(claims),
        "tests": tests["stdout"].strip(),
        "verdict": summary["overall_verdict"],
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
