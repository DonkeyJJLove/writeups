from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binom

ROOT = Path(__file__).resolve().parents[1]
AGG = ROOT / "results" / "aggregated"
AUDIT = ROOT / "results" / "audit_samples"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def exact_positive_probability(mu: float, n: int) -> float:
    # Operator wins +1 with q=(1+mu)/2. For odd n there are no ties.
    q = (1.0 + mu) / 2.0
    return float(binom.sf(n // 2, n, q))


def main() -> None:
    thresholds = pd.read_csv(AGG / "house_edge_thresholds.csv")
    threshold_checks = []
    for row in thresholds.itertuples(index=False):
        p = exact_positive_probability(float(row.mu), int(row.minimum_odd_horizon))
        previous_n = int(row.minimum_odd_horizon) - 2
        p_prev = exact_positive_probability(float(row.mu), previous_n) if previous_n > 0 else 0.0
        threshold_checks.append({
            "mu": float(row.mu),
            "target": float(row.target_probability),
            "n": int(row.minimum_odd_horizon),
            "p_recomputed": p,
            "p_previous_odd": p_prev,
            "meets_target": bool(p >= row.target_probability),
            "previous_fails": bool(p_prev < row.target_probability),
            "matches_csv": bool(abs(p - row.exact_probability_at_threshold) < 1e-12),
        })

    paired = pd.read_csv(AGG / "exposure_confirmatory_paired_effects.csv")
    pos = paired.loc[paired["mu"] > 0].copy()
    corr = float(np.corrcoef(pos["delta_operator_gain"], pos["predicted_delta_via_exposure"])[0, 1])
    mean_abs_residual = float(np.mean(np.abs(pos["delta_operator_gain"] - pos["predicted_delta_via_exposure"])))

    fair = json.loads((AGG / "fair_game_adjudication_summary.json").read_text(encoding="utf-8"))
    challenge = pd.read_csv(AGG / "challenge_set_results_final.csv")
    negative = pd.read_csv(AGG / "negative_edge_challenge.csv")
    prereg_hash_recorded = (ROOT / "docs" / "preregistration.sha256").read_text(encoding="utf-8").strip().split()[0]
    prereg_hash_actual = sha256(ROOT / "docs" / "preregistration.md")

    report = (ROOT / "report.md").read_text(encoding="utf-8")
    required_endings = [
        "PEWNIKI FORMALNE:", "NIEZMIENNIKI MODELU:", "WYNIKI ODPORNE SYMULACYJNIE:",
        "NAJSILNIEJSZE REGULARNOŚCI EMPIRYCZNE:", "TWIERDZENIA POMOSTOWE:",
        "HIPOTEZY OTWARTE:", "TWIERDZENIA ODRZUCONE:", "MODUŁ M0 — WERDYKT:",
        "MODUŁ M1 — WERDYKT:", "MODUŁ M2 — WERDYKT:", "MODUŁ M3 — WERDYKT:",
        "OSTATECZNA TEORIA:", "WARUNKI OBOWIĄZYWANIA:", "WARUNKI FALSYFIKACJI:",
        "OGRANICZENIA UOGÓLNIENIA BIOLOGICZNEGO:", "WERDYKT OGÓLNY:",
    ]

    result = {
        "thresholds_all_minimal_and_exact": all(x["meets_target"] and x["previous_fails"] and x["matches_csv"] for x in threshold_checks),
        "threshold_checks": threshold_checks,
        "m3_positive_edge_correlation": corr,
        "m3_mean_absolute_identity_residual": mean_abs_residual,
        "fair_game_all_scenarios_within_3_mcse": bool(fair["all_scenario_means_within_3_mcse"]),
        "fair_game_all_paired_effects_within_3_mcse": bool(fair["all_paired_effects_within_3_mcse"]),
        "challenge_pass": int((challenge["decision"] == "PASS").sum()),
        "challenge_total": int(len(challenge)),
        "negative_edge_all_operator_means_negative": bool((negative["mean_operator_gain"] < 0).all()),
        "preregistration_hash_matches": prereg_hash_recorded == prereg_hash_actual,
        "report_has_required_final_sections": all(x in report for x in required_endings),
    }
    result["all_crosschecks_pass"] = bool(
        result["thresholds_all_minimal_and_exact"]
        and result["fair_game_all_scenarios_within_3_mcse"]
        and result["fair_game_all_paired_effects_within_3_mcse"]
        and result["challenge_pass"] == result["challenge_total"] == 18
        and result["negative_edge_all_operator_means_negative"]
        and result["preregistration_hash_matches"]
        and result["report_has_required_final_sections"]
        and result["m3_positive_edge_correlation"] > 0.99
    )
    AUDIT.mkdir(parents=True, exist_ok=True)
    (AUDIT / "independent_crosscheck.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if not result["all_crosschecks_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
