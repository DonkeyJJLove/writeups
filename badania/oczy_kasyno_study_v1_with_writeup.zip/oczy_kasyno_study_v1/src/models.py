from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.stats import binom, qmc

EPS = 1e-12


def binary_entropy(p: np.ndarray | float) -> np.ndarray:
    """Binary entropy in nats, numerically stable."""
    arr = np.clip(np.asarray(p, dtype=float), EPS, 1.0 - EPS)
    return -(arr * np.log(arr) + (1.0 - arr) * np.log(1.0 - arr))


def policy_concentration_binary(p: np.ndarray | float) -> np.ndarray:
    """Normalized concentration: 0 at p=.5, 1 at deterministic policy."""
    return 1.0 - binary_entropy(p) / np.log(2.0)




def calibration_metrics(predicted: np.ndarray, outcome: np.ndarray, n_bins: int = 10) -> dict[str, float]:
    """Calibration diagnostics for binary probabilistic predictions.

    The logistic calibration slope/intercept are estimated by Newton-Raphson on
    outcome ~ intercept + slope * logit(predicted). Constant-prediction cases
    return NaN slope because discrimination is unidentified.
    """
    p = np.clip(np.asarray(predicted, dtype=float).ravel(), 1e-6, 1.0 - 1e-6)
    y = np.asarray(outcome, dtype=float).ravel()
    if p.size != y.size or p.size == 0:
        raise ValueError("predicted and outcome must have equal nonzero size")
    mean_p = float(np.mean(p))
    mean_y = float(np.mean(y))
    log_score = float(-np.mean(y * np.log(p) + (1.0 - y) * np.log(1.0 - p)))
    brier = float(np.mean(np.square(p - y)))
    lo = np.log(p / (1.0 - p))
    if float(np.std(lo)) < 1e-10:
        intercept = float(np.log(np.clip(mean_y, 1e-6, 1 - 1e-6) / np.clip(1 - mean_y, 1e-6, 1 - 1e-6)) - np.mean(lo))
        slope = float("nan")
    else:
        beta = np.array([0.0, 1.0], dtype=float)
        X = np.column_stack([np.ones_like(lo), lo])
        for _ in range(50):
            eta = X @ beta
            phat = expit(eta)
            w = np.clip(phat * (1.0 - phat), 1e-8, None)
            grad = X.T @ (y - phat)
            hess = -(X.T * w) @ X - 1e-8 * np.eye(2)
            step = np.linalg.solve(hess, grad)
            beta_new = beta - step
            if np.max(np.abs(beta_new - beta)) < 1e-9:
                beta = beta_new
                break
            beta = beta_new
        intercept, slope = float(beta[0]), float(beta[1])
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1], right=True), 0, n_bins - 1)
    ece = 0.0
    for b in range(n_bins):
        mask = idx == b
        if np.any(mask):
            ece += float(np.mean(mask)) * abs(float(np.mean(y[mask])) - float(np.mean(p[mask])))
    return {
        "brier": brier,
        "log_score": log_score,
        "mean_prediction": mean_p,
        "mean_outcome": mean_y,
        "calibration_in_the_large_approx": float(
            np.log(np.clip(mean_y, 1e-6, 1 - 1e-6) / np.clip(1 - mean_y, 1e-6, 1 - 1e-6))
            - np.log(mean_p / (1.0 - mean_p))
        ),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "ece_10bin": float(ece),
        "sharpness_sd": float(np.std(p)),
    }


def mcse_mean(values: np.ndarray, axis: int | None = None) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    n = values.size if axis is None else values.shape[axis]
    return np.std(values, axis=axis, ddof=1) / np.sqrt(n)


def mcse_probability(p: np.ndarray | float, n: int) -> np.ndarray:
    p = np.asarray(p, dtype=float)
    return np.sqrt(np.maximum(p * (1.0 - p), 0.0) / n)


def simulate_house_edge(
    mus: Iterable[float],
    horizons: Iterable[int],
    n_rep: int,
    seed: int,
) -> pd.DataFrame:
    """Exact binomial benchmark plus Monte Carlo for a ±1 zero-sum game.

    Agent wins +1 with p=(1-mu)/2; operator receives the negative outcome,
    hence E[X_operator]=mu per exposure.
    """
    rng = np.random.default_rng(seed)
    rows: list[dict[str, float | int]] = []
    for mu in mus:
        p_agent = (1.0 - float(mu)) / 2.0
        if not 0.0 <= p_agent <= 1.0:
            raise ValueError(f"Invalid house edge mu={mu}")
        for horizon in horizons:
            wins = rng.binomial(int(horizon), p_agent, size=n_rep)
            gain = horizon - 2 * wins
            p_pos = float(np.mean(gain > 0))
            exact_p_pos = float(binom.cdf((horizon - 1) // 2, horizon, p_agent))
            mean_per_exposure = float(np.mean(gain) / horizon)
            rows.append(
                {
                    "mu": float(mu),
                    "horizon": int(horizon),
                    "replications": int(n_rep),
                    "mean_gain": float(np.mean(gain)),
                    "mean_gain_per_exposure": mean_per_exposure,
                    "theoretical_mean_per_exposure": float(mu),
                    "bias_mean_per_exposure": mean_per_exposure - float(mu),
                    "mcse_mean_per_exposure": float(mcse_mean(gain / horizon)),
                    "p_operator_positive_mc": p_pos,
                    "p_operator_positive_exact": exact_p_pos,
                    "mcse_probability": float(mcse_probability(p_pos, n_rep)),
                    "p_tie_mc": float(np.mean(gain == 0)),
                }
            )
    return pd.DataFrame(rows)


def fixed_stake_ruin_exact(
    p_agent_win: float,
    initial_wealth: int,
    horizons: Iterable[int],
) -> pd.DataFrame:
    """Exact finite-horizon absorbing random walk for unit stakes."""
    horizons_sorted = sorted(set(int(h) for h in horizons))
    max_t = max(horizons_sorted)
    max_w = initial_wealth + max_t
    dist = np.zeros(max_w + 1, dtype=float)
    dist[initial_wealth] = 1.0
    q = 1.0 - p_agent_win
    rows: list[dict[str, float | int]] = []
    targets = set(horizons_sorted)
    wealth_grid = np.arange(max_w + 1, dtype=float)
    for t in range(1, max_t + 1):
        new = np.zeros_like(dist)
        new[0] += dist[0]
        new[:-1] += q * dist[1:]
        new[2:] += p_agent_win * dist[1:-1]
        dist = new
        if t in targets:
            rows.append(
                {
                    "strategy": "fixed_unit_exact",
                    "horizon": t,
                    "ruin_probability": float(dist[0]),
                    "mean_wealth": float(np.sum(dist * wealth_grid)),
                    "median_wealth": float(np.searchsorted(np.cumsum(dist), 0.5)),
                    "practical_ruin_probability": float(np.sum(dist[: max(1, int(np.ceil(0.1 * initial_wealth)) + 1)])),
                    "exit_probability": 0.0,
                    "mean_exposures": np.nan,
                    "replications": 0,
                }
            )
    return pd.DataFrame(rows)


def simulate_betting_strategies(
    p_agent_win: float,
    initial_wealth: float,
    horizons: Iterable[int],
    n_rep: int,
    seed: int,
) -> pd.DataFrame:
    """Monte Carlo benchmarks for fixed, Martingale, stop-loss, proportional and no-play strategies."""
    horizons_sorted = sorted(set(int(h) for h in horizons))
    max_t = max(horizons_sorted)
    master = np.random.SeedSequence(seed)
    child_seeds = master.spawn(5)
    rows: list[dict[str, float | int]] = []

    # No play.
    for h in horizons_sorted:
        rows.append(
            {
                "strategy": "no_play",
                "horizon": h,
                "ruin_probability": 0.0,
                "mean_wealth": initial_wealth,
                "median_wealth": initial_wealth,
                "practical_ruin_probability": 0.0,
                "exit_probability": 1.0,
                "mean_exposures": 0.0,
                "replications": n_rep,
            }
        )

    def run_path_strategy(name: str, mode: str, child_seed: np.random.SeedSequence) -> None:
        rng = np.random.default_rng(child_seed)
        wealth = np.full(n_rep, initial_wealth, dtype=float)
        active = np.ones(n_rep, dtype=bool)
        exposures = np.zeros(n_rep, dtype=np.int32)
        stake = np.ones(n_rep, dtype=float)
        max_bet = 16.0
        snapshots: dict[int, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
        for t in range(1, max_t + 1):
            if mode == "stop_loss":
                active &= wealth > 0.8 * initial_wealth
            current_stake = np.minimum(stake, wealth)
            current_stake = np.minimum(current_stake, max_bet)
            current_stake = np.where(active, current_stake, 0.0)
            idx = np.flatnonzero(active)
            if idx.size:
                win = rng.random(idx.size) < p_agent_win
                bet = current_stake[idx]
                wealth[idx] += np.where(win, bet, -bet)
                exposures[idx] += 1
                if mode == "martingale":
                    stake[idx] = np.where(win, 1.0, np.minimum(2.0 * bet, max_bet))
                else:
                    stake[idx] = 1.0
                active[idx[wealth[idx] <= EPS]] = False
            if t in horizons_sorted:
                snapshots[t] = (wealth.copy(), active.copy(), exposures.copy())
        for h in horizons_sorted:
            w, a, e = snapshots[h]
            rows.append(
                {
                    "strategy": name,
                    "horizon": h,
                    "ruin_probability": float(np.mean(w <= EPS)),
                    "mean_wealth": float(np.mean(w)),
                    "median_wealth": float(np.median(w)),
                    "practical_ruin_probability": float(np.mean(w <= 0.1 * initial_wealth)),
                    "exit_probability": float(np.mean(~a)),
                    "mean_exposures": float(np.mean(e)),
                    "replications": n_rep,
                }
            )

    run_path_strategy("fixed_unit_mc", "fixed", child_seeds[0])
    run_path_strategy("martingale_limit16", "martingale", child_seeds[1])
    run_path_strategy("stop_loss_20pct", "stop_loss", child_seeds[2])

    # Proportional 1% stake: literal wealth never reaches zero in exact arithmetic.
    rng_prop = np.random.default_rng(child_seeds[3])
    previous = 0
    cumulative_wins = np.zeros(n_rep, dtype=np.int32)
    fraction = 0.01
    for h in horizons_sorted:
        increment = h - previous
        cumulative_wins += rng_prop.binomial(increment, p_agent_win, size=n_rep)
        losses = h - cumulative_wins
        wealth = initial_wealth * np.power(1.0 + fraction, cumulative_wins) * np.power(1.0 - fraction, losses)
        rows.append(
            {
                "strategy": "proportional_1pct",
                "horizon": h,
                "ruin_probability": float(np.mean(wealth <= EPS)),
                "mean_wealth": float(np.mean(wealth)),
                "median_wealth": float(np.median(wealth)),
                "practical_ruin_probability": float(np.mean(wealth <= 0.1 * initial_wealth)),
                "exit_probability": 0.0,
                "mean_exposures": float(h),
                "replications": n_rep,
            }
        )
        previous = h

    return pd.DataFrame(rows)


@dataclass(frozen=True)
class BanditEnvironment:
    horizon: int = 400
    switch: int | None = 200
    p_high: float = 0.8
    p_low: float = 0.2


def _adaptation_delay(optimal_choices: np.ndarray, window: int = 20, threshold: float = 0.8) -> np.ndarray:
    """First post-switch index at which rolling optimal-choice rate reaches threshold."""
    n, m = optimal_choices.shape
    if m < window:
        return np.full(n, m + 1, dtype=int)
    cs = np.cumsum(optimal_choices, axis=1, dtype=np.int32)
    rolls = cs[:, window - 1 :].copy()
    if window < m:
        rolls[:, 1:] -= cs[:, :-window]
    meets = rolls >= int(np.ceil(threshold * window))
    any_meet = np.any(meets, axis=1)
    first = np.argmax(meets, axis=1) + window
    return np.where(any_meet, first, m + 1)


def simulate_bandit_agent(
    agent: str,
    env: BanditEnvironment,
    n_rep: int,
    seed: int,
) -> tuple[dict[str, float | int | str], pd.DataFrame, pd.DataFrame]:
    """Two-action Bernoulli bandit, optionally with one reversal."""
    rng = np.random.default_rng(seed)
    t_max = env.horizon
    switch = env.switch

    q0 = np.full(n_rep, 0.5, dtype=float)
    q1 = np.full(n_rep, 0.5, dtype=float)
    a0 = np.ones(n_rep, dtype=float)
    b0 = np.ones(n_rep, dtype=float)
    a1 = np.ones(n_rep, dtype=float)
    b1 = np.ones(n_rep, dtype=float)

    regret_ts = np.zeros(t_max)
    entropy_ts = np.zeros(t_max)
    confidence_ts = np.zeros(t_max)
    brier_ts = np.zeros(t_max)
    log_score_ts = np.zeros(t_max)
    reward_ts = np.zeros(t_max)
    calibration_n = min(1000, n_rep)
    calibration_pred = np.zeros((calibration_n, t_max), dtype=np.float32)
    calibration_outcome = np.zeros((calibration_n, t_max), dtype=np.uint8)
    choice_optimal_post = None
    if switch is not None:
        choice_optimal_post = np.zeros((n_rep, t_max - switch), dtype=np.uint8)

    pre_regret_rep = np.zeros(n_rep)
    post_regret_rep = np.zeros(n_rep)
    pre_entropy_rep = np.zeros(n_rep)
    post_entropy_rep = np.zeros(n_rep)
    pre_brier_rep = np.zeros(n_rep)
    post_brier_rep = np.zeros(n_rep)
    pre_conf_rep = np.zeros(n_rep)
    post_conf_rep = np.zeros(n_rep)
    pre_n = max(1, switch if switch is not None else t_max)
    post_n = max(1, t_max - switch) if switch is not None else 1

    for t in range(t_max):
        reversed_phase = switch is not None and t >= switch
        if reversed_phase:
            p0, p1_true = env.p_low, env.p_high
        else:
            p0, p1_true = env.p_high, env.p_low

        if agent == "oracle":
            p_choose1 = np.full(n_rep, 1.0 if reversed_phase else 0.0)
            v0 = np.full(n_rep, p0)
            v1 = np.full(n_rep, p1_true)
        elif agent == "random":
            p_choose1 = np.full(n_rep, 0.5)
            v0 = q0
            v1 = q1
        elif agent in {"softmax_rigid", "softmax_flexible", "cue_informed"}:
            if agent == "cue_informed" and switch is not None and t == switch:
                q0.fill(env.p_low)
                q1.fill(env.p_high)
            tau = {"softmax_rigid": 0.05, "softmax_flexible": 0.20, "cue_informed": 0.05}[agent]
            p_choose1 = expit((q1 - q0) / tau)
            v0, v1 = q0, q1
        elif agent == "epsilon_q":
            eps = 0.10
            gt = q1 > q0
            lt = q1 < q0
            p_choose1 = np.where(gt, 1.0 - eps / 2.0, np.where(lt, eps / 2.0, 0.5))
            v0, v1 = q0, q1
        elif agent in {"bayes_stationary", "bayes_discounted"}:
            if agent == "bayes_discounted":
                decay = 0.98
                a0 = 1.0 + decay * (a0 - 1.0)
                b0 = 1.0 + decay * (b0 - 1.0)
                a1 = 1.0 + decay * (a1 - 1.0)
                b1 = 1.0 + decay * (b1 - 1.0)
            v0 = a0 / (a0 + b0)
            v1 = a1 / (a1 + b1)
            eps = 0.05
            gt = v1 > v0
            lt = v1 < v0
            p_choose1 = np.where(gt, 1.0 - eps / 2.0, np.where(lt, eps / 2.0, 0.5))
        else:
            raise ValueError(f"Unknown agent: {agent}")

        choose1 = rng.random(n_rep) < p_choose1
        true_prob = np.where(choose1, p1_true, p0)
        reward = (rng.random(n_rep) < true_prob).astype(float)
        predicted = np.where(choose1, v1, v0)
        predicted = np.clip(predicted, 1e-6, 1.0 - 1e-6)
        best_prob = max(p0, p1_true)
        regret = best_prob - true_prob
        ent = binary_entropy(p_choose1)
        confidence = np.abs(v1 - v0)
        brier = np.square(predicted - reward)
        log_score = -(reward * np.log(predicted) + (1.0 - reward) * np.log(1.0 - predicted))
        calibration_pred[:, t] = predicted[:calibration_n]
        calibration_outcome[:, t] = reward[:calibration_n].astype(np.uint8)

        regret_ts[t] = np.mean(regret)
        entropy_ts[t] = np.mean(ent)
        confidence_ts[t] = np.mean(confidence)
        brier_ts[t] = np.mean(brier)
        log_score_ts[t] = np.mean(log_score)
        reward_ts[t] = np.mean(reward)

        if switch is None or t < switch:
            pre_regret_rep += regret / pre_n
            pre_entropy_rep += ent / pre_n
            pre_brier_rep += brier / pre_n
            pre_conf_rep += confidence / pre_n
        else:
            post_regret_rep += regret / post_n
            post_entropy_rep += ent / post_n
            post_brier_rep += brier / post_n
            post_conf_rep += confidence / post_n
            assert choice_optimal_post is not None
            choice_optimal_post[:, t - switch] = choose1.astype(np.uint8)

        # Update after observing reward.
        if agent in {"softmax_rigid", "softmax_flexible", "cue_informed", "epsilon_q"}:
            alpha = {
                "softmax_rigid": 0.03,
                "softmax_flexible": 0.20,
                "cue_informed": 0.03,
                "epsilon_q": 0.10,
            }[agent]
            idx1 = choose1
            idx0 = ~choose1
            q1[idx1] += alpha * (reward[idx1] - q1[idx1])
            q0[idx0] += alpha * (reward[idx0] - q0[idx0])
        elif agent in {"bayes_stationary", "bayes_discounted"}:
            idx1 = choose1
            idx0 = ~choose1
            a1[idx1] += reward[idx1]
            b1[idx1] += 1.0 - reward[idx1]
            a0[idx0] += reward[idx0]
            b0[idx0] += 1.0 - reward[idx0]

    if switch is not None and choice_optimal_post is not None:
        delays = _adaptation_delay(choice_optimal_post)
        delay_mean = float(np.mean(delays))
        delay_median = float(np.median(delays))
        no_adapt = float(np.mean(delays > (t_max - switch)))
    else:
        delays = np.full(n_rep, np.nan)
        delay_mean = np.nan
        delay_median = np.nan
        no_adapt = np.nan

    if switch is None:
        cal_pre = calibration_metrics(calibration_pred.ravel(), calibration_outcome.ravel())
        cal_post = {k: float("nan") for k in cal_pre}
    else:
        cal_pre = calibration_metrics(calibration_pred[:, :switch].ravel(), calibration_outcome[:, :switch].ravel())
        cal_post = calibration_metrics(calibration_pred[:, switch:].ravel(), calibration_outcome[:, switch:].ravel())

    metrics: dict[str, float | int | str] = {
        "agent": agent,
        "environment": "reversal" if switch is not None else "stationary",
        "replications": n_rep,
        "horizon": t_max,
        "switch": -1 if switch is None else switch,
        "pre_regret_mean": float(np.mean(pre_regret_rep)),
        "post_regret_mean": float(np.mean(post_regret_rep)) if switch is not None else np.nan,
        "pre_entropy_mean": float(np.mean(pre_entropy_rep)),
        "post_entropy_mean": float(np.mean(post_entropy_rep)) if switch is not None else np.nan,
        "pre_confidence_proxy": float(np.mean(pre_conf_rep)),
        "post_confidence_proxy": float(np.mean(post_conf_rep)) if switch is not None else np.nan,
        "pre_brier": float(np.mean(pre_brier_rep)),
        "post_brier": float(np.mean(post_brier_rep)) if switch is not None else np.nan,
        "pre_log_score": cal_pre["log_score"],
        "post_log_score": cal_post["log_score"],
        "pre_mean_prediction": cal_pre["mean_prediction"],
        "post_mean_prediction": cal_post["mean_prediction"],
        "pre_mean_outcome": cal_pre["mean_outcome"],
        "post_mean_outcome": cal_post["mean_outcome"],
        "pre_calibration_intercept": cal_pre["calibration_intercept"],
        "post_calibration_intercept": cal_post["calibration_intercept"],
        "pre_calibration_slope": cal_pre["calibration_slope"],
        "post_calibration_slope": cal_post["calibration_slope"],
        "pre_ece_10bin": cal_pre["ece_10bin"],
        "post_ece_10bin": cal_post["ece_10bin"],
        "pre_sharpness_sd": cal_pre["sharpness_sd"],
        "post_sharpness_sd": cal_post["sharpness_sd"],
        "adaptation_delay_mean": delay_mean,
        "adaptation_delay_median": delay_median,
        "no_adaptation_rate": no_adapt,
        "mcse_post_regret": float(mcse_mean(post_regret_rep)) if switch is not None else np.nan,
        "mcse_adaptation_delay": float(mcse_mean(delays[~np.isnan(delays)])) if switch is not None else np.nan,
    }

    timeseries = pd.DataFrame(
        {
            "agent": agent,
            "environment": metrics["environment"],
            "t": np.arange(t_max),
            "mean_regret": regret_ts,
            "mean_entropy": entropy_ts,
            "mean_confidence_proxy": confidence_ts,
            "mean_brier": brier_ts,
            "mean_log_score": log_score_ts,
            "mean_reward": reward_ts,
        }
    )
    audit = pd.DataFrame(
        {
            "agent": agent,
            "pre_regret": pre_regret_rep[: min(200, n_rep)],
            "post_regret": post_regret_rep[: min(200, n_rep)] if switch is not None else np.nan,
            "pre_entropy": pre_entropy_rep[: min(200, n_rep)],
            "post_entropy": post_entropy_rep[: min(200, n_rep)] if switch is not None else np.nan,
            "pre_confidence": pre_conf_rep[: min(200, n_rep)],
            "post_confidence": post_conf_rep[: min(200, n_rep)] if switch is not None else np.nan,
            "pre_brier": pre_brier_rep[: min(200, n_rep)],
            "post_brier": post_brier_rep[: min(200, n_rep)] if switch is not None else np.nan,
            "adaptation_delay": delays[: min(200, n_rep)],
        }
    )
    return metrics, timeseries, audit


def make_lhs_exposure_parameters(n_scenarios: int, seed: int) -> pd.DataFrame:
    sampler = qmc.LatinHypercube(d=6, seed=seed)
    u = sampler.random(n_scenarios)
    # Log-uniform mappings for alpha and tau.
    alpha = np.exp(np.log(0.01) + u[:, 2] * (np.log(0.30) - np.log(0.01)))
    tau = np.exp(np.log(0.02) + u[:, 3] * (np.log(0.30) - np.log(0.02)))
    return pd.DataFrame(
        {
            "scenario_id": np.arange(n_scenarios, dtype=int),
            "mu": 0.10 * u[:, 0],
            "loss_weight": 0.10 + 1.10 * u[:, 1],
            "alpha": alpha,
            "tau": tau,
            "q0": 0.50 * u[:, 4],
            "exit_cost": 0.20 * u[:, 5],
        }
    )


def make_confirmatory_exposure_parameters() -> pd.DataFrame:
    rows: list[dict[str, float | int]] = []
    sid = 0
    for mu in (0.0, 0.02, 0.05):
        for loss_weight in (1.0, 0.25):
            for alpha in (0.20, 0.02):
                for exit_cost in (0.0, 0.10):
                    rows.append(
                        {
                            "scenario_id": sid,
                            "mu": mu,
                            "loss_weight": loss_weight,
                            "alpha": alpha,
                            "tau": 0.05,
                            "q0": 0.30,
                            "exit_cost": exit_cost,
                        }
                    )
                    sid += 1
    return pd.DataFrame(rows)


def simulate_exposure_model(
    params: pd.DataFrame,
    n_rep: int,
    horizon: int,
    seed: int,
    disclosure_t: int | None = None,
) -> pd.DataFrame:
    """Continuation/exit model with true ±1 monetary outcomes and biased local learning signal.

    For scenario j, the agent wins +1 with p=(1-mu_j)/2. Operator gain is -Y.
    Agent updates a continuation value Q using perceived reward +1 after a win and
    -loss_weight after a loss. Exit has value -exit_cost.
    """
    required = {"scenario_id", "mu", "loss_weight", "alpha", "tau", "q0", "exit_cost"}
    missing = required.difference(params.columns)
    if missing:
        raise ValueError(f"Missing parameters: {sorted(missing)}")
    rng = np.random.default_rng(seed)
    n_s = len(params)
    shape = (n_s, n_rep)
    mu = params["mu"].to_numpy(float)[:, None]
    loss_weight = params["loss_weight"].to_numpy(float)[:, None]
    alpha = params["alpha"].to_numpy(float)[:, None]
    tau = params["tau"].to_numpy(float)[:, None]
    q_value = np.broadcast_to(params["q0"].to_numpy(float)[:, None], shape).copy()
    exit_cost = params["exit_cost"].to_numpy(float)[:, None]
    p_win = (1.0 - mu) / 2.0

    alive = np.ones(shape, dtype=bool)
    exposures = np.zeros(shape, dtype=np.int32)
    op_gain = np.zeros(shape, dtype=np.float32)
    agent_gain = np.zeros(shape, dtype=np.float32)
    pc_sum = np.zeros(shape, dtype=np.float32)
    pc_count = np.zeros(shape, dtype=np.int32)

    for t in range(horizon):
        active = alive.copy()
        if not np.any(active):
            break
        win = rng.random(shape) < p_win
        y = np.where(win, 1.0, -1.0)
        exposures += active
        agent_gain += np.where(active, y, 0.0).astype(np.float32)
        op_gain += np.where(active, -y, 0.0).astype(np.float32)
        perceived = np.where(win, 1.0, -loss_weight)
        q_value = np.where(active, q_value + alpha * (perceived - q_value), q_value)
        if disclosure_t is not None and t == disclosure_t:
            # Perfect disclosure of expected monetary value of continuing one more bet.
            q_value = np.where(active, -mu, q_value)
        p_continue = expit((q_value + exit_cost) / tau)
        pc = policy_concentration_binary(p_continue)
        pc_sum += np.where(active, pc, 0.0).astype(np.float32)
        pc_count += active
        alive = active & (rng.random(shape) < p_continue)

    rows: list[dict[str, float | int]] = []
    for j, source in params.reset_index(drop=True).iterrows():
        n_j = exposures[j].astype(float)
        s_o = op_gain[j].astype(float)
        s_a = agent_gain[j].astype(float)
        pc_j = pc_sum[j] / np.maximum(pc_count[j], 1)
        p_pos = float(np.mean(s_o > 0.0))
        mean_n = float(np.mean(n_j))
        mean_gain = float(np.mean(s_o))
        rows.append(
            {
                **{k: (int(v) if k == "scenario_id" else float(v)) for k, v in source.to_dict().items()},
                "replications": n_rep,
                "horizon": horizon,
                "disclosure_t": -1 if disclosure_t is None else disclosure_t,
                "mean_exposures": mean_n,
                "mcse_exposures": float(mcse_mean(n_j)),
                "mean_operator_gain": mean_gain,
                "mcse_operator_gain": float(mcse_mean(s_o)),
                "mean_agent_gain": float(np.mean(s_a)),
                "p_operator_positive": p_pos,
                "mcse_p_operator_positive": float(mcse_probability(p_pos, n_rep)),
                "exit_rate": float(np.mean(~alive[j])),
                "mean_policy_concentration": float(np.mean(pc_j)),
                "mean_final_q": float(np.mean(q_value[j])),
                "mean_update_error": float(np.mean(np.abs(q_value[j] + float(source["mu"])))),
                "expected_gain_via_exposure": float(source["mu"] * mean_n),
                "gain_residual": mean_gain - float(source["mu"] * mean_n),
            }
        )
    return pd.DataFrame(rows)


def softmax_entropy_grid() -> pd.DataFrame:
    ratios = np.concatenate(
        [
            np.linspace(0.0, 1.0, 21),
            np.linspace(1.25, 5.0, 16),
            np.linspace(6.0, 12.0, 7),
        ]
    )
    p = expit(ratios)
    return pd.DataFrame(
        {
            "abs_delta_over_tau": ratios,
            "p_preferred_action": p,
            "entropy_nats": binary_entropy(p),
            "normalized_concentration": policy_concentration_binary(p),
        }
    )
