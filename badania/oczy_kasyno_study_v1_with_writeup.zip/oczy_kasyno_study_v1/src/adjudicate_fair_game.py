from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from models import make_confirmatory_exposure_parameters, simulate_exposure_model
from run_study import paired_effects

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results' / 'aggregated'

params = make_confirmatory_exposure_parameters()
fair = params[params.mu == 0.0].copy().reset_index(drop=True)
master = np.random.SeedSequence(2026080601)
children = master.spawn(16)

scenario_batches = []
effect_batches = []
for b, child in enumerate(children):
    seed = int(child.generate_state(1, dtype=np.uint32)[0])
    res = simulate_exposure_model(fair, n_rep=8192, horizon=500, seed=seed)
    res['batch'] = b
    res['seed'] = seed
    scenario_batches.append(res)
    eff = paired_effects(res)
    eff['batch'] = b
    eff['seed'] = seed
    effect_batches.append(eff)

sb = pd.concat(scenario_batches, ignore_index=True)
eb = pd.concat(effect_batches, ignore_index=True)
sb.to_csv(RESULTS / 'fair_game_adjudication_batches.csv', index=False)
eb.to_csv(RESULTS / 'fair_game_adjudication_effect_batches.csv', index=False)

scenario_group_cols = ['scenario_id','mu','loss_weight','alpha','tau','q0','exit_cost']
scenario_summary = sb.groupby(scenario_group_cols, as_index=False).agg(
    mean_operator_gain=('mean_operator_gain','mean'),
    batch_sd_operator_gain=('mean_operator_gain','std'),
    mean_exposures=('mean_exposures','mean'),
    batch_sd_exposures=('mean_exposures','std'),
    batches=('batch','nunique'),
)
scenario_summary['mcse_operator_gain_across_batches'] = scenario_summary.batch_sd_operator_gain / np.sqrt(scenario_summary.batches)
scenario_summary['z_operator_gain'] = scenario_summary.mean_operator_gain / scenario_summary.mcse_operator_gain_across_batches
scenario_summary['within_3_mcse'] = scenario_summary.mean_operator_gain.abs() <= 3 * scenario_summary.mcse_operator_gain_across_batches
scenario_summary.to_csv(RESULTS / 'fair_game_adjudication_scenarios.csv', index=False)

key_cols = ['intervention','alpha','exit_cost','loss_weight']
# NaN is a grouping key only with dropna=False.
effect_summary = eb.groupby(key_cols, as_index=False, dropna=False).agg(
    mean_delta_operator_gain=('delta_operator_gain','mean'),
    batch_sd_delta_gain=('delta_operator_gain','std'),
    mean_delta_exposures=('delta_exposures','mean'),
    batch_sd_delta_exposures=('delta_exposures','std'),
    batches=('batch','nunique'),
)
effect_summary['mcse_delta_gain_across_batches'] = effect_summary.batch_sd_delta_gain / np.sqrt(effect_summary.batches)
effect_summary['z_delta_gain'] = effect_summary.mean_delta_operator_gain / effect_summary.mcse_delta_gain_across_batches
effect_summary['within_3_mcse'] = effect_summary.mean_delta_operator_gain.abs() <= 3 * effect_summary.mcse_delta_gain_across_batches
effect_summary.to_csv(RESULTS / 'fair_game_adjudication_effects.csv', index=False)

summary = {
    'replications_per_batch': 8192,
    'batches': 16,
    'total_replications_per_scenario': 8192 * 16,
    'all_scenario_means_within_3_mcse': bool(scenario_summary.within_3_mcse.all()),
    'all_paired_effects_within_3_mcse': bool(effect_summary.within_3_mcse.all()),
    'max_abs_z_scenario': float(scenario_summary.z_operator_gain.abs().max()),
    'max_abs_z_effect': float(effect_summary.z_delta_gain.abs().max()),
    'max_abs_mean_scenario_gain': float(scenario_summary.mean_operator_gain.abs().max()),
    'max_abs_mean_effect_gain': float(effect_summary.mean_delta_operator_gain.abs().max()),
    'max_abs_mean_delta_exposures': float(effect_summary.mean_delta_exposures.abs().max()),
}
(RESULTS / 'fair_game_adjudication_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
